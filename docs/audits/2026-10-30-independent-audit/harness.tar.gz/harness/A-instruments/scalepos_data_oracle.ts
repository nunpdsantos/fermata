// Key-independent data check of every authored scale position against the INDEPENDENT oracle
// (not the app's SCALE_FORMULAS). Key A, placed by the app's own getScalePositions.
import { SCALE_POSITION_LIBRARY, getScalePositions } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/constants/guitarScalePositions.ts';
import { ORACLE_SCALES, pcOf, mod12 } from './oracle.ts';
const OPEN = ['E', 'A', 'D', 'G', 'B', 'E'].map(pcOf);
const DEG: Record<string, number> = { '1': 0, b2: 1, '2': 2, '#2': 3, b3: 3, '3': 4, b4: 4, '4': 5, '#4': 6, b5: 6, '5': 7, '#5': 8, b6: 8, '6': 9, bb7: 9, b7: 10, '7': 11 };
const ALIAS: Record<string, string> = { ionian: 'major', aeolian: 'natural_minor' };
let uniq = 0, ok = 0, notes = 0, wrongLabel = 0, outScale = 0, missingDeg = 0; const okList: string[] = []; const seen = new Set<unknown>();
for (const [sc, list] of Object.entries(SCALE_POSITION_LIBRARY)) {
  const or = ORACLE_SCALES[ALIAS[sc] ?? sc];
  getScalePositions({ natural: 'A', accidental: '' } as any, sc).forEach(({ position: p, baseFret: b }, i) => {
    if (seen.has(p)) return; seen.add(p); uniq++;
    let bad = 0; const present = new Set<number>();
    for (const n of p.notes) { notes++; const iv = mod12(OPEN[6 - n.string] + b + n.fret - 9); present.add(iv);
      if (iv !== DEG[n.degree]) { wrongLabel++; bad++; } if (!or.semis.includes(iv)) { outScale++; bad++; } }
    const miss = or.semis.filter((s) => !present.has(s)); if (miss.length) { missingDeg++; bad++; }
    if (!bad) { ok++; okList.push(`${sc} #${i + 1} ${p.shortName}`); }
  });
}
console.log(`unique authored positions: ${uniq}; fully correct (every note in scale, labelled right, all scale degrees present): ${ok}`);
console.log(`correct: ${okList.join(', ')}`);
console.log(`notes: ${notes}; mislabelled: ${wrongLabel}; out-of-scale: ${outScale}; positions missing >=1 scale degree: ${missingDeg}`);
