// Audit every hand-authored scale position against the scale engine.
// Usage (from repo root): npx tsx <this file>
import { SCALE_POSITION_LIBRARY, getScalePositions } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/constants/guitarScalePositions.ts';
import { SCALE_FORMULAS } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/constants/scales.ts';

const OPEN = [4, 9, 2, 7, 11, 4]; // string index 0 = low E (string 6)
const DEG: Record<string, number> = {
  '1': 0, b2: 1, '2': 2, '#2': 3, b3: 3, '3': 4, b4: 4, '4': 5, '#4': 6, b5: 6,
  '5': 7, '#5': 8, b6: 8, '6': 9, bb7: 9, b7: 10, '7': 11,
};
const ROOTS = ['C', 'C#', 'D', 'Eb', 'E', 'F', 'F#', 'G', 'Ab', 'A', 'Bb', 'B'].map((s) => ({
  natural: s[0], accidental: s.slice(1),
})) as any[];
const rootPc = (i: number) => i; // ROOTS listed chromatically from C

const problems: string[] = [];
const summary: string[] = [];
let checked = 0;

for (const [scale, positions] of Object.entries(SCALE_POSITION_LIBRARY)) {
  const formula = SCALE_FORMULAS[scale as keyof typeof SCALE_FORMULAS];
  if (!formula) { problems.push(`${scale}: no engine formula`); continue; }
  const fset = new Set(formula);
  const shapeIssues = new Set<string>();
  const coverageGaps: string[] = [];

  // Shape-level checks (root-independent): do in key of the position's own computed root
  positions.forEach((p, pi) => {
    const label = `${scale} #${pi + 1} "${p.name}"`;
    // degree label sanity
    for (const n of p.notes) {
      if (!(n.degree in DEG)) shapeIssues.add(`${label}: unknown degree label ${n.degree}`);
      else if (!fset.has(DEG[n.degree])) shapeIssues.add(`${label}: degree ${n.degree} not in ${scale} formula`);
      if (!!n.isRoot !== (n.degree === '1')) shapeIssues.add(`${label}: isRoot flag mismatch on s${n.string} f${n.fret} (${n.degree})`);
    }
    // covers every scale degree
    const present = new Set(p.notes.map((n) => DEG[n.degree]));
    const missing = formula.filter((x) => !present.has(x));
    if (missing.length) shapeIssues.add(`${label}: missing degrees (semitones) ${missing.join(',')}`);
    // root anchor
    const anchor = p.notes.find((n) => n.string === p.rootString && n.fret === p.rootFretOffset);
    if (!anchor || anchor.degree !== '1') shapeIssues.add(`${label}: rootString/rootFretOffset (${p.rootString}/${p.rootFretOffset}) does not point at a '1'`);
    // span
    const frets = p.notes.map((n) => n.fret);
    const span = Math.max(...frets) - Math.min(...frets) + 1;
    if (span > 6) shapeIssues.add(`${label}: hand span ${span} frets`);
    // duplicate identical pitch on two strings
    const midis = p.notes.map((n) => [4, 9, 14, 19, 23, 28][6 - n.string] + n.fret);
    if (new Set(midis).size !== midis.length) shapeIssues.add(`${label}: same pitch appears twice (unison duplicate)`);
  });

  // Root-dependent checks: pitch-class truth at the computed baseFret, for all 12 roots
  ROOTS.forEach((root, ri) => {
    const rpc = rootPc(ri);
    const placed = getScalePositions(root, scale);
    const covered = new Set<string>();
    placed.forEach(({ position, baseFret }, pi) => {
      for (const n of position.notes) {
        checked++;
        const s = 6 - n.string;
        const abs = baseFret + n.fret;
        const pc = (OPEN[s] + abs) % 12;
        const interval = (pc - rpc + 12) % 12;
        if (interval !== DEG[n.degree]) {
          problems.push(`${scale} key ${root.natural}${root.accidental} pos #${pi + 1}: s${n.string} fret ${abs} sounds interval ${interval}, labelled '${n.degree}' (=${DEG[n.degree]})`);
        }
        if (!fset.has(interval)) {
          problems.push(`${scale} key ${root.natural}${root.accidental} pos #${pi + 1}: s${n.string} fret ${abs} is OUT OF SCALE (interval ${interval})`);
        }
        if (abs > 22) problems.push(`${scale} key ${root.natural}${root.accidental} pos #${pi + 1}: fret ${abs} beyond 22-fret board`);
        covered.add(`${s}:${abs % 12}`);
      }
    });
    // Coverage of one octave of the neck: every in-scale fret 0-11 on every string
    // should belong to at least one position (positions should tile the neck).
    if (ri === 0) {
      for (let s = 0; s < 6; s++) for (let f = 0; f < 12; f++) {
        const iv = (OPEN[s] + f - rpc + 120) % 12;
        if (fset.has(iv) && !covered.has(`${s}:${f}`)) coverageGaps.push(`s${6 - s}f${f}`);
      }
    }
  });

  shapeIssues.forEach((x) => problems.push(x));
  summary.push(`${scale.padEnd(22)} ${String(positions.length).padStart(2)} positions${coverageGaps.length ? `  | C-key neck gaps (not in any position): ${coverageGaps.length} [${coverageGaps.slice(0, 8).join(' ')}${coverageGaps.length > 8 ? ' …' : ''}]` : '  | tiles the neck'}`);
}

console.log(summary.join('\n'));
console.log(`\nnotes checked (scale x 12 keys x positions x notes): ${checked}`);
console.log(`problems: ${problems.length}`);
console.log(problems.join('\n'));
process.exitCode = 0;
