// How many KeySelector (root x scale) combos spell with double accidentals, and would the enharmonic root avoid them?
import { buildScale, SCALE_FORMULAS } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/constants/scales.ts';
const KS = ['C', 'C#', 'D', 'Eb', 'E', 'F', 'F#', 'G', 'Ab', 'A', 'Bb', 'B'];
const ENH: Record<string, string> = { 'C#': 'Db', Eb: 'D#', 'F#': 'Gb', Ab: 'G#', Bb: 'A#' };
const N = (s: string) => ({ natural: s[0], accidental: s.slice(1) }) as any;
const cnt = (r: string, t: string) => buildScale(N(r), t as any).notes.filter((n) => n.accidental.length === 2).length;
let combos = 0, withDbl = 0, avoidable = 0; const ex: string[] = [];
for (const t of Object.keys(SCALE_FORMULAS)) for (const r of KS) { combos++; const c = cnt(r, t); if (c) { withDbl++; if (ENH[r] && cnt(ENH[r], t) < c) { avoidable++; if (ex.length < 12) ex.push(`${r} ${t} (${c} dbl: ${buildScale(N(r), t as any).notes.map((n) => n.natural + n.accidental).join(' ')}) -> ${ENH[r]} has ${cnt(ENH[r], t)}`); } } }
console.log(`KeySelector combos: ${combos}; spelled with >=1 double accidental: ${withDbl}; of which the enharmonic root would use fewer: ${avoidable}`);
for (const e of ex) console.log('  ' + e);
