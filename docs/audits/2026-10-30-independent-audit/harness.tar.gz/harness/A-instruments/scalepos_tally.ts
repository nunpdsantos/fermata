import { SCALE_POSITION_LIBRARY, getScalePositions } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/constants/guitarScalePositions.ts';
import { SCALE_FORMULAS } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/constants/scales.ts';
const OPEN = [4, 9, 2, 7, 11, 4];
const DEG: Record<string, number> = { '1':0,b2:1,'2':2,'#2':3,b3:3,'3':4,b4:4,'4':5,'#4':6,b5:6,'5':7,'#5':8,b6:8,'6':9,bb7:9,b7:10,'7':11 };
let okPos = 0, badPos = 0, okNotes = 0, wrongLabel = 0, outOfScale = 0;
const rows: string[] = [];
for (const [scale, positions] of Object.entries(SCALE_POSITION_LIBRARY)) {
  const fset = new Set(SCALE_FORMULAS[scale as keyof typeof SCALE_FORMULAS]);
  const placed = getScalePositions({ natural: 'A', accidental: '' } as any, scale);
  const cells = placed.map(({ position, baseFret }) => {
    let bad = 0, oos = 0;
    for (const n of position.notes) {
      const iv = (OPEN[6 - n.string] + baseFret + n.fret - 9 + 120) % 12;
      if (iv !== DEG[n.degree]) bad++; else okNotes++;
      if (!fset.has(iv)) oos++;
    }
    wrongLabel += bad; outOfScale += oos;
    bad ? badPos++ : okPos++;
    return `${position.shortName}:${bad ? `${bad}/${position.notes.length} wrong (${oos} out of scale)` : 'OK'}`;
  });
  rows.push(`${scale.padEnd(22)} ${cells.join(' | ')}`);
}
console.log(rows.join('\n'));
console.log(`\npositions correct: ${okPos}, broken: ${badPos}; notes correct ${okNotes}, mislabelled ${wrongLabel} (of which out-of-scale ${outOfScale})  [key of A]`);
