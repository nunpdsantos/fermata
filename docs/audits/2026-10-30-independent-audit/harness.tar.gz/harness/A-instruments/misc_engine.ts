// (1) getScalePositionBaseFret NOTE_TO_PITCH_CLASS '?? 0' fallback for roots the UI can set
// (2) diatonic chords offered per scale (ScaleDegreeBar buttons / ChordGrid): are their notes in the scale?
// (3) circle constants vs first principles
import { getScalePositions } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/constants/guitarScalePositions.ts';
import { buildScale, SCALE_FORMULAS } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/constants/scales.ts';
import { getDiatonicChordsForScale } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/constants/chords.ts';
import { CIRCLE_MAJOR, CIRCLE_MINOR, KEY_SIGNATURES } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/components/theory/circleOfFifthsConstants.ts';
import { pcOf, majorKeySignature, spellDegree } from './oracle.ts';
const N = (s: string) => ({ natural: s[0], accidental: s.slice(1) }) as any;
// (1) reachable double-accidental roots: chord roots from diatonic chords of KeySelector scales
const KS = ['C', 'C#', 'D', 'Eb', 'E', 'F', 'F#', 'G', 'Ab', 'A', 'Bb', 'B'];
const dbl = new Set<string>();
for (const t of Object.keys(SCALE_FORMULAS)) for (const r of KS) { try { for (const d of getDiatonicChordsForScale(buildScale(N(r), t as any))) { const s = d.chord.root.natural + d.chord.root.accidental; if (s.length === 3) dbl.add(`${s} (from ${r} ${t})`); } } catch { /* crash scales */ } }
console.log(`double-accidental chord roots reachable via the degree bar (then "Compatible scales" -> setKey(chord.root)): ${dbl.size}, e.g. ${[...dbl].slice(0, 5).join('; ')}`);
for (const [dblRoot, enh] of [['F##', 'G'], ['C##', 'D'], ['Bbb', 'A'], ['Ebb', 'D']]) {
  const a = getScalePositions(N(dblRoot), 'locrian').map((p) => p.baseFret).join(',');
  const b = getScalePositions(N(enh), 'locrian').map((p) => p.baseFret).join(',');
  const c = getScalePositions(N('C'), 'locrian').map((p) => p.baseFret).join(',');
  console.log(`  locrian positions base frets: root ${dblRoot} -> [${a}]  vs enharmonic ${enh} -> [${b}]  vs C -> [${c}]  ${a === b ? 'OK' : 'WRONG (falls back to C)'}`);
}
// (2) diatonic chords whose notes leave the scale
let tot = 0, out = 0; const ex: Record<string, string> = {};
for (const t of Object.keys(SCALE_FORMULAS)) {
  let scaleBad = 0, scaleTot = 0;
  for (const r of KS) { let ds; try { ds = getDiatonicChordsForScale(buildScale(N(r), t as any)); } catch { continue; }
    const pcs = new Set(buildScale(N(r), t as any).notes.map((n) => pcOf(n.natural + n.accidental)));
    for (const d of ds) { tot++; scaleTot++; const bad = d.chord.notes.filter((n) => !pcs.has(pcOf(n.natural + n.accidental))); if (bad.length) { out++; scaleBad++; if (r === 'C') ex[t] = (ex[t] ? ex[t] + ', ' : '') + `${d.numeral}=${d.chord.root.natural}${d.chord.root.accidental} ${d.chord.quality} (${bad.map((n) => n.natural + n.accidental).join('')} not in scale)`; } } }
  if (scaleBad) console.log(`  ${t.padEnd(18)} ${scaleBad}/${scaleTot} offered chords contain non-scale notes; C: ${ex[t]}`);
}
console.log(`diatonic-chord buttons with non-scale notes: ${out}/${tot}`);
// (3) circle constants
const bad3: string[] = [];
CIRCLE_MAJOR.forEach((n, i) => { const s = n.natural + n.accidental; const k = majorKeySignature(s); const txt = k.count === 0 ? '' : k.count === 6 ? '6♯/6♭' : `${k.count}${k.type === '#' ? '♯' : '♭'}`; if (txt !== KEY_SIGNATURES[i]) bad3.push(`${s}: ${KEY_SIGNATURES[i]} vs ${txt}`);
  const rel = spellDegree(s, '6')!; const m = CIRCLE_MINOR[i].natural + CIRCLE_MINOR[i].accidental; if (pcOf(rel) !== pcOf(m)) bad3.push(`relative minor of ${s} is ${rel}, circle shows ${m}`);
  if (i > 0) { const prev = CIRCLE_MAJOR[i - 1]; if ((pcOf(prev.natural + prev.accidental) + 7) % 12 !== pcOf(s)) bad3.push(`${s} is not a fifth above previous`); } });
console.log(`circle constants (12 major + 12 minor + 12 signatures + fifth steps) mismatches: ${bad3.length} ${bad3.join(' | ')}`);
