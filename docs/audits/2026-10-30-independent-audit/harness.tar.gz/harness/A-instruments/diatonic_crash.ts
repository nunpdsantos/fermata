// Which scale types make getDiatonicChordsForScale throw (it runs inside useKeyContext,
// which Fretboard, Piano, CircleOfFifths, ScaleDegreeBar... all call on every render)?
import { buildScale, SCALE_FORMULAS } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/constants/scales.ts';
import { getDiatonicChordsForScale } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/constants/chords.ts';
const ROOTS = ['C', 'C#', 'D', 'Eb', 'E', 'F', 'F#', 'G', 'Ab', 'A', 'Bb', 'B'];
const crash: Record<string, string> = {}; let ok = 0;
for (const t of Object.keys(SCALE_FORMULAS)) for (const r of ROOTS) {
  try { getDiatonicChordsForScale(buildScale({ natural: r[0], accidental: r.slice(1) } as any, t as any)); ok++; }
  catch (e) { crash[t] = `${(e as Error).message} (all ${ROOTS.length} roots)`; }
}
console.log('ok cases:', ok); for (const [t, m] of Object.entries(crash)) console.log('THROWS', t, '->', m);
// known-positive: a fake 8-note scale must throw the same way
try { getDiatonicChordsForScale({ ...buildScale({ natural: 'C', accidental: '' } as any, 'bebop_major'), type: 'bebop_major' }); console.log('planted: no throw'); } catch { console.log('planted bebop_major C: throws (detector works)'); }
