// Audio pitch mapping checks (pure functions + exact replicas of the 2-line octave rules
// in audio.ts, cited by line). Run: cd <repo> && npx tsx <this file>
import { getNoteFrequency, getPitchClass } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/constants/notes.ts';
import { midiToNote, getMidiNumber, getVoicedChordNotes } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/utils/pianoLayout.ts';
import { buildChord, CHORD_FORMULAS, getDiatonicTriads } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/constants/chords.ts';
import { GUITAR_TUNINGS } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/constants/guitarTunings.ts';
import { midiOf, freqOfMidi, pcOf } from './oracle.ts';

// 1. MIDI <-> frequency over the full piano + guitar range (independent formula)
let bad = 0;
for (let m = 21; m <= 108; m++) {
  const n = midiToNote(m);
  const f = getNoteFrequency(n, n.octave);
  if (Math.abs(f - freqOfMidi(m)) > 1e-6 || getMidiNumber(n, n.octave) !== m || midiOf(n.natural + n.accidental, n.octave) !== m) { bad++; console.log('MISMATCH', m, n, f); }
}
console.log(`midi 21..108: midiToNote/getMidiNumber/getNoteFrequency mismatches vs oracle: ${bad} (A4=${getNoteFrequency({ natural: 'A', accidental: '' }, 4)}Hz, C4 midi ${getMidiNumber({ natural: 'C', accidental: '' }, 4)})`);
// known-positive: a planted off-by-one must be caught
console.log(`plant: freqOfMidi(70) vs app A4 differ? ${Math.abs(freqOfMidi(70) - getNoteFrequency({ natural: 'A', accidental: '' }, 4)) > 1e-6}`);

// 2. Tunings: Fretboard midi = 12 + octave*12 + pc (Fretboard.tsx fretNoteMap)
for (const t of GUITAR_TUNINGS) {
  const app = t.strings.map((s) => 12 + s.octave * 12 + pcOf(s.natural + s.accidental));
  const ora = t.strings.map((s) => midiOf(s.natural + s.accidental, s.octave));
  console.log(`tuning ${t.id.padEnd(15)} open-string midi ${app.join(',')}  oracle ${ora.join(',')}  ${app.join() === ora.join() ? 'OK' : 'MISMATCH'}  Hz ${ora.map((m) => freqOfMidi(m).toFixed(2)).join(',')}`);
}

// 3. Spelled-note octave convention: app pitch for (Cb,4)/(B#,4) vs scientific pitch
for (const [n, o] of [['Cb', 4], ['B#', 3], ['B#', 4], ['Cb', 5]] as const) {
  const app = 12 + o * 12 + pcOf(n); const sci = midiOf(n, o);
  console.log(`${n}${o}: app midi ${app} (${(freqOfMidi(app)).toFixed(1)}Hz), scientific ${sci} (${freqOfMidi(sci).toFixed(1)}Hz)`);
}

// 4. Ear-training chord playback: ExerciseRunner.tsx:112 playChord(chord.notes, 4) -> audio.ts playChord
//    plays EVERY note at octave 4 (audio.ts:716-729). Which chords come out NOT in root position?
const ROOTS = ['C', 'Db', 'D', 'Eb', 'E', 'F', 'F#', 'G', 'Ab', 'A', 'Bb', 'B'];
let combos = 0, inverted = 0; const invEx: string[] = [];
for (const q of Object.keys(CHORD_FORMULAS)) for (const r of ROOTS) {
  combos++;
  const c = buildChord({ natural: r[0], accidental: r.slice(1) } as any, q as any);
  const midis = c.notes.map((n) => 12 + 4 * 12 + getPitchClass(n));
  if (Math.min(...midis) !== midis[0]) { inverted++; if (invEx.length < 8) invEx.push(`${r}${q}: plays ${c.notes.map((n, i) => n.natural + n.accidental + (Math.floor((midis[i] - 12) / 12))).join(' ')} — lowest is ${c.notes[midis.indexOf(Math.min(...midis))].natural}${c.notes[midis.indexOf(Math.min(...midis))].accidental}`); }
}
console.log(`\near-training playChord: ${inverted}/${combos} (quality x 12 roots) chords sound with a non-root note in the bass`);
for (const s of invEx) console.log('  ' + s);
// triads only
let tri = 0, triInv = 0;
for (const q of ['major', 'minor', 'diminished', 'augmented']) for (const r of ROOTS) { tri++; const c = buildChord({ natural: r[0], accidental: r.slice(1) } as any, q as any); const m = c.notes.map((n) => getPitchClass(n)); if (Math.min(...m) !== m[0]) triInv++; }
console.log(`  of which basic triads: ${triInv}/${tri}`);
// progressions: getDiatonicTriads(C) chords via playChord at octave 4
const prog = getDiatonicTriads({ natural: 'C', accidental: '' } as any).map((d) => `${d.numeral}:${d.chord.notes.map((n) => n.natural + n.accidental).join('')}${Math.min(...d.chord.notes.map(getPitchClass)) === getPitchClass(d.chord.notes[0]) ? '' : '(inv)'}`);
console.log(`  progression triads in C at octave 4: ${prog.join(' ')}`);

// 5. Piano chord highlight + playback voicing for low octaves (pianoLayout.getOpenVoicedChordNotes)
let lowCombos = 0, lowBassWrong = 0; const lowEx: string[] = [];
for (const oct of [1, 2, 3]) for (const q of ['major', 'minor', 'diminished', 'augmented', 'major7', 'minor7', 'dominant7']) for (const r of ROOTS) {
  lowCombos++;
  const c = buildChord({ natural: r[0], accidental: r.slice(1) } as any, q as any);
  const v = getVoicedChordNotes(c.notes, oct);
  const lowest = v[0];
  if (getPitchClass(lowest) !== getPitchClass(c.notes[0])) { lowBassWrong++; if (lowEx.length < 6) lowEx.push(`oct ${oct} ${r}${q}: ${v.map((n) => n.natural + n.accidental + n.octave).join(' ')}`); }
}
console.log(`\ngetVoicedChordNotes at baseOctave 1-3 (root-position chord): ${lowBassWrong}/${lowCombos} put a non-root in the bass`);
for (const s of lowEx) console.log('  ' + s);
