
const REPO = '/Users/nunosantos/Documents/Base/Music/new_music_app';
const HERE = '/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/A-instruments';
export default ({
  root: REPO,
  esbuild: { jsx: 'automatic' },
  oxc: { jsx: { runtime: 'automatic' } },
  cacheDir: HERE + '/.vitecache',
  resolve: { alias: { 'virtual:pwa-register': REPO + '/src/test/stubs/pwa-register.ts' } },
  server: { fs: { allow: [REPO, HERE] } },
  test: {
    dir: HERE + '/render',
    include: ['**/*.test.{ts,tsx}'],
    environment: 'jsdom',
    setupFiles: [REPO + '/src/i18n/index.ts'],
    testTimeout: 600000,
  },
});
