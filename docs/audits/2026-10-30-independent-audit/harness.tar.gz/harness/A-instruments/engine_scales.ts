// Compare the app's buildScale (feeds fretboard/piano/staff highlighting + labels)
// against the independent oracle for every scale type x every root spelling.
// Run: cd <repo> && npx tsx <this file>
import { buildScale, SCALE_FORMULAS } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/constants/scales.ts';
import { ORACLE_SCALES, spellDegree, pcOf, mod12, majorKeySignature } from './oracle.ts';

// --- oracle self-test (known-answer checks; proves the oracle can fail) ---
const selfTests: [string, string[]][] = [
  ['C major', ['C', 'D', 'E', 'F', 'G', 'A', 'B']],
  ['A natural_minor', ['A', 'B', 'C', 'D', 'E', 'F', 'G']],
  ['D dorian', ['D', 'E', 'F', 'G', 'A', 'B', 'C']],
  ['Eb major', ['Eb', 'F', 'G', 'Ab', 'Bb', 'C', 'D']],
  ['C# major', ['C#', 'D#', 'E#', 'F#', 'G#', 'A#', 'B#']],
  ['C altered', ['C', 'Db', 'Eb', 'Fb', 'Gb', 'Ab', 'Bb']],
  ['A harmonic_minor', ['A', 'B', 'C', 'D', 'E', 'F', 'G#']],
  ['E phrygian_dominant', ['E', 'F', 'G#', 'A', 'B', 'C', 'D']],
];
let selfFail = 0;
for (const [label, expected] of selfTests) {
  const [root, type] = label.split(' ');
  const got = ORACLE_SCALES[type].degrees.map((d) => spellDegree(root, d));
  if (got.join(' ') !== expected.join(' ')) { selfFail++; console.log('ORACLE SELF-TEST FAIL', label, got.join(' ')); }
}
const ks = (t: string) => { const k = majorKeySignature(t); return `${k.count}${k.type}`; };
for (const [t, e] of [['C', '0'], ['G', '1#'], ['F#', '6#'], ['C#', '7#'], ['F', '1b'], ['Gb', '6b'], ['Cb', '7b']] as const) {
  if (ks(t) !== e) { selfFail++; console.log('KEYSIG SELF-TEST FAIL', t, ks(t)); }
}
// planted bad value must be caught:
if (ORACLE_SCALES.major.degrees.map((d) => spellDegree('C', d)).join(' ') === 'C D E F# G A B') selfFail++;
console.log(`oracle self-tests: ${selfFail === 0 ? 'PASS' : 'FAIL ' + selfFail}`);

const ROOTS = ['C', 'C#', 'Db', 'D', 'D#', 'Eb', 'E', 'F', 'F#', 'Gb', 'G', 'G#', 'Ab', 'A', 'A#', 'Bb', 'B', 'Cb', 'E#', 'Fb', 'B#'];
const KEYSELECTOR = ['C', 'C#', 'D', 'Eb', 'E', 'F', 'F#', 'G', 'Ab', 'A', 'Bb', 'B'];
const toNote = (s: string) => ({ natural: s[0], accidental: s.slice(1) }) as any;
const str = (n: any) => n.natural + n.accidental;

let formulaMismatch = 0, pcMismatch = 0, spellMismatch = 0, total = 0;
const spellRows: Record<string, string[]> = {};
for (const type of Object.keys(SCALE_FORMULAS)) {
  const or = ORACLE_SCALES[type];
  if (!or) { console.log('NO ORACLE FOR', type); continue; }
  if (SCALE_FORMULAS[type as keyof typeof SCALE_FORMULAS].join(',') !== or.semis.join(',')) {
    formulaMismatch++;
    console.log(`FORMULA ${type}: app ${SCALE_FORMULAS[type as keyof typeof SCALE_FORMULAS].join(',')} oracle ${or.semis.join(',')}`);
  }
  for (const root of ROOTS) {
    total++;
    const app = buildScale(toNote(root), type as any).notes.map(str);
    const exp = or.degrees.map((d) => spellDegree(root, d));
    const appPcs = app.map(pcOf).sort((a, b) => a - b).join(',');
    const expPcs = or.semis.map((s) => mod12(pcOf(root) + s)).sort((a, b) => a - b).join(',');
    if (appPcs !== expPcs) { pcMismatch++; console.log(`PC ${root} ${type}: app [${app.join(' ')}] expected pcs ${expPcs}`); }
    const expS = exp.map((e) => e ?? '(triple)').join(' ');
    if (app.join(' ') !== expS) {
      spellMismatch++;
      (spellRows[type] ??= []).push(`${KEYSELECTOR.includes(root) ? '*' : ' '}${root}: app [${app.join(' ')}]  conventional [${expS}]`);
    }
  }
}
console.log(`\nscale types: ${Object.keys(SCALE_FORMULAS).length}; (type x root) cases: ${total}`);
console.log(`formula mismatches vs first-principles: ${formulaMismatch}`);
console.log(`pitch-class mismatches: ${pcMismatch}`);
console.log(`spelling differences from conventional: ${spellMismatch}  (* = root offered by KeySelector)`);
for (const [t, rows] of Object.entries(spellRows)) {
  console.log(`\n== ${t} (${rows.length} roots differ)`);
  for (const r of rows) console.log('  ' + r);
}
