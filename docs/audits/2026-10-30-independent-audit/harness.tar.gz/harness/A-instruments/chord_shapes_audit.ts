// Independent audit of what the fretboard draws for chords:
// getChordShapesWithFallback(buildChord(root, q)) for every quality x 12 roots,
// sorted nut-closest exactly as Fretboard.tsx does, then checked against an
// independent chord-tone oracle + physical/fingering rules.
// Run: cd <repo> && npx tsx <this file>
import { buildChord, CHORD_FORMULAS } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/constants/chords.ts';
import { getChordShapesWithFallback, CHORD_SHAPE_LIBRARY, getChordShapes } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/constants/guitarChordShapes.ts';
import { pcOf, mod12 } from './oracle.ts';

const OPEN = ['E', 'A', 'D', 'G', 'B', 'E'].map(pcOf); // 6th..1st
const FULL_FRETS = 15; // fretboardConstants.ts — highest drawable fret
// Independent chord-tone oracle (semitones mod 12) from chord-symbol definitions.
const ORACLE_CHORD: Record<string, number[]> = {
  major: [0, 4, 7], minor: [0, 3, 7], diminished: [0, 3, 6], augmented: [0, 4, 8],
  major6: [0, 4, 7, 9], minor6: [0, 3, 7, 9], major7: [0, 4, 7, 11], minor7: [0, 3, 7, 10],
  dominant7: [0, 4, 7, 10], diminished7: [0, 3, 6, 9], half_diminished7: [0, 3, 6, 10],
  augmented7: [0, 4, 8, 10], sus2: [0, 2, 7], sus4: [0, 5, 7], add9: [0, 2, 4, 7],
  minor_major7: [0, 3, 7, 11], power: [0, 7], dominant7sus4: [0, 5, 7, 10],
  major9: [0, 2, 4, 7, 11], minor9: [0, 2, 3, 7, 10], dominant9: [0, 2, 4, 7, 10],
  dominant7flat9: [0, 1, 4, 7, 10], dominant7sharp9: [0, 3, 4, 7, 10], dominant7flat5: [0, 4, 6, 10],
  dominant7sharp5: [0, 4, 8, 10], dominant7alt: [0, 1, 3, 4, 6, 8, 10],
  dominant11: [0, 2, 4, 5, 7, 10], major11: [0, 2, 4, 5, 7, 11], minor11: [0, 2, 3, 5, 7, 10],
  dominant9sharp11: [0, 2, 4, 6, 7, 10], dominant7sharp11: [0, 4, 6, 7, 10], major9sharp11: [0, 2, 4, 6, 7, 11],
  dominant13: [0, 2, 4, 5, 7, 9, 10], major13: [0, 2, 4, 5, 7, 9, 11], minor13: [0, 2, 3, 5, 7, 9, 10],
  dominant13flat9: [0, 1, 4, 7, 9, 10], dominant7flat13: [0, 4, 7, 8, 10], add11: [0, 4, 5, 7],
  six_nine: [0, 2, 4, 7, 9], minor_six_nine: [0, 2, 3, 7, 9], dominant9sus4: [0, 2, 5, 7, 10],
  sus2sus4: [0, 2, 5, 7], augmented_major7: [0, 4, 8, 11], major7flat5: [0, 4, 6, 11],
  major7sharp11: [0, 4, 6, 7, 11], diminished_major7: [0, 3, 6, 11],
  dominant7sharp5flat9: [0, 1, 4, 8, 10], dominant7flat5flat9: [0, 1, 4, 6, 10],
  dominant7sharp5sharp9: [0, 3, 4, 8, 10], dominant7flat5sharp9: [0, 3, 4, 6, 10],
};
const ROOTS = ['C', 'Db', 'D', 'Eb', 'E', 'F', 'F#', 'G', 'Ab', 'A', 'Bb', 'B'];
const toNote = (s: string) => ({ natural: s[0], accidental: s.slice(1) }) as any;

const stats = { combos: 0, shapes: 0, wrongNote: 0, noRoot: 0, beyond15: 0, beyond15Default: 0, fingerIssues: 0, barreIssues: 0, empty: 0, badgeVsBarre: 0, defaultBassNotRoot: 0 };
const ex: Record<string, string[]> = {};
const note = (k: string, s: string) => { (ex[k] ??= []); if (ex[k].length < 400) ex[k].push(s); };

for (const q of Object.keys(CHORD_FORMULAS)) {
  const or = ORACLE_CHORD[q];
  if (!or) { console.log('no oracle for', q); continue; }
  for (const r of ROOTS) {
    stats.combos++;
    const chord = buildChord(toNote(r), q as any);
    const rootPc = pcOf(r);
    const allowed = new Set(or.map((s) => mod12(rootPc + s)));
    const shapes = getChordShapesWithFallback(chord);
    const positionOf = ({ shape, baseFret }: any) => { let m = Infinity; for (const p of shape.strings) if (p.fret !== null) { const a = baseFret + p.fret; if (a > 0) m = Math.min(m, a); } return m === Infinity ? 0 : m; };
    const sorted = [...shapes].sort((a, b) => positionOf(a) - positionOf(b));
    if (sorted.length === 0) { stats.empty++; note('empty', `${r}${q}`); continue; }
    sorted.forEach(({ shape, baseFret }, idx) => {
      stats.shapes++;
      const tag = `${r} ${q} [${idx === 0 ? 'DEFAULT ' : ''}${shape.name} @${baseFret}] frets=${shape.strings.map((p) => (p.fret === null ? 'x' : baseFret + p.fret)).join(',')} fingers=${shape.strings.map((p) => p.finger ?? '-').join(',')}`;
      const sounding = shape.strings.map((p, i) => (p.fret === null ? null : { s: i, abs: baseFret + p.fret, pc: mod12(OPEN[i] + baseFret + p.fret), finger: p.finger }));
      const live = sounding.filter(Boolean) as { s: number; abs: number; pc: number; finger: any }[];
      if (live.some((n) => !allowed.has(n.pc))) { stats.wrongNote++; note('wrongNote', tag); }
      if (!live.some((n) => n.pc === rootPc)) { stats.noRoot++; note('noRoot', tag); }
      if (live.some((n) => n.abs > FULL_FRETS)) { stats.beyond15++; if (idx === 0) stats.beyond15Default++; note('beyond15', tag); }
      // Fingering plausibility (for fretted notes, abs > 0)
      const fretted = live.filter((n) => n.abs > 0);
      const probs: string[] = [];
      for (const n of fretted) if (n.finger === undefined || n.finger === 0) probs.push(`s${6 - n.s} fret ${n.abs} has no finger`);
      const byFinger = new Map<any, number[]>();
      for (const n of fretted) if (n.finger && n.finger !== 0) { const k = n.finger === 'bar' ? 1 : n.finger; (byFinger.get(k) ?? byFinger.set(k, []).get(k)!).push(n.abs); }
      for (const [f, frets] of byFinger) if (new Set(frets).size > 1) probs.push(`finger ${f} on two frets ${[...new Set(frets)].join('/')}`);
      const entries = [...byFinger.entries()].map(([f, frets]) => [Number(f), Math.min(...frets)] as const).sort((a, b) => a[0] - b[0]);
      for (let i = 1; i < entries.length; i++) if (entries[i][1] < entries[i - 1][1]) probs.push(`finger ${entries[i][0]} (fret ${entries[i][1]}) below finger ${entries[i - 1][0]} (fret ${entries[i - 1][1]})`);
      if (fretted.length) { const span = Math.max(...fretted.map((n) => n.abs)) - Math.min(...fretted.map((n) => n.abs)); if (span > 4) probs.push(`stretch ${span + 1} frets`); }
      if (fretted.filter((n) => n.finger !== 'bar').length > 4 && !byFinger.has(1)) probs.push('more than 4 fretted notes with no barre');
      if (probs.length) { stats.fingerIssues++; note('finger', `${tag}  -> ${probs.join('; ')}`); }
      // barreInfo consistency
      if (shape.barreInfo) {
        const bf = baseFret + shape.barreInfo.fret;
        const from = 6 - shape.barreInfo.fromString, to = 6 - shape.barreInfo.toString;
        const bprobs: string[] = [];
        for (let s = Math.min(from, to); s <= Math.max(from, to); s++) {
          const p = shape.strings[s];
          if (p.fret !== null && baseFret + p.fret < bf) bprobs.push(`s${6 - s} fretted below barre`);
        }
        for (const end of [from, to]) { const p = shape.strings[end]; if (p.fret === null || baseFret + p.fret !== bf) bprobs.push(`barre end s${6 - end} not at barre fret ${bf}`); }
        if (bf === 0) bprobs.push('barre at fret 0 (open position: overlay drawn on nut)');
        if (bprobs.length) { stats.barreIssues++; note('barre', `${tag} barre=${JSON.stringify(shape.barreInfo)} -> ${bprobs.join('; ')}`); }
        // anchor badge (lowest fretted abs) should equal barre fret
        const anchor = Math.min(...fretted.map((n) => n.abs));
        if (bf > 0 && anchor !== bf) { stats.badgeVsBarre++; note('badge', `${tag} anchor=${anchor} barre=${bf}`); }
      }
      if (idx === 0) {
        const lowest = live.reduce((a, b) => (b.s < a.s ? b : a));
        if (lowest.pc !== rootPc) { stats.defaultBassNotRoot++; note('bassNotRoot', tag); }
      }
    });
  }
}
// hand-library data quality: shapes that the wrong-note filter silently discards
let handTotal = 0, handDiscard = 0; const discardEx: string[] = [];
for (const [lib, shapes] of Object.entries(CHORD_SHAPE_LIBRARY)) {
  const qmap: Record<string, string> = { halfDiminished: 'half_diminished7', sixth: 'major6' };
  const q = qmap[lib] ?? lib; const or = ORACLE_CHORD[q]; if (!or) continue;
  for (const r of ['C', 'F', 'A']) {
    for (const e of getChordShapes(toNote(r), q)) {
      handTotal++;
      const ok = e.shape.strings.every((p, i) => p.fret === null || or.map((s) => mod12(pcOf(r) + s)).includes(mod12(OPEN[i] + e.baseFret + p.fret)));
      if (!ok) { handDiscard++; if (discardEx.length < 25) discardEx.push(`${r} ${q}: "${e.shape.name}" @${e.baseFret} frets=${e.shape.strings.map((p) => (p.fret === null ? 'x' : e.baseFret + p.fret)).join(',')}`); }
    }
  }
}
console.log(JSON.stringify(stats, null, 1));
for (const [k, v] of Object.entries(ex)) { console.log(`\n== ${k}`); for (const s of v) console.log('  ' + s); }
console.log(`\nHAND LIBRARY (roots C,F,A): ${handDiscard}/${handTotal} placed hand shapes sound a non-chord tone (silently filtered at runtime)`);
for (const s of discardEx) console.log('  ' + s);
