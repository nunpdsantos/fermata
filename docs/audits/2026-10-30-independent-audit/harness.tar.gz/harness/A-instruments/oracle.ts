// Independent music-theory oracle for Track A. Imports NOTHING from the app.
// Everything is derived from first principles (step patterns / rotations) or
// from explicitly written degree labels with conventions documented inline.

export const LETTERS = ['C', 'D', 'E', 'F', 'G', 'A', 'B'] as const;
export const LETTER_PC: Record<string, number> = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };
export const ACC_OFFSET: Record<string, number> = { '': 0, '#': 1, '##': 2, b: -1, bb: -2 };

export const mod12 = (n: number) => ((n % 12) + 12) % 12;
export function pcOf(name: string): number {
  const m = /^([A-G])(##|#|bb|b)?$/.exec(name);
  if (!m) throw new Error('bad note ' + name);
  return mod12(LETTER_PC[m[1]] + ACC_OFFSET[m[2] ?? '']);
}

// ---- Scale construction from first principles ------------------------------
// Major = W W H W W W H. Modes = rotations. Melodic minor (asc) = W H W W W W H.
// Harmonic minor = W H W W H A2 H.
function stepsToSemis(steps: number[]): number[] {
  const out = [0];
  for (let i = 0; i < steps.length - 1; i++) out.push(out[i] + steps[i]);
  return out;
}
function rotate(steps: number[], k: number) { return [...steps.slice(k), ...steps.slice(0, k)]; }
const MAJOR_STEPS = [2, 2, 1, 2, 2, 2, 1];
const MEL_STEPS = [2, 1, 2, 2, 2, 2, 1];
const HARM_STEPS = [2, 1, 2, 2, 1, 3, 1];
const mode = (steps: number[], k: number) => stepsToSemis(rotate(steps, k));

// Degree labels (letter-degree number + alteration), the conventional textbook
// spellings. Heptatonic scales: one letter per degree by construction.
// Non-heptatonic: conventions noted.
export interface OracleScale { semis: number[]; degrees: string[] }
function fromSemis7(semis: number[]): OracleScale {
  // 7-note: degree number i+1; alteration = semis - major-scale semis
  const maj = stepsToSemis(MAJOR_STEPS);
  const degrees = semis.map((s, i) => {
    const d = s - maj[i];
    const acc = d === 0 ? '' : d === -1 ? 'b' : d === -2 ? 'bb' : d === 1 ? '#' : d === 2 ? '##' : '?';
    return acc + String(i + 1);
  });
  return { semis, degrees };
}
function fromDegrees(degrees: string[]): OracleScale {
  const maj = stepsToSemis(MAJOR_STEPS);
  const semis = degrees.map((d) => {
    const m = /^(bb|b|##|#)?(\d)$/.exec(d)!;
    return maj[Number(m[2]) - 1] + ACC_OFFSET[m[1] ?? ''];
  });
  return { semis, degrees };
}

export const ORACLE_SCALES: Record<string, OracleScale> = {
  major: fromSemis7(mode(MAJOR_STEPS, 0)),
  dorian: fromSemis7(mode(MAJOR_STEPS, 1)),
  phrygian: fromSemis7(mode(MAJOR_STEPS, 2)),
  lydian: fromSemis7(mode(MAJOR_STEPS, 3)),
  mixolydian: fromSemis7(mode(MAJOR_STEPS, 4)),
  natural_minor: fromSemis7(mode(MAJOR_STEPS, 5)),
  locrian: fromSemis7(mode(MAJOR_STEPS, 6)),
  melodic_minor: fromSemis7(mode(MEL_STEPS, 0)),
  dorian_b2: fromSemis7(mode(MEL_STEPS, 1)),
  lydian_augmented: fromSemis7(mode(MEL_STEPS, 2)),
  lydian_dominant: fromSemis7(mode(MEL_STEPS, 3)),
  mixolydian_b6: fromSemis7(mode(MEL_STEPS, 4)),
  locrian_natural2: fromSemis7(mode(MEL_STEPS, 5)),
  altered: fromSemis7(mode(MEL_STEPS, 6)), // 1 b2 b3 b4 b5 b6 b7
  harmonic_minor: fromSemis7(mode(HARM_STEPS, 0)),
  phrygian_dominant: fromSemis7(mode(HARM_STEPS, 4)),
  // Other heptatonics, written as degree formulas (standard references):
  hungarian_minor: fromDegrees(['1', '2', 'b3', '#4', '5', 'b6', '7']),
  hungarian_major: fromDegrees(['1', '#2', '3', '#4', '5', '6', 'b7']),
  double_harmonic: fromDegrees(['1', 'b2', '3', '4', '5', 'b6', '7']),
  persian: fromDegrees(['1', 'b2', '3', '4', 'b5', 'b6', '7']),
  neapolitan_minor: fromDegrees(['1', 'b2', 'b3', '4', '5', 'b6', '7']),
  neapolitan_major: fromDegrees(['1', 'b2', 'b3', '4', '5', '6', '7']),
  // Pentatonic / hexatonic
  pentatonic_major: fromDegrees(['1', '2', '3', '5', '6']),
  pentatonic_minor: fromDegrees(['1', 'b3', '4', '5', 'b7']),
  blues: fromDegrees(['1', 'b3', '4', 'b5', '5', 'b7']), // convention: "flat five" blue note
  major_blues: fromDegrees(['1', '2', 'b3', '3', '5', '6']),
  hirajoshi: fromDegrees(['1', '2', 'b3', '5', 'b6']),
  in_sen: fromDegrees(['1', 'b2', '4', '5', 'b7']),
  iwato: fromDegrees(['1', 'b2', '4', 'b5', 'b7']),
  egyptian: fromDegrees(['1', '2', '4', '5', 'b7']),
  whole_tone: fromDegrees(['1', '2', '3', '#4', '#5', 'b7']), // b7 vs #6 both seen
  // Octatonic: common jazz spellings
  diminished_whole_half: fromDegrees(['1', '2', 'b3', '4', 'b5', 'b6', '6', '7']),
  diminished_half_whole: fromDegrees(['1', 'b2', '#2', '3', '#4', '5', '6', 'b7']),
  // Bebop (David Baker): parent mode + one chromatic passing tone
  bebop_dominant: fromDegrees(['1', '2', '3', '4', '5', '6', 'b7', '7']),
  bebop_major: fromDegrees(['1', '2', '3', '4', '5', '#5', '6', '7']),
  bebop_dorian: fromDegrees(['1', '2', 'b3', '3', '4', '5', '6', 'b7']),
  chromatic: fromDegrees(['1', '#1', '2', '#2', '3', '4', '#4', '5', '#5', '6', '#6', '7']),
};

// Spell a scale degree on a root: letter = root letter + (degreeNumber-1),
// accidental = whatever makes the pitch right. Returns null for > double acc.
export function spellDegree(root: string, degree: string): string | null {
  const rl = root[0];
  const rootPc = pcOf(root);
  const m = /^(bb|b|##|#)?(\d+)$/.exec(degree)!;
  const num = Number(m[2]);
  const maj = stepsToSemis(MAJOR_STEPS);
  const semis = maj[(num - 1) % 7] + ACC_OFFSET[m[1] ?? ''];
  const letter = LETTERS[(LETTERS.indexOf(rl as any) + num - 1) % 7];
  const diff = mod12(rootPc + semis - LETTER_PC[letter]);
  const acc = diff === 0 ? '' : diff === 1 ? '#' : diff === 2 ? '##' : diff === 11 ? 'b' : diff === 10 ? 'bb' : null;
  return acc === null ? null : letter + acc;
}

export function degreeNumber(degree: string): number {
  return Number(/(\d+)$/.exec(degree)![1]);
}

// MIDI: C4 = 60 (scientific pitch notation; A4 = 69 = 440 Hz)
export function midiOf(name: string, octave: number): number {
  // octave belongs to the LETTER (B#3 sounds as C4; Cb4 sounds as B3)
  const m = /^([A-G])(##|#|bb|b)?$/.exec(name)!;
  return 12 * (octave + 1) + LETTER_PC[m[1]] + ACC_OFFSET[m[2] ?? ''];
}
export const freqOfMidi = (m: number) => 440 * Math.pow(2, (m - 69) / 12);

// Major key signatures from first principles: count sharps/flats of the major scale.
export function majorKeySignature(tonic: string): { count: number; type: '#' | 'b' | '' ; accs: string[] } {
  const notes = ORACLE_SCALES.major.degrees.map((d) => spellDegree(tonic, d)!);
  const accs = notes.filter((n) => n.length > 1);
  const sharps = accs.filter((n) => n.includes('#'));
  const flats = accs.filter((n) => n.includes('b'));
  if (sharps.length && flats.length) throw new Error('mixed');
  // double accidentals count twice in signature terms
  const count = accs.reduce((s, n) => s + (n.length - 1), 0);
  return { count, type: sharps.length ? '#' : flats.length ? 'b' : '', accs };
}
export const SHARP_ORDER = ['F', 'C', 'G', 'D', 'A', 'E', 'B'];
export const FLAT_ORDER = ['B', 'E', 'A', 'D', 'G', 'C', 'F'];
