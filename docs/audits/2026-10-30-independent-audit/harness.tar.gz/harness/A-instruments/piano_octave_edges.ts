// Piano octave buttons C0..C8 (Piano.tsx:359): how many of a scale's notes (useKeyContext.scaleMidiNumbers,
// 1 octave) exist on the 88-key board (generateKeyboardKeys(0,8), MIDI 21..108)?
import { buildScale } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/constants/scales.ts';
import { getScaleNotesWithOctaves, getMidiNumber, generateKeyboardKeys } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/utils/pianoLayout.ts';
const keys = new Set(generateKeyboardKeys(0, 8).map((k) => k.midiNumber));
console.log(`keyboard keys: ${keys.size}, range ${Math.min(...keys)}..${Math.max(...keys)}`);
for (const oct of [0, 1, 7, 8]) for (const r of ['C', 'G', 'B']) {
  const p = getScaleNotesWithOctaves(buildScale({ natural: r, accidental: '' } as any, 'major').notes, oct);
  const m = p.map((n) => getMidiNumber(n, n.octave));
  console.log(`octave button C${oct}, ${r} major: ${m.filter((x) => keys.has(x)).length}/${m.length} scale keys exist on the board`);
}
