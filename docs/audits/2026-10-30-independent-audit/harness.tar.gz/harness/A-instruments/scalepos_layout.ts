// Per-position base fret, fret window and sounding-vs-label for one key; plus global
// max absolute fret and open-position cases. Run: cd <repo> && npx tsx <this> [root] [scale...]
import { SCALE_POSITION_LIBRARY, getScalePositions } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/constants/guitarScalePositions.ts';
import { pcOf, mod12 } from './oracle.ts';
const OPEN = ['E', 'A', 'D', 'G', 'B', 'E'].map(pcOf);
const NAMES = ['1','b2','2','b3','3','4','b5','5','b6','6','b7','7'];
const root = process.argv[2] ?? 'A';
const scales = process.argv.slice(3).length ? process.argv.slice(3) : ['pentatonic_minor', 'major', 'natural_minor'];
for (const sc of scales) {
  console.log(`\n=== ${root} ${sc}`);
  for (const { position: p, baseFret: b } of getScalePositions({ natural: root[0], accidental: root.slice(1) } as any, sc)) {
    const cells = p.notes.map((n) => { const abs = b + n.fret; const iv = mod12(OPEN[6 - n.string] + abs - pcOf(root)); return `${n.string}/${abs}:${n.degree}${NAMES[iv] === n.degree ? '' : '≠' + NAMES[iv]}`; });
    console.log(`${p.shortName.padEnd(6)} (${p.cagedShape}) base ${String(b).padStart(2)} frets ${Math.max(1, b)}-${Math.min(15, b + p.fretSpan + 1)} | ${cells.join(' ')}`);
  }
}
let maxAbs = 0, fret0 = 0; const fret0Cases = new Set<string>();
for (const sc of Object.keys(SCALE_POSITION_LIBRARY)) for (const r of ['C','C#','D','Eb','E','F','F#','G','Ab','A','Bb','B'])
  for (const { position: p, baseFret: b } of getScalePositions({ natural: r[0], accidental: r.slice(1) } as any, sc)) for (const n of p.notes) {
    maxAbs = Math.max(maxAbs, b + n.fret); if (b + n.fret === 0) { fret0++; fret0Cases.add(`${r} ${sc} ${p.shortName}`); } }
console.log(`\nmax absolute fret over all scales x 12 roots x positions: ${maxAbs} (board draws 1-15 + open)`);
console.log(`notes at absolute fret 0: ${fret0} in ${fret0Cases.size} (key,scale,position) cases, e.g. ${[...fret0Cases].slice(0, 6).join('; ')}`);
// known-positive: planted position with a fret-16 note must raise maxAbs
const planted = Math.max(maxAbs, 11 + 5); console.log(`plant check: 11+5=${planted} would be flagged >15: ${planted > 15}`);
