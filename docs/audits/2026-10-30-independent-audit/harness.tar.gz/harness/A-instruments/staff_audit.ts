// What the Explore staff (ChordWorkspace -> StaffNotation -> VexFlow) shows for a scale:
//   notes = getScaleNotesWithOctaves(scale.notes, 4), keySignature = getKeySignatureForScale(root, type),
//   every note with accidental != '' gets an explicit Accidental glyph, naturals get none.
// VexFlow places "c#/4" by LETTER + OCTAVE (tables.js keyProperties: line = (octave*7 - 28 + letterIndex)/2),
// i.e. scientific pitch where the octave belongs to the letter (Cb4 = B3, B#4 = C5).
// This script computes what a reader of the staff would read, and checks it against the oracle.
// Run: cd <repo> && npx tsx <this file>
import { buildScale, SCALE_FORMULAS } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/constants/scales.ts';
import { getScaleNotesWithOctaves, getVoicedChordNotes } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/utils/pianoLayout.ts';
import { getKeySignatureForScale, pitchedNoteToVexKey, getVexAccidental } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/utils/notationHelpers.ts';
import { buildChord, CHORD_FORMULAS } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/constants/chords.ts';
import { ORACLE_SCALES, spellDegree, midiOf, LETTERS, ACC_OFFSET, LETTER_PC, pcOf, mod12 } from './oracle.ts';

const ROOTS = ['C', 'C#', 'D', 'Eb', 'E', 'F', 'F#', 'G', 'Ab', 'A', 'Bb', 'B', 'Db', 'Gb'];
const KS = new Set(['C', 'C#', 'D', 'Eb', 'E', 'F', 'F#', 'G', 'Ab', 'A', 'Bb', 'B']);
const toNote = (s: string) => ({ natural: s[0], accidental: s.slice(1) }) as any;

// Independent key-signature content: letters altered, for a VexFlow sig string like "Eb" / "Cm".
function sigAccidentals(sig: string): Record<string, string> {
  const minor = sig.endsWith('m');
  const tonic = minor ? sig.slice(0, -1) : sig;
  const majorTonic = minor ? spellDegree(tonic, 'b3')! : tonic;
  const out: Record<string, string> = {};
  for (const d of ORACLE_SCALES.major.degrees) { const n = spellDegree(majorTonic, d)!; if (n.length > 1) out[n[0]] = n.slice(1); }
  return out;
}
// Parse vex key "cb/4" -> {letter, acc, octave}; staff step = octave*7 + letterIndex (VexFlow semantics)
function vexParse(k: string) { const [n, o] = k.split('/'); const letter = n[0].toUpperCase(); return { letter, acc: n.slice(1), octave: Number(o), step: Number(o) * 7 + LETTERS.indexOf(letter as any) }; }

// self-test of the reader model: G major, F# with sig G => no explicit accidental needed
if (JSON.stringify(sigAccidentals('G')) !== '{"F":"#"}' || Object.entries(sigAccidentals('Cm')).sort().join() !== 'A,b,B,b,E,b') throw new Error('sig oracle broken');

let cases = 0, octaveJump = 0, wrongRead = 0, redundant = 0, notAscending = 0;
const ex: Record<string, string[]> = {};
const push = (k: string, s: string) => ((ex[k] ??= []).length < 400 ? ex[k].push(s) : 0);
for (const type of Object.keys(SCALE_FORMULAS)) {
  for (const root of ROOTS) {
    cases++;
    const scale = buildScale(toNote(root), type as any);
    const pitched = getScaleNotesWithOctaves(scale.notes, 4);
    const sig = getKeySignatureForScale(scale.root, type);
    const sigAcc = sig ? sigAccidentals(sig) : {};
    const keys = pitched.map(pitchedNoteToVexKey);
    const parsed = keys.map(vexParse);
    // intended: ascending scale from root in octave 4 (root letter octave 4), oracle pitch
    const or = ORACLE_SCALES[type];
    const rootMidi = midiOf(root, 4);
    const intended = [...or.semis.map((s) => rootMidi + s), rootMidi + 12];
    // what VexFlow draws: sounding pitch of each drawn key (letter-octave semantics)
    const drawnMidi = parsed.map((p) => midiOf(p.letter + p.acc, p.octave));
    const jumps = drawnMidi.map((m, i) => m - intended[i]).filter((d) => d !== 0);
    const tag = `${KS.has(root) ? '*' : ' '}${root} ${type}`;
    if (jumps.length) { octaveJump++; push('octave', `${tag}: keys [${keys.join(' ')}] — ${drawnMidi.map((m, i) => (m === intended[i] ? '.' : (m > intended[i] ? '+' : '') + (m - intended[i]))).join(' ')}`); }
    for (let i = 1; i < parsed.length; i++) if (parsed[i].step < parsed[i - 1].step) { notAscending++; push('notAscending', `${tag}: ${keys[i - 1]} -> ${keys[i]}`); break; }
    // reader model: explicit accidental drawn iff getVexAccidental(note) != null; otherwise key sig applies
    pitched.forEach((n, i) => {
      const explicit = getVexAccidental(n);
      const shownAcc = explicit !== null ? explicit : (sigAcc[n.natural] ?? '');
      const readPc = mod12(LETTER_PC[n.natural] + ACC_OFFSET[shownAcc]);
      const truePc = pcOf(n.natural + n.accidental);
      if (readPc !== truePc) { wrongRead++; push('wrongRead', `${tag} (sig ${sig}): note ${n.natural}${n.accidental || '♮'} drawn without ♮ — reader sees ${n.natural}${shownAcc}`); }
      if (explicit !== null && sigAcc[n.natural] === explicit) { redundant++; }
    });
  }
}
console.log(`scale cases (type x root): ${cases}`);
console.log(`cases with a note drawn in the wrong octave (letter-octave mismatch at B/C): ${octaveJump}`);
console.log(`cases where staff positions do not ascend: ${notAscending}`);
console.log(`notes a reader would read WRONG (natural needed against key signature, none drawn): ${wrongRead}`);
console.log(`redundant accidentals (explicit glyph that the key signature already supplies): ${redundant}`);
for (const [k, v] of Object.entries(ex)) { console.log(`\n== ${k} (${v.length}${v.length === 40 ? '+' : ''} shown)`); for (const s of v) console.log('  ' + s); }

// Chord staff: getVoicedChordNotes(chord.notes, 4) with letter-octave semantics
let chordCases = 0, chordOct = 0; const chordEx: string[] = [];
for (const q of Object.keys(CHORD_FORMULAS)) for (const r of ['C', 'Db', 'D', 'Eb', 'E', 'F', 'F#', 'Gb', 'G', 'Ab', 'A', 'Bb', 'B', 'C#', 'Cb']) {
  chordCases++;
  const c = buildChord(toNote(r), q as any);
  const v = getVoicedChordNotes(c.notes, 4);
  const pcMidi = v.map((n) => 12 + n.octave * 12 + pcOf(n.natural + n.accidental)); // app's own (pitch-class octave) intent
  const drawn = v.map((n) => midiOf(n.natural + n.accidental, n.octave));
  if (drawn.some((m, i) => m !== pcMidi[i])) { chordOct++; if (chordEx.length < 15) chordEx.push(`${r}${q}: [${v.map(pitchedNoteToVexKey).join(' ')}] intended midi ${pcMidi.join(',')} drawn ${drawn.join(',')}`); }
}
console.log(`\nchord staff cases: ${chordCases}; chords with a note drawn an octave off: ${chordOct}`);
for (const s of chordEx) console.log('  ' + s);
