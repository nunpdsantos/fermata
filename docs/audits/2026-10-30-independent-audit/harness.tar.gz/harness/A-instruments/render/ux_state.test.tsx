// UX/state checks on REAL components: circle minor-variant stale position, KeySelector with
// circle-only spellings, fretboard vs inversion, slash-chord bass on fretboard.
import './setup.ts';
import { it, vi } from 'vitest';
import { render, cleanup, fireEvent, act } from '@testing-library/react';
import { writeFileSync } from 'node:fs';
vi.mock('/Users/nunosantos/Documents/Base/Music/new_music_app/src/hooks/useAudio.ts', () => ({ useAudio: () => ({ noteOn: vi.fn().mockResolvedValue(60), noteOff: vi.fn() }) }));
vi.mock('/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/services/audio.ts', async (orig) => ({ ...(await orig() as object), resumeAudio: vi.fn(), playChordVoiced: vi.fn() }));
import { Fretboard } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/components/instruments/Fretboard.tsx';
import { CircleOfFifths } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/components/theory/CircleOfFifths.tsx';
import { KeySelector } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/components/navigation/KeySelector.tsx';
import { useAppStore } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/state/store.ts';
import { buildChord } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/constants/chords.ts';
const OUT = '/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/A-instruments/out_ux_state.txt';
const L: string[] = [];
const chips = (c: HTMLElement) => [...c.querySelectorAll('[role="tab"]')].map((t) => `${t.textContent}${t.getAttribute('aria-selected') === 'true' ? '[x]' : ''}`).join(' ');
it('ux state', () => {
  const errSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
  // (a) A natural minor, pick Box/Pos 5, then click the circle's "Harmonic" minor-variant button
  useAppStore.setState({ selectedKey: { natural: 'A', accidental: '' }, selectedScale: 'natural_minor', selectedChord: null, guitarScalePosition: null, guitarTuningId: 'standard', activeNotes: new Set(), exerciseInputActive: false });
  let r = render(<><CircleOfFifths /><Fretboard /></>);
  fireEvent.click([...r.container.querySelectorAll('[role="tab"]')].find((t) => /Pos 5/.test(t.textContent ?? ''))!);
  L.push(`(a) after choosing Pos 5 in A natural minor: ${chips(r.container)} | store guitarScalePosition=${useAppStore.getState().guitarScalePosition}`);
  fireEvent.click([...r.container.querySelectorAll('button')].find((b) => b.textContent === 'Harmonic')!);
  L.push(`    after circle "Harmonic" button: scale=${useAppStore.getState().selectedScale} guitarScalePosition=${useAppStore.getState().guitarScalePosition} chips: ${chips(r.container)}`);
  L.push(`    lit position dots: ${[...r.container.querySelectorAll('[data-fret]')].filter((c) => (c.textContent ?? '').trim()).length} (full-neck view shows ~40+, a position ~16)`);
  // circle major click with a stale position index
  fireEvent.click(r.container.querySelector('g[aria-label="E major"]')!);
  L.push(`    after clicking "E major" segment: key=${useAppStore.getState().selectedKey.natural} scale=${useAppStore.getState().selectedScale} guitarScalePosition=${useAppStore.getState().guitarScalePosition} chips: ${chips(r.container)}`);
  cleanup();
  // (b) KeySelector after the circle picks Db / Gb
  for (const seg of ['Db major', 'Gb major', 'Eb minor']) {
    useAppStore.setState({ selectedKey: { natural: 'C', accidental: '' }, selectedScale: 'major' });
    r = render(<><CircleOfFifths /><KeySelector /></>);
    fireEvent.click(r.container.querySelector(`g[aria-label="${seg}"]`)!);
    const pressed = [...r.container.querySelectorAll('button[data-root]')].filter((b) => b.getAttribute('aria-pressed') === 'true').map((b) => b.getAttribute('data-root'));
    const k = useAppStore.getState().selectedKey;
    L.push(`(b) circle "${seg}" -> store key ${k.natural}${k.accidental}; KeySelector root buttons pressed: [${pressed.join(',')}]`);
    cleanup();
  }
  // (d) Fretboard ignores chord inversion
  const C = buildChord({ natural: 'C', accidental: '' } as any, 'major');
  const snap = (inv: number) => { useAppStore.setState({ selectedChord: C, chordInversion: inv, guitarScalePosition: null }); const x = render(<Fretboard />); const s = [...x.container.querySelectorAll('[data-fret]')].filter((c) => (c.textContent ?? '').trim()).map((c) => `${c.getAttribute('data-string-row')}:${c.getAttribute('data-fret')}`).join(' '); cleanup(); return s; };
  const s0 = snap(0), s1 = snap(1), s2 = snap(2);
  L.push(`(d) C major fretboard dots inv0=[${s0}] inv1=[${s1}] inv2=[${s2}] identical=${s0 === s1 && s1 === s2}`);
  // (e) slash chord with non-chord-tone bass: Dm7/G
  const Dm7G = { ...buildChord({ natural: 'D', accidental: '' } as any, 'minor7'), bassNote: { natural: 'G', accidental: '' } } as any;
  useAppStore.setState({ selectedChord: Dm7G, chordInversion: 0 });
  r = render(<Fretboard />);
  const OPEN = [4, 9, 2, 7, 11, 4];
  const dots = [...r.container.querySelectorAll('[data-fret]')].filter((c) => (c.textContent ?? '').trim()).map((c) => (OPEN[Number(c.getAttribute('data-string-row'))] + Number(c.getAttribute('data-fret'))) % 12);
  const opens = [...r.container.querySelectorAll('[aria-label$="open string"]')].filter((e) => e.querySelector('div.rounded-full')).map((e) => e.getAttribute('aria-label'));
  L.push(`(e) Dm7/G on fretboard: fretted pcs [${dots.join(',')}], sounding open strings [${opens.join(', ')}]; G (pc 7) present: ${dots.includes(7) || opens.some((o) => o?.startsWith('G'))}`);
  cleanup();
  errSpy.mockRestore();
  writeFileSync(OUT, L.join('\n'));
});
