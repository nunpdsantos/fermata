import './setup.ts';
import { it, vi } from 'vitest';
import { render } from '@testing-library/react';
vi.mock('/Users/nunosantos/Documents/Base/Music/new_music_app/src/hooks/useAudio.ts', () => ({ useAudio: () => ({ noteOn: vi.fn().mockResolvedValue(60), noteOff: vi.fn() }) }));
import { Fretboard } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/components/instruments/Fretboard.tsx';
import { useAppStore } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/state/store.ts';
it('smoke', () => {
  useAppStore.setState({ selectedKey: { natural: 'C', accidental: '' }, selectedScale: 'major', selectedChord: null, guitarScalePosition: null, guitarTuningId: 'standard', activeNotes: new Set() });
  const { container } = render(<Fretboard />);
  const cells = container.querySelectorAll('[data-fret][data-string-row]');
  const lit = [...cells].filter((c) => (c.textContent ?? '').trim() !== '');
  console.log('cells', cells.length, 'lit', lit.length);
  for (const c of lit.slice(0, 4)) console.log(c.getAttribute('data-string-row'), c.getAttribute('data-fret'), c.textContent, (c.lastElementChild as HTMLElement).getAttribute('style'));
  const rows = container.querySelectorAll('[data-string-row="0"]')[0].parentElement!.parentElement!;
  console.log('ROW', rows.children.length, (rows.lastElementChild as HTMLElement).outerHTML.slice(0, 400));
});
