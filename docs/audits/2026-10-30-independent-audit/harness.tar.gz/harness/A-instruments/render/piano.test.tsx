// Render the REAL <Piano/> for every scale type x root (baseOctave 4, 1 octave) and compare
// the highlighted keys (aria-label = label+octave; highlight detected from inline style) with the oracle.
import './setup.ts';
import { it, vi } from 'vitest';
import { render, cleanup } from '@testing-library/react';
import { writeFileSync } from 'node:fs';
vi.mock('/Users/nunosantos/Documents/Base/Music/new_music_app/src/hooks/useAudio.ts', () => ({ useAudio: () => ({ noteOn: vi.fn().mockResolvedValue(60), noteOff: vi.fn() }) }));
import { Piano } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/components/instruments/Piano.tsx';
import { useAppStore } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/state/store.ts';
import { ORACLE_SCALES, spellDegree, pcOf, mod12, degreeNumber } from '../oracle.ts';
const OUT = '/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/A-instruments/out_piano.txt';
const SPEC: Record<number, string> = { 1: '#60a5fa', 2: '#a78bfa', 3: '#f472b6', 4: '#34d399', 5: '#fbbf24', 6: '#fb923c', 7: '#f87171' };
const ROOTS = ['C', 'C#', 'D', 'Eb', 'E', 'F', 'F#', 'G', 'Ab', 'A', 'Bb', 'B'];
it('piano', () => {
  const errSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
  const L: string[] = []; const agg: Record<string, { missing: number; extra: number; label: number; colour: number; ex: string[] }> = {};
  let renders = 0; const crashes = new Set<string>(); let keyCount = -1;
  for (const scale of Object.keys(ORACLE_SCALES)) for (const root of ROOTS) {
    useAppStore.setState({ selectedKey: { natural: root[0], accidental: root.slice(1) } as any, selectedScale: scale as any, selectedChord: null, baseOctave: 4, scaleOctaves: 1, activeNotes: new Set(), exerciseInputActive: false, instrument: 'piano' });
    let c: HTMLElement;
    try { ({ container: c } = render(<Piano />)); } catch (e) { crashes.add(scale); cleanup(); continue; }
    renders++;
    const keys = [...c.querySelectorAll('[aria-label]')].filter((e) => /^[A-G](##|#|bb|b)?-?\d$/.test(e.getAttribute('aria-label') ?? ''));
    if (keyCount < 0) keyCount = keys.length;
    const or = ORACLE_SCALES[scale]; const rootPc = pcOf(root); const rootMidi = 12 + 4 * 12 + rootPc;
    const expMidi = new Map<number, { name: string | null; deg: number }>();
    or.semis.forEach((s, i) => expMidi.set(rootMidi + s, { name: spellDegree(root, or.degrees[i]), deg: degreeNumber(or.degrees[i]) }));
    expMidi.set(rootMidi + 12, { name: root, deg: 1 });
    const a = (agg[scale] ??= { missing: 0, extra: 0, label: 0, colour: 0, ex: [] });
    // physical midi of each key: keys are rendered in generateKeyboardKeys order: whites then blacks? use index map via aria octave + pc of physical position
    for (const k of keys) {
      const style = ((k.getAttribute('style') ?? '') + ' ' + ((k.firstElementChild as HTMLElement | null)?.getAttribute('style') ?? '')).toLowerCase();
      const lit = Object.values(SPEC).some((rgb) => style.includes(rgb)) || /var\(--accent\)/.test(style);
      const labelText = (k.textContent ?? '').trim();
      const [, name, oct] = /^([A-G](?:##|#|bb|b)?)(-?\d)$/.exec(k.getAttribute('aria-label')!)!;
      const midi = 12 + Number(oct) * 12 + pcOf(name); // aria octave is the PHYSICAL key's octave (PianoKey.tsx comment)
      const exp = expMidi.get(midi);
      if (exp && !lit) { a.missing++; if (a.ex.length < 3) a.ex.push(`${root}: ${name}${oct} not lit`); }
      if (!exp && lit) { a.extra++; if (a.ex.length < 3) a.ex.push(`${root}: ${name}${oct} lit`); }
      if (exp && lit) {
        if (exp.name && name !== exp.name) { a.label++; if (a.ex.length < 3) a.ex.push(`${root}: aria ${name}${oct} expected ${exp.name}`); }
        const deg = Number(Object.entries(SPEC).find(([, rgb]) => style.includes(rgb))?.[0] ?? 0);
        if (deg !== exp.deg) a.colour++;
      }
    }
    cleanup();
  }
  errSpy.mockRestore();
  L.push(`renders ${renders}; keys per render ${keyCount}; crashes: ${[...crashes].join(', ')}`);
  L.push('scale: missing-lit | extra-lit | label!=conventional | colour!=function colour');
  for (const [s, v] of Object.entries(agg)) L.push(`${s.padEnd(22)} ${v.missing} | ${v.extra} | ${v.label} | ${v.colour}  ${v.ex.join('; ')}`);
  writeFileSync(OUT, L.join('\n'));
});
