// Scale-position view: are authored fret-0 notes drawn? Are open-string dots shown for a position far from the nut?
import './setup.ts';
import { it, vi } from 'vitest';
import { render, cleanup } from '@testing-library/react';
import { writeFileSync } from 'node:fs';
vi.mock('/Users/nunosantos/Documents/Base/Music/new_music_app/src/hooks/useAudio.ts', () => ({ useAudio: () => ({ noteOn: vi.fn().mockResolvedValue(60), noteOff: vi.fn() }) }));
import { Fretboard } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/components/instruments/Fretboard.tsx';
import { useAppStore } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/state/store.ts';
import { getScalePositions } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/constants/guitarScalePositions.ts';
it('open in position', () => {
  const L: string[] = [];
  for (const [root, scale, idx] of [['E', 'pentatonic_minor', 0], ['A', 'major', 1], ['G', 'major', 0]] as const) {
    const placed = getScalePositions({ natural: root, accidental: '' } as any, scale)[idx];
    useAppStore.setState({ selectedKey: { natural: root, accidental: '' } as any, selectedScale: scale, selectedChord: null, guitarScalePosition: idx, guitarTuningId: 'standard', activeNotes: new Set(), exerciseInputActive: false });
    const { container } = render(<Fretboard />);
    const fretDots = [...container.querySelectorAll('[data-fret]')].filter((c) => (c.textContent ?? '').trim());
    const openDots = [...container.querySelectorAll('[aria-label$="open string"]')].filter((e) => e.querySelector('div.rounded-full')).map((e) => e.textContent);
    const frets = [...container.querySelectorAll('[data-string-row="0"][data-fret]')].map((c) => c.getAttribute('data-fret'));
    L.push(`${root} ${scale} chip ${idx + 1} (${placed.position.shortName}, base fret ${placed.baseFret}): authored notes ${placed.position.notes.length} (at abs fret 0: ${placed.position.notes.filter((n) => placed.baseFret + n.fret === 0).length}); drawn position dots ${fretDots.length}; visible frets ${frets[frets.length - 1]}-${frets[0]}; open-string column dots (unlabelled degree, plain note name): [${openDots.join(',')}]`);
    cleanup();
  }
  writeFileSync('/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/A-instruments/out_open_in_position.txt', L.join('\n'));
});
