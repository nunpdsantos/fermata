// Render REAL ScaleComparison for every (selected scale A, comparison scale B) pair in key C and
// collect slots whose fixed chromatic label (1 b2 2 b3 3 4 b5 5 b6 6 b7 7) contradicts the note shown.
import './setup.ts';
import { it, vi } from 'vitest';
import { render, cleanup } from '@testing-library/react';
import { writeFileSync } from 'node:fs';
import { ScaleComparison } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/components/theory/ScaleComparison.tsx';
import { useAppStore } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/state/store.ts';
import { SCALE_FORMULAS } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/constants/scales.ts';
const OUT = '/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/A-instruments/out_scale_comparison.txt';
const LETTERS = ['C', 'D', 'E', 'F', 'G', 'A', 'B'];
it('scale comparison', () => {
  const errSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
  const L: string[] = []; let pairs = 0, crash = 0, contradictions = 0; const ex = new Set<string>();
  const types = Object.keys(SCALE_FORMULAS);
  for (const a of types) for (const b of types) {
    if (a === b) continue;
    useAppStore.setState({ selectedKey: { natural: 'C', accidental: '' }, selectedScale: a as any, comparisonScale: b as any, selectedChord: null, exerciseInputActive: false });
    let c: HTMLElement;
    try { ({ container: c } = render(<ScaleComparison />)); } catch { crash++; cleanup(); continue; }
    pairs++;
    const text = c.textContent ?? '';
    // each slot renders label then note names; scan the DOM for elements whose text is a chromatic label followed by notes
    const slots = [...c.querySelectorAll('div')].filter((d) => d.children.length === 2 && /^(1|b2|2|b3|3|4|b5|5|b6|6|b7|7)$/.test((d.children[1].textContent ?? '').trim()));
    if (pairs === 1) L.push(`slots found in first render: ${slots.length} (expect 24)`);
    for (const s of slots) {
      const label = (s.children[1].textContent ?? '').trim();
      const notes = [(s.children[0].textContent ?? '').trim()].filter((t) => /^[A-G](##|#|bb|b)?$/.test(t));
      const num = Number(label.replace(/[b#]/g, ''));
      for (const n of notes) if (n[0] !== LETTERS[(num - 1) % 7]) { contradictions++; ex.add(`C ${a} vs ${b}: slot "${label}" shows ${n}`); }
    }
    void text;
    cleanup();
  }
  errSpy.mockRestore();
  L.push(`pairs rendered: ${pairs} (crashed: ${crash}); label/note contradictions: ${contradictions}; distinct: ${ex.size}`);
  const pick = [...ex].filter((e) => /^C (major|natural_minor|dorian|mixolydian) vs (lydian|lydian_augmented|lydian_dominant|whole_tone|hungarian_minor|blues|altered)/.test(e));
  L.push(...pick.slice(0, 30));
  writeFileSync(OUT, L.join('\n'));
});
