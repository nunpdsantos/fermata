// Exercise instrument-input mode: does the guitar fretboard show the learner's toggled notes?
import './setup.ts';
import { it, vi } from 'vitest';
import { render, cleanup } from '@testing-library/react';
import { writeFileSync } from 'node:fs';
vi.mock('/Users/nunosantos/Documents/Base/Music/new_music_app/src/hooks/useAudio.ts', () => ({ useAudio: () => ({ noteOn: vi.fn().mockResolvedValue(60), noteOff: vi.fn() }) }));
import { Fretboard } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/components/instruments/Fretboard.tsx';
import { Piano } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/components/instruments/Piano.tsx';
import { useAppStore } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/state/store.ts';
it('exercise input', () => {
  const L: string[] = [];
  const toggled = [{ natural: 'C', accidental: '', octave: 4 }, { natural: 'E', accidental: '', octave: 4 }, { natural: 'G', accidental: '', octave: 4 }] as any;
  for (const [mode, hl] of [['exercise, C-E-G toggled', toggled], ['exercise, nothing toggled', []]] as const) {
    useAppStore.setState({ selectedKey: { natural: 'D', accidental: '' }, selectedScale: 'major', selectedChord: null, guitarScalePosition: null, guitarTuningId: 'standard', activeNotes: new Set(), exerciseInputActive: true, highlightedNotes: hl as any, baseOctave: 4 });
    const f = render(<Fretboard />);
    const fdots = [...f.container.querySelectorAll('[data-fret]')].filter((c) => (c.textContent ?? '').trim()).length;
    const fopen = [...f.container.querySelectorAll('[aria-label$="open string"]')].filter((e) => e.querySelector('div.rounded-full')).length;
    cleanup();
    const p = render(<Piano />);
    const plit = [...p.container.querySelectorAll('[aria-label]')].filter((k) => /^[A-G]#?\d$/.test(k.getAttribute('aria-label') ?? '') && /#[0-9a-f]{6}|var\(--accent\)/i.test(((k.getAttribute('style') ?? '') + ((k.firstElementChild as HTMLElement | null)?.getAttribute('style') ?? '')).replace(/var\(--piano[^)]*\)/g, ''))).length;
    cleanup();
    L.push(`${mode}: fretboard dots ${fdots} (+${fopen} open-string dots); piano highlighted keys ${plit}`);
  }
  // control: Explore mode (not exercise) D major — fretboard must show dots (proves detector)
  useAppStore.setState({ exerciseInputActive: false, highlightedNotes: [] });
  const f = render(<Fretboard />);
  L.push(`control (Explore, D major): fretboard dots ${[...f.container.querySelectorAll('[data-fret]')].filter((c) => (c.textContent ?? '').trim()).length}`);
  cleanup();
  writeFileSync('/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/A-instruments/out_exercise_input.txt', L.join('\n'));
});
