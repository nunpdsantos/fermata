// Render the real StaffNotation (VexFlow 5) in jsdom with the exact props ChordWorkspace passes,
// and read back the SVG: which accidental glyphs are drawn, and the vertical order of noteheads.
import './setup.ts';
import { it, expect } from 'vitest';
import { render, waitFor, cleanup } from '@testing-library/react';
import { writeFileSync } from 'node:fs';
import { StaffNotation } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/components/notation/StaffNotation.tsx';
import { buildScale } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/constants/scales.ts';
import { getScaleNotesWithOctaves } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/utils/pianoLayout.ts';
import { getKeySignatureForScale } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/utils/notationHelpers.ts';
const OUT = '/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/A-instruments/out_staff_vexflow.txt';
(globalThis as any).ResizeObserver = class { observe() {} disconnect() {} };
const GLYPH: Record<string, string> = { '': 'flat', '': 'natural', '': 'sharp', '': 'dblsharp', '': 'dblflat' };
it('vexflow staff', async () => {
  const lines: string[] = [];
  for (const [r, t] of [['C', 'harmonic_minor'], ['C', 'melodic_minor'], ['Eb', 'major'], ['C#', 'major'], ['Ab', 'natural_minor']] as const) {
    const scale = buildScale({ natural: r[0], accidental: r.slice(1) } as any, t as any);
    const notes = getScaleNotesWithOctaves(scale.notes, 4);
    const sig = getKeySignatureForScale(scale.root, t) ?? undefined;
    const { container } = render(<StaffNotation notes={notes} keySignature={sig} width={700} height={130} />);
    await waitFor(() => expect(container.querySelectorAll('svg g.vf-stavenote').length).toBeGreaterThan(0), { timeout: 15000 });
    await new Promise((r) => setTimeout(r, 300));
    const svg = container.querySelector('svg')!;
    lines.push('   raw: ' + svg.outerHTML.length + ' chars');
    const texts = [...svg.querySelectorAll('text')].map((e) => e.textContent ?? '');
    const accs = texts.map((s) => [...s].map((ch) => GLYPH[ch]).filter(Boolean).join('+')).filter(Boolean);
    const noteGroups = [...svg.querySelectorAll('g.vf-stavenote')];
    const ys = noteGroups.map((g) => { const h = g.querySelector('.vf-notehead text, .vf-notehead path, text'); return h ? Number(h.getAttribute('y')) : NaN; });
    lines.push(`${r} ${t}: sig=${sig} notes=[${notes.map((n) => n.natural + n.accidental + n.octave).join(' ')}]`);
    lines.push(`   accidental glyphs drawn in document order (key signature first): ${accs.join(', ')}`);
    lines.push(`   notehead y (smaller = higher on staff): ${ys.join(', ')}`);
    cleanup();
  }
  writeFileSync(OUT, lines.join('\n'));
});
