// Alternate tuning + selected chord: what does the fretboard draw?
import './setup.ts';
import { it, vi } from 'vitest';
import { render, cleanup } from '@testing-library/react';
import { writeFileSync } from 'node:fs';
vi.mock('/Users/nunosantos/Documents/Base/Music/new_music_app/src/hooks/useAudio.ts', () => ({ useAudio: () => ({ noteOn: vi.fn().mockResolvedValue(60), noteOff: vi.fn() }) }));
import { Fretboard } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/components/instruments/Fretboard.tsx';
import { useAppStore } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/state/store.ts';
import { buildChord } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/constants/chords.ts';
it('alt tuning chord', () => {
  const L: string[] = [];
  const OPEN: Record<string, number[]> = { 'drop-d': [2, 9, 2, 7, 11, 4], standard: [4, 9, 2, 7, 11, 4], dadgad: [2, 9, 2, 7, 9, 2] };
  for (const tid of ['standard', 'drop-d', 'dadgad']) {
    useAppStore.setState({ selectedKey: { natural: 'D', accidental: '' }, selectedScale: 'major', selectedChord: buildChord({ natural: 'C', accidental: '' } as any, 'major'), guitarScalePosition: null, guitarTuningId: tid, activeNotes: new Set(), exerciseInputActive: false });
    const { container } = render(<Fretboard />);
    const pcs = new Set([...container.querySelectorAll('[data-fret]')].filter((c) => (c.textContent ?? '').trim()).map((c) => (OPEN[tid][Number(c.getAttribute('data-string-row'))] + Number(c.getAttribute('data-fret'))) % 12));
    const text = container.textContent ?? '';
    L.push(`${tid}: chord C major selected (key D major). Pitch classes drawn: {${[...pcs].sort((a, b) => a - b).join(',')}}  (C chord = {0,4,7}; D major scale = {1,2,4,6,7,9,11}); any notice about chords being unavailable: ${/standard tuning|not available|unavailable/i.test(text)}`);
    cleanup();
  }
  writeFileSync('/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/A-instruments/out_alt_tuning_chord.txt', L.join('\n'));
});
