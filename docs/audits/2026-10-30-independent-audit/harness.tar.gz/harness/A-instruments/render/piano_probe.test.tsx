import './setup.ts';
import { it, vi } from 'vitest';
import { render } from '@testing-library/react';
import { appendFileSync } from 'node:fs';
vi.mock('/Users/nunosantos/Documents/Base/Music/new_music_app/src/hooks/useAudio.ts', () => ({ useAudio: () => ({ noteOn: vi.fn().mockResolvedValue(60), noteOff: vi.fn() }) }));
import { Piano } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/components/instruments/Piano.tsx';
import { useAppStore } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/state/store.ts';
it('probe', () => {
  useAppStore.setState({ selectedKey: { natural: 'C', accidental: '' } as any, selectedScale: 'major', selectedChord: null, baseOctave: 4, scaleOctaves: 1, activeNotes: new Set(), exerciseInputActive: false });
  const { container } = render(<Piano />);
  for (const l of ['C4', 'D4', 'C#4', 'B4', 'C5', 'D5']) { const e = container.querySelector(`[aria-label="${l}"]`); appendFileSync('/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/A-instruments/out_piano_probe.txt', l + ' ' + (e?.outerHTML.slice(0, 700) ?? 'NONE') + '\n'); }
});
