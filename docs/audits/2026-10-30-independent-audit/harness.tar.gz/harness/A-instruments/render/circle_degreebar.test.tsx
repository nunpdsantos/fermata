// Renders the REAL CircleOfFifths and ScaleDegreeBar for every scale type x root and
// compares centre key name + key-signature text, selected segment and Roman numerals
// (circle), and the degree label / note name pairs (degree bar) with the oracle.
import './setup.ts';
import { it, vi } from 'vitest';
import { render, cleanup, act } from '@testing-library/react';
import { writeFileSync } from 'node:fs';
vi.mock('/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/services/audio.ts', () => ({ resumeAudio: vi.fn(), playChordVoiced: vi.fn() }));
import { CircleOfFifths } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/components/theory/CircleOfFifths.tsx';
import { ScaleDegreeBar } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/components/theory/ScaleDegreeBar.tsx';
import { useAppStore } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/state/store.ts';
import { ORACLE_SCALES, spellDegree, majorKeySignature, pcOf, mod12, degreeNumber } from '../oracle.ts';

const OUT = '/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/A-instruments/out_circle_degreebar.txt';
const ROOTS = ['C', 'C#', 'D', 'Eb', 'E', 'F', 'F#', 'G', 'Ab', 'A', 'Bb', 'B', 'Db', 'Gb'];
const KS = new Set(ROOTS.slice(0, 12));
// Parent-key rule (conventional key signature) per scale type; undefined = no standard signature.
const PARENT: Record<string, string | undefined> = {
  major: '1', pentatonic_major: '1', major_blues: '1',
  natural_minor: 'b3', harmonic_minor: 'b3', melodic_minor: 'b3', pentatonic_minor: 'b3', blues: 'b3',
  dorian: 'b7', phrygian: 'b6', lydian: '5', mixolydian: '4', locrian: 'b2',
};
const MINORISH = new Set(['natural_minor', 'harmonic_minor', 'melodic_minor', 'pentatonic_minor', 'blues', 'dorian', 'phrygian', 'locrian']);
const ROMAN = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII'];
function triadNumerals(semis: number[]): string[] {
  return semis.map((s, i) => {
    const t = mod12(semis[(i + 2) % 7] - s), f = mod12(semis[(i + 4) % 7] - s);
    const q = t === 4 && f === 7 ? 'M' : t === 3 && f === 7 ? 'm' : t === 3 && f === 6 ? 'd' : t === 4 && f === 8 ? 'A' : '?';
    const r = ROMAN[i];
    return q === 'M' ? r : q === 'm' ? r.toLowerCase() : q === 'd' ? r.toLowerCase() + '°' : q === 'A' ? r + '+' : r + '?';
  });
}
const sigText = (count: number, type: string) => (count === 0 ? 'no ♯/♭' : count === 6 ? '6♯/6♭' : `${count}${type === '#' ? '♯' : '♭'}`);

it('circle + degree bar', () => {
  const errSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
  const L: string[] = [];
  const crashes = new Set<string>();
  let circleCases = 0, sigWrong = 0, sigNA = 0, numeralWrong = 0, numeralCases = 0, centreName = 0;
  let barCases = 0, barMismatch = 0, barMixedNotation = 0;
  const sigEx: string[] = [], numEx: string[] = [], barEx: string[] = [], sigByType: Record<string, number> = {};
  for (const scale of Object.keys(ORACLE_SCALES)) {
    for (const root of ROOTS) {
      useAppStore.setState({ selectedKey: { natural: root[0], accidental: root.slice(1) } as any, selectedScale: scale as any, selectedChord: null, selectedDegree: null, exerciseInputActive: false });
      let c: HTMLElement;
      try { ({ container: c } = render(<><CircleOfFifths /><ScaleDegreeBar /></>)); } catch (e) { crashes.add(`${scale}: ${(e as Error).message}`); cleanup(); continue; }
      circleCases++;
      const focusedOnMount = document.activeElement?.getAttribute('aria-label') ?? null;
      if (circleCases === 1) L.push(`element focused right after mount: ${focusedOnMount}`);
      act(() => { (document.activeElement as HTMLElement | null)?.blur(); });
      const or = ORACLE_SCALES[scale];
      const tag = `${KS.has(root) ? '*' : ' '}${root} ${scale}`;
      // --- centre text
      const texts = [...c.querySelectorAll('svg > text')].map((t) => t.textContent ?? '');
      const centreKey = texts[texts.length - 2], centreSig = texts[texts.length - 1];
      const rule = PARENT[scale];
      if (rule) {
        const parent = spellDegree(root, rule)!;
        const ks = majorKeySignature(parent);
        const exp = sigText(ks.count, ks.type);
        if (centreSig !== exp) { sigWrong++; sigByType[scale] = (sigByType[scale] ?? 0) + 1; if (sigEx.length < 60) sigEx.push(`${tag}: centre "${centreKey} · ${centreSig}" — conventional signature ${exp} (parent ${parent} major)`); }
        const expName = root + (MINORISH.has(scale) && ['natural_minor', 'harmonic_minor', 'melodic_minor'].includes(scale) ? 'm' : '');
        if (!['natural_minor', 'harmonic_minor', 'melodic_minor', 'major'].includes(scale) && centreKey === root) centreName++;
        void expName;
      } else { sigNA++; }
      // --- numerals on major ring
      if (or.semis.length === 7) {
        numeralCases++;
        const expNum = triadNumerals(or.semis);
        const segs = [...c.querySelectorAll('g[aria-label$=" major"]')];
        const shown = new Map<number, string>();
        for (const g of segs) { const label = g.getAttribute('aria-label')!.replace(' major', ''); const t = g.querySelectorAll('text'); if (t.length > 1) shown.set(pcOf(label), t[1].textContent ?? ''); }
        const diffs: string[] = [];
        or.semis.forEach((s, i) => { const pc = mod12(pcOf(root) + s); const got = shown.get(pc); if (got !== expNum[i]) diffs.push(`${spellDegree(root, or.degrees[i])}: shows ${got} expected ${expNum[i]}`); });
        if (diffs.length) { numeralWrong++; if (numEx.length < 40) numEx.push(`${tag}: ${diffs.join('; ')}`); }
      }
      // --- degree bar
      barCases++;
      const btns = [...c.querySelectorAll('[aria-label^="Degree "]')].map((b) => b.getAttribute('aria-label')!);
      const pairs = btns.map((a) => { const m = /^Degree (\d+), ([^,]+), (.+)$/.exec(a)!; return { idx: Number(m[1]), label: m[2], note: m[3] }; });
      const issues: string[] = [];
      pairs.forEach((p, i) => {
        // letter implied by the label's degree number must match the note's letter
        const m = /^(bb|b|##|#|m)?(\d+|R)$/.exec(p.label);
        if (!m) { issues.push(`unparseable label ${p.label}`); return; }
        const num = m[2] === 'R' ? 1 : Number(m[2]);
        const expLetter = spellDegree(root, String(num))![0];
        if (p.note[0] !== expLetter) issues.push(`"${p.label}" on ${p.note} (a ${p.label} of ${root} is spelled ${expLetter}-something)`);
        const oracleNote = spellDegree(root, or.degrees[i]);
        void oracleNote;
      });
      const labels = pairs.map((p) => p.label);
      if (labels.some((l) => l.startsWith('m')) && labels.some((l) => l.startsWith('b'))) barMixedNotation++;
      if (issues.length) { barMismatch++; if (barEx.length < 60) barEx.push(`${tag}: ${issues.join('; ')}  [bar: ${pairs.map((p) => p.label + '/' + p.note).join(' ')}]`); }
      cleanup();
    }
  }
  errSpy.mockRestore();
  L.push(`renders: ${circleCases} (scale types x ${ROOTS.length} roots); crashes: ${[...crashes].join(' | ') || 'none'}`);
  L.push(`\nCIRCLE centre key-signature wrong vs conventional (scales with a standard signature): ${sigWrong}; scales with no standard signature (not judged): ${sigNA} cases`);
  L.push(`  by type: ${JSON.stringify(sigByType)}`);
  L.push(`  centre shows bare root (reads as the MAJOR key) for a minor-type/modal scale: ${centreName}`);
  for (const s of sigEx) L.push('  ' + s);
  L.push(`\nCIRCLE Roman numerals wrong (heptatonic scales): ${numeralWrong} of ${numeralCases}`);
  for (const s of numEx) L.push('  ' + s);
  L.push(`\nDEGREE BAR label/spelling contradictions: ${barMismatch} of ${barCases} cases; bars mixing "m3"-style and "b7"-style labels: ${barMixedNotation}`);
  for (const s of barEx) L.push('  ' + s);
  writeFileSync(OUT, L.join('\n'));
});
