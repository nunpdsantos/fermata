// Renders the REAL <Fretboard/> with each "Scale Pos" chip selected, for every
// scale type that has positions x 12 KeySelector roots, and checks every drawn
// position dot against the independent oracle (pitch in scale? degree label right?).
// Also counts authored position notes that are NOT drawn (fret 0 / >15 / outside window).
import './setup.ts';
import { it, vi, expect } from 'vitest';
import { render, cleanup } from '@testing-library/react';
import { writeFileSync } from 'node:fs';
vi.mock('/Users/nunosantos/Documents/Base/Music/new_music_app/src/hooks/useAudio.ts', () => ({ useAudio: () => ({ noteOn: vi.fn().mockResolvedValue(60), noteOff: vi.fn() }) }));
import { Fretboard } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/components/instruments/Fretboard.tsx';
import { useAppStore } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/state/store.ts';
import { SCALE_POSITION_LIBRARY, getScalePositions } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/constants/guitarScalePositions.ts';
import { ORACLE_SCALES, pcOf, mod12 } from '../oracle.ts';

const OUT = '/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/A-instruments/out_scalepos_render.txt';
const OPEN = ['E', 'A', 'D', 'G', 'B', 'E'].map(pcOf);
const ROOTS = ['C', 'C#', 'D', 'Eb', 'E', 'F', 'F#', 'G', 'Ab', 'A', 'Bb', 'B'];
// degree label -> semitones (independent)
const DEG: Record<string, number> = { '1': 0, b2: 1, '2': 2, '#2': 3, b3: 3, '3': 4, b4: 4, '4': 5, '#4': 6, b5: 6, '5': 7, '#5': 8, b6: 8, '6': 9, bb7: 9, b7: 10, '7': 11 };

it('scale position render audit', () => {
  const errSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
  const lines: string[] = [];
  let posRenders = 0, perfect = 0, dots = 0, outOfScale = 0, wrongLabel = 0, notDrawn = 0, notDrawnFret0 = 0, notDrawnHigh = 0, notDrawnWindow = 0, missingPcPositions = 0;
  const crashed = new Set<string>();
  const perScale: Record<string, { pos: number; perfectPositions: Set<number>; anyBad: Set<number> }> = {};
  const examples: string[] = [];
  for (const scale of Object.keys(SCALE_POSITION_LIBRARY)) {
    const or = ORACLE_SCALES[scale];
    if (!or) { lines.push(`${scale}: not a selectable ScaleType (alias) — unreachable in UI`); continue; }
    const ps = (perScale[scale] = { pos: SCALE_POSITION_LIBRARY[scale].length, perfectPositions: new Set<number>(), anyBad: new Set<number>() });
    for (const root of ROOTS) {
      const rootPc = pcOf(root);
      const scalePcs = new Set(or.semis.map((s) => mod12(rootPc + s)));
      const placed = getScalePositions({ natural: root[0], accidental: root.slice(1) } as any, scale);
      for (let idx = 0; idx < placed.length; idx++) {
        useAppStore.setState({ selectedKey: { natural: root[0], accidental: root.slice(1) } as any, selectedScale: scale as any, selectedChord: null, guitarScalePosition: idx, guitarTuningId: 'standard', activeNotes: new Set(), exerciseInputActive: false });
        let container: HTMLElement;
        try { ({ container } = render(<Fretboard />)); } catch (e) { crashed.add(`${scale}: ${(e as Error).message}`); cleanup(); break; }
        posRenders++;
        let bad = 0; const drawnPcs = new Set<number>();
        const cells = container.querySelectorAll('[data-fret][data-string-row]');
        for (const cell of cells) {
          const text = (cell.textContent ?? '').trim();
          if (!text) continue;
          dots++;
          const s = Number(cell.getAttribute('data-string-row')), f = Number(cell.getAttribute('data-fret'));
          const iv = mod12(OPEN[s] + f - rootPc);
          drawnPcs.add(mod12(OPEN[s] + f));
          if (!or.semis.includes(iv)) { outOfScale++; bad++; }
          if (DEG[text] !== iv) { wrongLabel++; bad++; if (examples.length < 25) examples.push(`${root} ${scale} chip#${idx + 1} (${placed[idx].position.shortName}, base ${placed[idx].baseFret}): string ${6 - s} fret ${f} labelled "${text}" but sounds ${['1','b2','2','b3','3','4','b5','5','b6','6','b7','7'][iv]}${or.semis.includes(iv) ? '' : ' (NOT IN SCALE)'}`); }
        }
        // authored notes not drawn
        const { position, baseFret } = placed[idx];
        const lo = Math.max(1, baseFret), hi = Math.min(15, baseFret + position.fretSpan + 1);
        for (const n of position.notes) {
          const abs = baseFret + n.fret;
          if (abs < lo || abs > hi) { notDrawn++; bad++; if (abs === 0) notDrawnFret0++; else if (abs > 15) notDrawnHigh++; else notDrawnWindow++; }
        }
        const missing = [...scalePcs].filter((pc) => !drawnPcs.has(pc));
        if (missing.length) missingPcPositions++;
        if (bad === 0 && missing.length === 0) { perfect++; ps.perfectPositions.add(idx); } else ps.anyBad.add(idx);
        cleanup();
      }
    }
  }
  errSpy.mockRestore();
  lines.unshift(
    `position renders (scale x root x chip): ${posRenders}`,
    `renders where every drawn dot is in-scale, correctly labelled, nothing authored is hidden, and all scale pcs appear: ${perfect}`,
    `drawn dots: ${dots}; out-of-scale dots: ${outOfScale}; wrong degree label: ${wrongLabel}`,
    `authored notes not drawn: ${notDrawn} (fret 0 / open: ${notDrawnFret0}; above fret 15: ${notDrawnHigh}; outside the chip window: ${notDrawnWindow})`,
    `renders whose drawn dots omit at least one scale pitch class: ${missingPcPositions}`,
    `crashed (whole fretboard throws, positions unreachable): ${[...crashed].join(' | ') || 'none'}`,
    '',
    'per scale: positions | positions correct in ALL 12 keys',
  );
  for (const [s, v] of Object.entries(perScale)) lines.push(`  ${s.padEnd(22)} ${v.pos} | ${[...v.perfectPositions].filter((i) => !v.anyBad.has(i)).map((i) => '#' + (i + 1)).join(',') || '-'}`);
  lines.push('', 'examples:', ...examples.map((e) => '  ' + e));
  writeFileSync(OUT, lines.join('\n'));
  expect(posRenders).toBeGreaterThan(0);
});
