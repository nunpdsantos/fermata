import { vi } from 'vitest';
const REPO = '/Users/nunosantos/Documents/Base/Music/new_music_app';
Element.prototype.scrollIntoView = vi.fn();
(Element.prototype as any).scrollTo = vi.fn();
if (!window.matchMedia) {
  (window as any).matchMedia = (q: string) => ({ matches: false, media: q, onchange: null, addListener() {}, removeListener() {}, addEventListener() {}, removeEventListener() {}, dispatchEvent() { return false; } });
}
export { REPO };
