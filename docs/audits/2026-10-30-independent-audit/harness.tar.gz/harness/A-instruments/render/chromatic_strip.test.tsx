// Render the REAL ChordBuilderPanel (which hosts ChromaticStrip) for 12 roots x scales and
// check each block's interval label against its note spelling (letter distance).
import './setup.ts';
import { it, vi } from 'vitest';
import { render, cleanup } from '@testing-library/react';
import { writeFileSync } from 'node:fs';
vi.mock('/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/services/audio.ts', async (orig) => ({ ...(await orig() as object), resumeAudio: vi.fn(), playChordVoiced: vi.fn() }));
import { ChordBuilderPanel } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/components/theory/ChordBuilderPanel.tsx';
import { useAppStore } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/state/store.ts';
import { LETTERS } from '../oracle.ts';
const OUT = '/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/A-instruments/out_chromatic_strip.txt';
const NUM: Record<string, number[]> = { m2: [2], M2: [2], m3: [3], M3: [3], P4: [4], TT: [4, 5], P5: [5], m6: [6], M6: [6], m7: [7], M7: [7], '8': [8] };
it('chromatic strip', () => {
  const errSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
  const L: string[] = []; let blocks = 0, bad = 0; const byInterval: Record<string, number> = {};
  for (const scale of ['major', 'natural_minor', 'dorian', 'mixolydian', 'pentatonic_minor']) for (const root of ['C', 'C#', 'D', 'Eb', 'E', 'F', 'F#', 'G', 'Ab', 'A', 'Bb', 'B']) {
    useAppStore.setState({ selectedKey: { natural: root[0], accidental: root.slice(1) } as any, selectedScale: scale as any, selectedChord: null, exerciseInputActive: false });
    const { container } = render(<ChordBuilderPanel />);
    const btns = [...container.querySelectorAll('[aria-label]')].map((b) => b.getAttribute('aria-label')!).filter((a) => /^(m2|M2|m3|M3|P4|TT|P5|m6|M6|m7|M7|8), /.test(a));
    const bads: string[] = [];
    for (const a of btns) {
      blocks++;
      const [iv, note] = a.split(', ');
      const dist = (LETTERS.indexOf(note[0] as any) - LETTERS.indexOf(root[0] as any) + 7) % 7 + 1;
      const ok = NUM[iv].some((n) => (n === 8 ? 1 : n) === dist);
      if (!ok) { bad++; byInterval[iv] = (byInterval[iv] ?? 0) + 1; bads.push(`${iv} shown as ${note}`); }
    }
    if (bads.length) L.push(`${root} ${scale}: ${bads.join('; ')}`);
    cleanup();
  }
  errSpy.mockRestore();
  L.unshift(`blocks checked: ${blocks}; interval label contradicts note spelling: ${bad}; by interval ${JSON.stringify(byInterval)}`);
  writeFileSync(OUT, L.join('\n'));
});
