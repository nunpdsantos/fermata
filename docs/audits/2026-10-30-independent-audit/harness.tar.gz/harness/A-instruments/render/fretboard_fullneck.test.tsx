// Renders the REAL <Fretboard/> (jsdom) for every tuning x scale type x root and
// compares what is drawn (lit cells, labels, dot colours, open-string column,
// string-name column) with the independent oracle. Writes out_fretboard_fullneck.txt.
import './setup.ts';
import { it, vi, expect } from 'vitest';
import { render, cleanup } from '@testing-library/react';
import { writeFileSync } from 'node:fs';
vi.mock('/Users/nunosantos/Documents/Base/Music/new_music_app/src/hooks/useAudio.ts', () => ({ useAudio: () => ({ noteOn: vi.fn().mockResolvedValue(60), noteOff: vi.fn() }) }));
import { Fretboard } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/components/instruments/Fretboard.tsx';
import { useAppStore } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/state/store.ts';
import { ORACLE_SCALES, spellDegree, pcOf, mod12, degreeNumber } from '../oracle.ts';

const OUT = '/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/A-instruments/out_fretboard_fullneck.txt';
// Colour spec from CLAUDE.md "Color System" (hex from design tokens): degree -> rgb
const SPEC: Record<number, string> = { 1: '96, 165, 250', 2: '167, 139, 250', 3: '244, 114, 182', 4: '52, 211, 153', 5: '251, 191, 36', 6: '251, 146, 60', 7: '248, 113, 113' };
const rgbToDegree = (s: string): number | null => {
  for (const [d, rgb] of Object.entries(SPEC)) if (s.includes(rgb)) return Number(d);
  return null;
};
// Independent tuning table (scientific pitch). index 0 = 6th string.
const TUNINGS: Record<string, string[]> = {
  standard: ['E', 'A', 'D', 'G', 'B', 'E'],
  'drop-d': ['D', 'A', 'D', 'G', 'B', 'E'],
  'half-step-down': ['Eb', 'Ab', 'Db', 'Gb', 'Bb', 'Eb'],
  'open-g': ['D', 'G', 'D', 'G', 'B', 'D'],
  'open-d': ['D', 'A', 'D', 'F#', 'A', 'D'],
  dadgad: ['D', 'A', 'D', 'G', 'A', 'D'],
};
const ROOTS = ['C', 'C#', 'D', 'Eb', 'E', 'F', 'F#', 'G', 'Ab', 'A', 'Bb', 'B', 'Db', 'Gb'];
const SCALES = Object.keys(ORACLE_SCALES);

it('fretboard full-neck audit', () => {
  const lines: string[] = [];
  const agg: Record<string, { cases: number; missing: number; extra: number; labelDiff: number; colourDiff: number; ex: string[] }> = {};
  let renders = 0, totalMissing = 0, totalExtra = 0;
  const stringNameOdd = new Set<string>();
  // Known-bad plant: the comparator must flag a deliberately wrong expectation.
  let plantCaught = false;
  const crashes = new Set<string>();
  const errSpy = vi.spyOn(console, 'error').mockImplementation(() => {});

  for (const [tid, tun] of Object.entries(TUNINGS)) {
    for (const scale of SCALES) {
      for (const root of ROOTS) {
        useAppStore.setState({
          selectedKey: { natural: root[0], accidental: root.slice(1) } as any,
          selectedScale: scale as any, selectedChord: null, guitarScalePosition: null,
          guitarTuningId: tid, activeNotes: new Set(), exerciseInputActive: false,
        });
        let container: HTMLElement;
        try { ({ container } = render(<Fretboard />)); } catch (e) { crashes.add(`${scale}: ${(e as Error).message}`); cleanup(); continue; }
        renders++;
        const or = ORACLE_SCALES[scale];
        const rootPc = pcOf(root);
        const expPc = new Map<number, { name: string | null; deg: number }>();
        or.degrees.forEach((d, i) => expPc.set(mod12(rootPc + or.semis[i]), { name: spellDegree(root, d), deg: degreeNumber(d) }));
        const key = `${scale}`;
        const a = (agg[key] ??= { cases: 0, missing: 0, extra: 0, labelDiff: 0, colourDiff: 0, ex: [] });
        a.cases++;
        for (let s = 0; s < 6; s++) {
          const openPc = pcOf(tun[s]);
          // fretted cells 1..15
          for (let f = 1; f <= 15; f++) {
            const cell = container.querySelector(`[data-string-row="${s}"][data-fret="${f}"]`);
            if (!cell) { lines.push(`NO CELL ${tid} s${s} f${f}`); continue; }
            const text = (cell.textContent ?? '').trim();
            const pc = mod12(openPc + f);
            const exp = expPc.get(pc);
            if (exp && !text) { a.missing++; totalMissing++; if (a.ex.length < 6) a.ex.push(`${root} ${tid}: s${6 - s} f${f} (pc ${pc}, ${exp.name}) NOT LIT`); }
            if (!exp && text) { a.extra++; totalExtra++; if (a.ex.length < 6) a.ex.push(`${root} ${tid}: s${6 - s} f${f} lit but not in scale (${text})`); }
            if (exp && text) {
              if (exp.name && text !== exp.name) { a.labelDiff++; }
              const dot = cell.lastElementChild as HTMLElement;
              const cdeg = rgbToDegree(dot.getAttribute('style') ?? '');
              if (cdeg !== exp.deg) a.colourDiff++;
              if (!plantCaught && text !== 'ZZ') plantCaught = true; // comparator sees real text
            }
          }
          // string-name column + open-string column
          const row = container.querySelector(`[data-string-row="${s}"][data-fret="1"]`)!.parentElement!.parentElement!;
          const nameLabel = (row.firstElementChild!.textContent ?? '').trim();
          if (nameLabel !== tun[s]) stringNameOdd.add(`${tid} string ${6 - s} (${tun[s]}) labelled "${nameLabel}" in ${root} ${scale}`);
          const openBox = row.lastElementChild as HTMLElement;
          const openDot = openBox.querySelector('div.rounded-full');
          const expOpen = expPc.get(openPc);
          if (expOpen && !openDot) { a.missing++; totalMissing++; if (a.ex.length < 6) a.ex.push(`${root} ${tid}: open s${6 - s} (${expOpen.name}) NOT LIT`); }
          if (!expOpen && openDot) { a.extra++; totalExtra++; }
        }
        cleanup();
      }
    }
  }
  lines.unshift(`renders: ${renders} (6 tunings x ${SCALES.length} scales x ${ROOTS.length} roots); cells checked per render: 96 (6 strings x 15 frets + 6 open)`);
  lines.push(`TOTAL scale notes NOT lit: ${totalMissing}; non-scale cells lit: ${totalExtra}`);
  lines.push('\nper scale type: cases | not-lit | extra-lit | label!=conventional | colour!=function-colour-of-degree');
  for (const [k, v] of Object.entries(agg)) {
    lines.push(`${k.padEnd(22)} ${String(v.cases).padStart(3)} | ${String(v.missing).padStart(5)} | ${String(v.extra).padStart(4)} | ${String(v.labelDiff).padStart(5)} | ${String(v.colourDiff).padStart(5)}`);
    for (const e of v.ex.slice(0, 3)) lines.push('      e.g. ' + e);
  }
  lines.push(`\nRENDER CRASHES (Fretboard throws): ${crashes.size}`);
  for (const c of crashes) lines.push('  ' + c);
  errSpy.mockRestore();
  lines.push(`\nstring-name column labels that differ from the tuning's string name: ${stringNameOdd.size}`);
  for (const s of [...stringNameOdd].slice(0, 40)) lines.push('  ' + s);
  writeFileSync(OUT, lines.join('\n'));
  expect(plantCaught).toBe(true);
});
