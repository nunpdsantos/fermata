// interval_id exercises: the staff (ExercisePrompt.tsx:45-63) spells the 2nd note from a sharps-only
// table. Enumerate every authored + generated (EN) interval_id exercise and compare the drawn letter
// distance with the interval actually asked (targetSemitones -> generic interval number).
import { generateAllForLevel, mergeExerciseMaps } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/data/exercises/exerciseGenerator.ts';
const REPO = '/Users/nunosantos/Documents/Base/Music/new_music_app/src/data/exercises/';
const LET = ['C', 'D', 'E', 'F', 'G', 'A', 'B'];
const NATURALS = ['C', 'C', 'D', 'D', 'E', 'F', 'F', 'G', 'G', 'A', 'A', 'B'];
const ACC = ['', '#', '', '#', '', '', '#', '', '#', '', '#', ''];
// generic interval numbers that a given semitone count may be spelled as (conventional names; TT = 4th or 5th)
const GEN: Record<number, number[]> = { 0: [1], 1: [2], 2: [2], 3: [3], 4: [3], 5: [4], 6: [4, 5], 7: [5], 8: [6], 9: [6], 10: [7], 11: [7], 12: [8] };
(async () => {
  let total = 0, wrong = 0; const ex: string[] = [];
  for (let l = 1; l <= 9; l++) {
    const authored = (await import(REPO + `exercisesL${l}.ts`)).default as Record<string, any[]>;
    const templates = (await import(REPO + `templatesL${l}.ts`)).default as any[];
    const merged = mergeExerciseMaps(authored, generateAllForLevel(templates));
    for (const list of Object.values(merged)) for (const e of list) {
      if (e.config?.type !== 'interval_id') continue;
      total++;
      const c = e.config; const rootPCs: Record<string, number> = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };
      let rootPC = rootPCs[c.root] ?? 0; if (c.rootAccidental === '#') rootPC++; if (c.rootAccidental === 'b') rootPC--;
      const semis = c.direction === 'descending' ? -c.targetSemitones : c.targetSemitones;
      const tpc = ((rootPC + semis) % 12 + 12) % 12;
      const tLetter = NATURALS[tpc];
      const dist = c.direction === 'descending' ? (LET.indexOf(c.root) - LET.indexOf(tLetter) + 7) % 7 + 1 : (LET.indexOf(tLetter) - LET.indexOf(c.root) + 7) % 7 + 1;
      const okNums = GEN[Math.abs(c.targetSemitones) % 13] ?? [];
      const distAdj = Math.abs(c.targetSemitones) === 12 ? (dist === 1 ? 8 : dist) : dist;
      if (!okNums.includes(distAdj)) { wrong++; if (ex.length < 40) ex.push(`${e.id} [${(e.prompt as string).slice(0, 70)}]: ${c.root}${c.rootAccidental || ''} ${c.direction ?? 'ascending'} ${c.targetSemitones} semitones -> staff shows ${c.root}${c.rootAccidental || ''} + ${tLetter}${ACC[tpc]} (a ${distAdj}th by letter)`); }
    }
  }
  console.log(`interval_id exercises (authored + generated EN): ${total}; staff draws the wrong interval number: ${wrong}`);
  for (const s of ex) console.log('  ' + s);
})();
