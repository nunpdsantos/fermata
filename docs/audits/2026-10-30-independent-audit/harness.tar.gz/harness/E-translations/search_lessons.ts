const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
(async () => {
  const { getResults } = await import(`${R}/components/navigation/quickSearchResults.ts`);
  for (const q of ['cadence', 'cadência', 'cadencia', 'suspension', 'suspensão', 'retardo', 'Neapolitan', 'napolitano', 'Dó maior']) {
    const r = getResults(q);
    console.log(JSON.stringify(q).padEnd(14), r.length, r.slice(0, 3).map((x: any) => `${x.type}:${x.label}`).join(' | '));
  }
})();
