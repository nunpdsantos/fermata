/*
 * Invariant-token drift check: for every translated exercise prompt/hint/choice,
 * template prompt/hint/choiceSet label, and curriculum string, compare the
 * multiset of "language-independent" tokens (numbers, accidental-bearing notes
 * normalised from solfège, Roman numerals, chord symbols, time signatures)
 * between EN and PT/ES at the SAME position. A mismatch = the translation may
 * state a different fact (or a choice was reordered => different correct answer).
 * Run: cd <repo> && npx tsx invariants.ts [--plant]
 */
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
import fs from 'node:fs';
const OUT = '/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/E-translations';
const PLANT = process.argv.includes('--plant');

const SOLF: [RegExp, string][] = [
  [/(?<![\p{L}])(?:Dó|Do)(?=[#b♯♭]|-|\s(?:maior|menor|mayor|sustenido|bemol|sostenido))/gu, 'C'],
  [/(?<![\p{L}])(?:Ré|Re)(?=[#b♯♭]|-|\s(?:maior|menor|mayor|sustenido|bemol|sostenido))/gu, 'D'],
  [/(?<![\p{L}])Mi(?=[#b♯♭]|-|\s(?:maior|menor|mayor|sustenido|bemol|sostenido))/gu, 'E'],
  [/(?<![\p{L}])(?:Fá|Fa)(?=[#b♯♭]|-|\s(?:maior|menor|mayor|sustenido|bemol|sostenido))/gu, 'F'],
  [/(?<![\p{L}])Sol(?=[#b♯♭]|-|\s(?:maior|menor|mayor|sustenido|bemol|sostenido))/gu, 'G'],
  [/(?<![\p{L}])(?:Lá|La)(?=[#b♯♭]|-|\s(?:maior|menor|mayor|sustenido|bemol|sostenido))/gu, 'A'],
  [/(?<![\p{L}])Si(?=[#b♯♭]|-|\s(?:maior|menor|mayor|sustenido|bemol|sostenido))/gu, 'B'],
];
const NUMW: [RegExp, string][] = [
  [/(?<![\p{L}])(?:second|seconds|segunda|segundas|2nds?)(?![\p{L}])/giu, '2'],
  [/(?<![\p{L}])(?:third|thirds|terça|terças|tercera|terceras|terceira|terceiras|3rds?)(?![\p{L}])/giu, '3'],
  [/(?<![\p{L}])(?:fourth|fourths|quarta|quartas|cuarta|cuartas|4ths?)(?![\p{L}])/giu, '4'],
  [/(?<![\p{L}])(?:fifth|fifths|quinta|quintas|5ths?)(?![\p{L}])/giu, '5'],
  [/(?<![\p{L}])(?:sixth|sixths|sexta|sextas|6ths?)(?![\p{L}])/giu, '6'],
  [/(?<![\p{L}])(?:seventh|sevenths|sétima|sétimas|séptima|séptimas|7ths?)(?![\p{L}])/giu, '7'],
  [/(?<![\p{L}])(?:octave|octaves|oitava|oitavas|octava|octavas|8ths?|8vas?)(?![\p{L}])/giu, '8'],
  [/(?<![\p{L}])(?:ninth|ninths|nona|nonas|novena|novenas|9ths?)(?![\p{L}])/giu, '9'],
];
function norm(s: string): string {
  let t = s.replace(/♯/g, '#').replace(/♭/g, 'b').replace(/°/g, 'o');
  for (const [re, d] of NUMW) t = t.replace(re, d);
  t = t.replace(/(\d+)(?:\.(?:ª|º|a|o|as|os)|ª|º|st|nd|rd|th)(?![\p{L}])/gu, '$1');
  t = t.replace(/(?<=[\p{L}])\s(?:sustenido|sostenido)/gu, '#').replace(/(?<=[\p{L}])\s(?:bemol)/gu, 'b');
  for (const [re, l] of SOLF) t = t.replace(re, l);
  return t;
}
function tokens(s: string): string[] {
  const t = norm(s);
  const out: string[] = [];
  // accidental notes / chord symbols starting with a letter + accidental
  for (const m of t.matchAll(/(?<![\p{L}])[A-G][#b](?:maj7|m7b5|m7|dim7|dim|aug|m|7|9|11|13|6)?(?![\p{L}])/gu)) out.push('N:' + m[0]);
  // chord symbols on naturals (Cmaj7, Dm7, G7, Bdim) — exclude bare 'Em' (PT/ES word) and bare 'A'/'E'
  for (const m of t.matchAll(/(?<![\p{L}#])[A-G](?:maj7|m7b5|m7|dim7|dim|aug|7|9|11|13|6)(?![\p{L}])/gu)) out.push('C:' + m[0]);
  // Roman numerals with figures/qualities (require length>=2 or a figure to avoid PT 'I'/'V' as words)
  for (const m of t.matchAll(/(?<![\p{L}])(?:b|#)?(?:VII|VI|IV|V|III|II|I|vii|vi|iv|v|iii|ii|i)(?:°|ø|o|\+|maj7|7|6\/5|4\/3|4\/2|6\/4|65|43|42|64|6)?(?![\p{L}])/gu)) {
    if (/^(?:I|V|i|v)$/.test(m[0])) continue; // ambiguous bare single letters
    if (/^(?:vi|v|i)$/.test(m[0])) continue;
    out.push('R:' + m[0]);
  }
  // time signatures and ratios
  for (const m of t.matchAll(/\b\d+\/\d+\b/g)) out.push('T:' + m[0]);
  // standalone numbers (incl. ordinals 3rd / 3.ª / 3º / 3.a)
  for (const m of t.matchAll(/(?<![\d/])\d+(?![\d/])/g)) out.push('#' + m[0]);
  return out.sort();
}
function diff(a: string[], b: string[]) {
  const ca: Record<string, number> = {}, cb: Record<string, number> = {};
  a.forEach((x) => (ca[x] = (ca[x] ?? 0) + 1)); b.forEach((x) => (cb[x] = (cb[x] ?? 0) + 1));
  const onlyA: string[] = [], onlyB: string[] = [];
  for (const k of new Set([...a, ...b])) { const d = (ca[k] ?? 0) - (cb[k] ?? 0); if (d > 0) onlyA.push(`${k}×${d}`); if (d < 0) onlyB.push(`${k}×${-d}`); }
  return { onlyA, onlyB };
}

async function main() {
  const pairs: { where: string; kind: string; en: string; tr: string; lang: string }[] = [];
  for (let n = 1; n <= 9; n++) {
    const exEn = Object.values((await import(`${R}/data/exercises/exercisesL${n}.ts`)).default as Record<string, any[]>).flat();
    const tmEn = (await import(`${R}/data/exercises/templatesL${n}.ts`)).default as any[];
    const cur = (await import(`${R}/core/constants/curriculumL${n}.ts`))[`L${n}_UNITS`] as any[];
    for (const lang of ['pt', 'es']) {
      const xov = (await import(`${R}/i18n/content/${lang}/exercisesL${n}.ts`)).default as any;
      const tov = (await import(`${R}/i18n/content/${lang}/templatesL${n}.ts`)).default as any;
      const cov = (await import(`${R}/i18n/content/${lang}/curriculumL${n}.ts`)).default as any;
      for (const e of exEn) {
        const o = xov[e.id]; if (!o) continue;
        pairs.push({ where: `${lang}/exercisesL${n} ${e.id}.prompt`, kind: 'ex-prompt', en: e.prompt, tr: o.prompt, lang });
        if (e.hint && o.hint) pairs.push({ where: `${lang}/exercisesL${n} ${e.id}.hint`, kind: 'ex-hint', en: e.hint, tr: o.hint, lang });
        const ch = e.config.choices as any[] | undefined;
        if (ch && o.choices) ch.forEach((c, i) => pairs.push({ where: `${lang}/exercisesL${n} ${e.id}.choices[${i}]${c.correct ? ' (CORRECT)' : ''}`, kind: 'ex-choice', en: c.label, tr: o.choices[i] ?? '', lang }));
      }
      for (const c of tmEn) {
        const o = tov[c.moduleId]; if (!o) continue;
        c.templates.forEach((t: any, i: number) => {
          const ot = o[i]; if (!ot) return;
          pairs.push({ where: `${lang}/templatesL${n} ${c.moduleId}[${i}].prompt`, kind: 'tm-prompt', en: t.promptTemplate, tr: ot.promptTemplate, lang });
          pairs.push({ where: `${lang}/templatesL${n} ${c.moduleId}[${i}].hint`, kind: 'tm-hint', en: t.hintTemplate, tr: ot.hintTemplate, lang });
          (t.params.choiceSets ?? []).forEach((set: any[], si: number) => set.forEach((ch: any, ci: number) => pairs.push({ where: `${lang}/templatesL${n} ${c.moduleId}[${i}].set${si}[${ci}]${ch.correct ? ' (CORRECT)' : ''}`, kind: 'tm-choice', en: ch.label, tr: ot.choiceSets?.[si]?.[ci] ?? '', lang })));
        });
      }
      for (const u of cur) for (const m of u.modules) {
        const o = cov.modules[m.id]; if (!o) continue;
        m.concepts.forEach((c: any, i: number) => {
          pairs.push({ where: `${lang}/curriculumL${n} ${m.id}.concepts[${i}].explanation`, kind: 'cur', en: c.explanation, tr: o.concepts[i]?.explanation ?? '', lang });
          pairs.push({ where: `${lang}/curriculumL${n} ${m.id}.concepts[${i}].tryThisLabel`, kind: 'cur', en: c.tryThisLabel, tr: o.concepts[i]?.tryThisLabel ?? '', lang });
        });
        m.tasks.forEach((t: any, i: number) => pairs.push({ where: `${lang}/curriculumL${n} ${m.id}.tasks[${i}]`, kind: 'cur', en: t.instruction, tr: o.tasks[i]?.instruction ?? '', lang }));
        m.objectives.forEach((t: string, i: number) => pairs.push({ where: `${lang}/curriculumL${n} ${m.id}.objectives[${i}]`, kind: 'cur', en: t, tr: o.objectives[i] ?? '', lang }));
      }
    }
  }
  if (PLANT) pairs.push({ where: 'planted', kind: 'ex-choice', en: 'F# major has 6 sharps', tr: 'Sol maior tem 1 sustenido', lang: 'pt' });
  const lines: string[] = [];
  const byKind: Record<string, [number, number]> = {};
  for (const p of pairs) {
    const k = `${p.lang}:${p.kind}`;
    byKind[k] ??= [0, 0]; byKind[k][0]++;
    const { onlyA, onlyB } = diff(tokens(p.en), tokens(p.tr));
    if (onlyA.length || onlyB.length) {
      byKind[k][1]++;
      lines.push(`[${p.kind}] ${p.where}\n  only-EN: ${onlyA.join(' ')}  only-${p.lang}: ${onlyB.join(' ')}\n  EN: ${p.en}\n  ${p.lang.toUpperCase()}: ${p.tr}`);
    }
  }
  const head = `# pairs compared: ${pairs.length}; mismatches by kind [compared, mismatched]: ${JSON.stringify(byKind)}`;
  fs.writeFileSync(`${OUT}/invariants${PLANT ? '.plant' : ''}.out.txt`, [head, ...lines].join('\n'));
  console.log(head);
}
main().catch((e) => { console.error(e); process.exit(1); });
