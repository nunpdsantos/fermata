const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
(async () => {
  const lv = Number(process.argv[2]);
  const ex = Object.values((await import(`${R}/data/exercises/exercisesL${lv}.ts`)).default as Record<string, any[]>).flat();
  const pt = (await import(`${R}/i18n/content/pt/exercisesL${lv}.ts`)).default as any;
  for (const e of ex) {
    if (e.config.type !== 'multiple_choice') continue;
    const o = pt[e.id];
    console.log(`# ${e.id}\nEN: ${e.prompt}\nPT: ${o.prompt}`);
    e.config.choices.forEach((c: any, i: number) => console.log(`  ${c.correct ? '*' : ' '} ${c.label}\n    ${o.choices?.[i]}`));
  }
})();
