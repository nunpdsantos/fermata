// Heuristic reorder detector: per choice position, EN/PT length ratio should be roughly stable.
// Flags sets where the per-position length ratios disagree strongly (possible swapped choices).
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const PLANT = process.argv.includes('--plant');
(async () => {
  const sets: { id: string; en: string[]; tr: string[]; lang: string; correct: number }[] = [];
  for (let n = 1; n <= 9; n++) {
    const ex = Object.values((await import(`${R}/data/exercises/exercisesL${n}.ts`)).default as Record<string, any[]>).flat();
    const tm = (await import(`${R}/data/exercises/templatesL${n}.ts`)).default as any[];
    for (const lang of ['pt', 'es']) {
      const xo = (await import(`${R}/i18n/content/${lang}/exercisesL${n}.ts`)).default as any;
      const to = (await import(`${R}/i18n/content/${lang}/templatesL${n}.ts`)).default as any;
      for (const e of ex) if (e.config.choices && xo[e.id]?.choices) sets.push({ id: e.id, en: e.config.choices.map((c: any) => c.label), tr: xo[e.id].choices, lang, correct: e.config.choices.findIndex((c: any) => c.correct) });
      for (const c of tm) c.templates.forEach((t: any, i: number) => (t.params.choiceSets ?? []).forEach((s: any[], si: number) => { const o = to[c.moduleId]?.[i]?.choiceSets?.[si]; if (o) sets.push({ id: `${c.moduleId}[${i}].set${si}`, en: s.map((x: any) => x.label), tr: o, lang, correct: s.findIndex((x: any) => x.correct) }); }));
    }
  }
  if (PLANT) sets.push({ id: 'planted', lang: 'pt', correct: 0, en: ['A very long correct explanation of the concept here', 'Short wrong', 'Tiny wrong', 'Brief wrong'], tr: ['Curto errado', 'Uma explicação muito longa e correta do conceito aqui', 'Mini errado', 'Breve errado'] });
  let flagged = 0;
  for (const s of sets) {
    if (s.en.length < 3) continue;
    const ratios = s.en.map((e, i) => (s.tr[i]?.length ?? 0) / Math.max(1, e.length));
    const med = [...ratios].sort((a, b) => a - b)[Math.floor(ratios.length / 2)];
    const bad = ratios.map((r, i) => [r / med, i] as const).filter(([q]) => (q > 1.9 || q < 0.52));
    const longEnough = s.en.every((e) => e.length >= 8);
    if (bad.length && longEnough) { flagged++; console.log(`${s.lang} ${s.id} correct=${s.correct} odd positions ${bad.map(([q, i]) => `${i}(x${q.toFixed(2)})`).join(',')}\n  EN: ${JSON.stringify(s.en)}\n  TR: ${JSON.stringify(s.tr)}`); }
  }
  console.log(`# sets checked: ${sets.length}, flagged: ${flagged}`);
})();
