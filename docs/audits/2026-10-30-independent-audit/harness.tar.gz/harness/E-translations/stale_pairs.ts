/*
 * For every EN string that was rewritten in a content-fix commit (from en_diffs.txt
 * '+' lines), locate it in current EN data and print the PT/ES overlay text at the
 * same position, alongside the OLD EN text ('-' line) — so a reviewer can see whether
 * the translation follows the old (pre-fix) or new EN.
 * Run: cd <repo> && npx tsx stale_pairs.ts
 */
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
import fs from 'node:fs';
const OUT = '/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/E-translations';

function unq(s: string) {
  let t = s.replace(/^[-+]\s*/, '').replace(/^(?:\w+:\s*)/, '').trim().replace(/,$/, '');
  t = t.replace(/^['"`]/, '').replace(/['"`]$/, '');
  return t.replace(/\\u([0-9A-Fa-f]{4})/g, (_, h) => String.fromCharCode(parseInt(h, 16))).replace(/\\'/g, "'");
}
const diffLines = fs.readFileSync(`${OUT}/en_diffs.txt`, 'utf8').split('\n');
const pairs: { old: string; neu: string }[] = [];
for (let i = 0; i < diffLines.length; i++) {
  if (diffLines[i].startsWith('+ ') || diffLines[i].startsWith('+\t')) {
    const neu = unq(diffLines[i]);
    let j = i - 1; let old = '';
    while (j >= 0 && (diffLines[j].startsWith('+ ') || diffLines[j].startsWith('- '))) { if (diffLines[j].startsWith('- ')) { old = unq(diffLines[j]); break; } j--; }
    if (neu.length > 25) pairs.push({ old, neu });
  }
}
const key = (s: string) => s.slice(0, 50);
async function main() {
  const lines: string[] = [`# EN '+' strings considered: ${pairs.length}`];
  let located = 0;
  for (let n = 1; n <= 9; n++) {
    const cur = (await import(`${R}/core/constants/curriculumL${n}.ts`))[`L${n}_UNITS`] as any[];
    const ex = Object.values((await import(`${R}/data/exercises/exercisesL${n}.ts`)).default as Record<string, any[]>).flat();
    const tm = (await import(`${R}/data/exercises/templatesL${n}.ts`)).default as any[];
    const ov: Record<string, any> = {};
    for (const l of ['pt', 'es']) ov[l] = {
      cur: (await import(`${R}/i18n/content/${l}/curriculumL${n}.ts`)).default,
      ex: (await import(`${R}/i18n/content/${l}/exercisesL${n}.ts`)).default,
      tm: (await import(`${R}/i18n/content/${l}/templatesL${n}.ts`)).default,
    };
    const fields: { path: string; en: string; get: (l: string) => string | undefined }[] = [];
    for (const u of cur) for (const m of u.modules) {
      fields.push({ path: `${m.id}.title`, en: m.title, get: (l) => ov[l].cur.modules[m.id]?.title });
      fields.push({ path: `${m.id}.subtitle`, en: m.subtitle, get: (l) => ov[l].cur.modules[m.id]?.subtitle });
      m.objectives.forEach((o: string, i: number) => fields.push({ path: `${m.id}.objectives[${i}]`, en: o, get: (l) => ov[l].cur.modules[m.id]?.objectives[i] }));
      m.concepts.forEach((c: any, i: number) => {
        fields.push({ path: `${m.id}.concepts[${i}].title`, en: c.title, get: (l) => ov[l].cur.modules[m.id]?.concepts[i]?.title });
        fields.push({ path: `${m.id}.concepts[${i}].explanation`, en: c.explanation, get: (l) => ov[l].cur.modules[m.id]?.concepts[i]?.explanation });
        fields.push({ path: `${m.id}.concepts[${i}].tryThisLabel`, en: c.tryThisLabel, get: (l) => ov[l].cur.modules[m.id]?.concepts[i]?.tryThisLabel });
      });
      m.tasks.forEach((t: any, i: number) => fields.push({ path: `${m.id}.tasks[${i}]`, en: t.instruction, get: (l) => ov[l].cur.modules[m.id]?.tasks[i]?.instruction }));
    }
    for (const e of ex) {
      fields.push({ path: `${e.id}.prompt`, en: e.prompt, get: (l) => ov[l].ex[e.id]?.prompt });
      if (e.hint) fields.push({ path: `${e.id}.hint`, en: e.hint, get: (l) => ov[l].ex[e.id]?.hint });
      (e.config.choices ?? []).forEach((c: any, i: number) => fields.push({ path: `${e.id}.choices[${i}]`, en: c.label, get: (l) => ov[l].ex[e.id]?.choices?.[i] }));
    }
    for (const c of tm) c.templates.forEach((t: any, i: number) => {
      fields.push({ path: `${c.moduleId}[${i}].prompt`, en: t.promptTemplate, get: (l) => ov[l].tm[c.moduleId]?.[i]?.promptTemplate });
      fields.push({ path: `${c.moduleId}[${i}].hint`, en: t.hintTemplate, get: (l) => ov[l].tm[c.moduleId]?.[i]?.hintTemplate });
      (t.params.choiceSets ?? []).forEach((s: any[], si: number) => s.forEach((ch: any, ci: number) => fields.push({ path: `${c.moduleId}[${i}].set${si}[${ci}]`, en: ch.label, get: (l) => ov[l].tm[c.moduleId]?.[i]?.choiceSets?.[si]?.[ci] })));
    });
    for (const p of pairs) {
      const f = fields.find((x) => key(x.en) === key(p.neu) || x.en.includes(p.neu.slice(0, 60)));
      if (!f) continue;
      located++;
      lines.push(`\n## L${n} ${f.path}\n  OLD-EN: ${p.old.slice(0, 600)}\n  NEW-EN: ${f.en.slice(0, 600)}\n  PT: ${(f.get('pt') ?? '<none>').slice(0, 600)}\n  ES: ${(f.get('es') ?? '<none>').slice(0, 600)}`);
    }
  }
  lines.splice(1, 0, `# located in current EN: ${located}`);
  fs.writeFileSync(`${OUT}/stale_pairs.out.txt`, lines.join('\n'));
  console.log(lines.slice(0, 2).join('\n'));
}
main().catch((e) => { console.error(e); process.exit(1); });
