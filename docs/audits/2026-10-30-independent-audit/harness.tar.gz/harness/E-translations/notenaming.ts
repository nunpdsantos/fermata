/*
 * Note-naming convention audit: letter names (C, F#, Bb) vs solfège (Dó/Ré/Mi | Do/Re/Mi)
 * across every translated string in PT/ES overlays + locale JSON.
 * Run: cd <repo> && npx tsx notenaming.ts [--plant]
 */
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
import fs from 'node:fs';
const OUT = '/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/E-translations';
const PLANT = process.argv.includes('--plant');

// Unambiguous letter-note contexts
const LETTER = [
  /\b[A-G](?:#|b|♯|♭)(?![a-z])/g,                       // F#, Bb, C♯
  /\b[A-G](?:#|b)?[0-68]\b/g,                            // C4, A3 (7/9 excluded: chord symbols)
  /\b[A-G](?:#|b)?-[A-G](?:#|b)?\b/g,                    // C-E, D-F#
  // chord symbols (Cmaj7, G7, Am) deliberately EXCLUDED: letter-based cifra is normal in PT/ES too
  /\b[A-G](?:#|b)? (?:maior|menor|mayor|central|natural)\b/g, // C maior, C central
];
const SOLF_PT = [
  /(?:Dó|Ré|Fá|Lá)(?:#|b|♯|♭|\s?sustenido|\s?bemol)?/g,
  /\b(?:Sol|Mi|Si)(?:#|b|♯|♭)?(?= (?:maior|menor|central|sustenido|bemol)|-|#|b\b|♯|♭)/g,
  /\b(?:Sol|Mi|Si)(?:#|b)\b/g,
];
const SOLF_ES = [
  /\b(?:Do|Re|Fa|La|Sol|Mi|Si)(?:#|b|♯|♭)?(?= (?:mayor|menor|central|sostenido|bemol)|-[A-Z]|#|♯|♭)/g,
  /\b(?:Do|Re|Fa|La|Sol|Mi|Si)(?:#|b)\b/g,
  /-(?:Do|Re|Fa|La|Sol|Mi|Si)(?:#|b)?\b/g,
];
function count(s: string, res: RegExp[]) { let n = 0; const ex: string[] = []; for (const r of res) for (const m of s.matchAll(r)) { n++; ex.push(m[0]); } return { n, ex }; }

function walk(o: unknown, path: string, acc: [string, string][]) {
  if (typeof o === 'string') acc.push([path, o]);
  else if (Array.isArray(o)) o.forEach((v, i) => walk(v, `${path}[${i}]`, acc));
  else if (o && typeof o === 'object') for (const [k, v] of Object.entries(o)) walk(v, path ? `${path}.${k}` : k, acc);
}

async function main() {
  const lines: string[] = [];
  for (const lang of ['pt', 'es'] as const) {
    const SOLF = lang === 'pt' ? SOLF_PT : SOLF_ES;
    const files = fs.readdirSync(`${R}/i18n/content/${lang}`).filter((f) => f.endsWith('.ts'));
    const strings: [string, string][] = [];
    for (const f of files) {
      const mod = (await import(`${R}/i18n/content/${lang}/${f}`)).default;
      walk(mod, f.replace('.ts', ''), strings);
    }
    walk(JSON.parse(fs.readFileSync(`${R}/i18n/locales/${lang}.json`, 'utf8')), `locale`, strings);
    if (PLANT) strings.push(['planted.mixed', lang === 'pt' ? 'O acorde de Dó maior tem C-E-G' : 'El acorde de Do mayor tiene C-E-G']);
    const per: Record<string, { letter: number; solf: number; both: number; total: number }> = {};
    const mixed: string[] = [];
    let L = 0, S = 0, B = 0;
    for (const [p, s] of strings) {
      const group = p.split(/[.[]/)[0].replace(/L\d$/, '');
      per[group] ??= { letter: 0, solf: 0, both: 0, total: 0 };
      per[group].total++;
      const l = count(s, LETTER), so = count(s, SOLF);
      if (l.n) per[group].letter++;
      if (so.n) per[group].solf++;
      if (l.n && so.n) { per[group].both++; B++; mixed.push(`${p}\n    letter:${JSON.stringify([...new Set(l.ex)])} solf:${JSON.stringify([...new Set(so.ex)])}\n    "${s.slice(0, 300)}"`); }
      if (l.n) L++; if (so.n) S++;
    }
    lines.push(`## ${lang}: ${strings.length} strings; with letter-notes ${L}; with solfège ${S}; with BOTH in same string ${B}`);
    lines.push('group | strings | letter | solfège | both');
    for (const [g, v] of Object.entries(per)) lines.push(`${g} | ${v.total} | ${v.letter} | ${v.solf} | ${v.both}`);
    lines.push(`### ${lang} strings mixing both conventions:`);
    lines.push(...mixed);
  }
  fs.writeFileSync(`${OUT}/notenaming${PLANT ? '.plant' : ''}.out.txt`, lines.join('\n'));
  console.log(lines.filter((l) => l.startsWith('##') || l.includes(' | ')).join('\n'));
}
main().catch((e) => { console.error(e); process.exit(1); });
