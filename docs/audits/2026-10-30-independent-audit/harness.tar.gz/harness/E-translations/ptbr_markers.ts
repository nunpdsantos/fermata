/*
 * PT-BR / register / orthography marker scan over every PT string
 * (content overlays + pt.json + musicTerms). Exhaustive over strings.
 * Run: cd <repo> && npx tsx ptbr_markers.ts [--plant]
 */
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
import fs from 'node:fs';
const OUT = '/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/E-translations';
const PLANT = process.argv.includes('--plant');

function walk(o: unknown, path: string, acc: [string, string][]) {
  if (typeof o === 'string') acc.push([path, o]);
  else if (Array.isArray(o)) o.forEach((v, i) => walk(v, `${path}[${i}]`, acc));
  else if (o && typeof o === 'object') for (const [k, v] of Object.entries(o)) walk(v, path ? `${path}.${k}` : k, acc);
}

// Each marker: [label, regex]. Word-ish boundaries built with lookarounds that treat accented letters as letters.
const W = (s: string) => new RegExp(`(?<![\\p{L}])(?:${s})(?![\\p{L}])`, 'gu');
const MARKERS: [string, RegExp][] = [
  ['BR pronoun você/vocês', W('[Vv]ocês?')],
  ['BR circumflex spelling (tônica/harmônico/gênero/fenômeno/metrônomo/acadêmico/cômodo/Antônio/sinônimo/anônimo/econômico/polifônico/sinfônico/eletrônico/tônico/harmônica)', W('[Tt]ônic[ao]s?|[Hh]armônic[ao]s?|[Gg]êner[ao]s?|[Ff]enômen[ao]s?|[Mm]etrônom[ao]s?|[Aa]cadêmic[ao]s?|[Ss]inônim[ao]s?|[Aa]nônim[ao]s?|[Ee]conômic[ao]s?|[Pp]olifônic[ao]s?|[Ss]infônic[ao]s?|[Ee]letrônic[ao]s?|[Mm]onofônic[ao]s?|[Hh]omofônic[ao]s?|[Ff]ônic[ao]s?|[Cc]ômod[ao]s?|[Tt]ênue|[Aa]gônic[ao]|[Ii]rônic[ao]s?|[Cc]rônic[ao]s?')],
  ['BR spelling without c/p (fato/contato/ação ok; seção/setor/ótica/diretor/exato)', W('[Ss]eção|[Ss]eções|[Ff]ato(?:s)?|[Cc]ontato|[Aa]to(?:s)?|[Rr]egistr(?:o|ar|ado|ada)|[Pp]lanej\\p{L}*|[Ee]quipe')],
  ['BR vocabulary (tela/arquivo/usuário/aplicativo/salvar/baixar/celular/mouse/trem/ônibus/time/legal/bacana/a gente)', W('[Tt]elas?|[Aa]rquivos?|[Uu]suári[oa]s?|[Aa]plicativos?|[Ss]alvar|[Bb]aixar|[Cc]elular|[Mm]ouse|[Tt]rem|[Óó]nibus|[Bb]acana|a gente')],
  ['BR gerund progressive (estar/ficar/continuar + -ndo)', W('(?:[Ee]st(?:á|ão|ou|ás|amos|ava|avam|iver|ar)|[Ff]ic(?:a|am|ar)|[Cc]ontinu(?:a|am|ar)|[Vv]ai|[Vv]ão|[Vv][áa]s|[Aa]nda|[Aa]ndam)\\s+\\p{L}+ndo')],
  ['bare -ndo gerund (inspect; PT-PT uses a+infinitive for progressives, gerunds ok adverbially)', W('\\p{L}+[aei]ndo')],
  ['3rd-person (você) imperatives at sentence start (Toque/Ouça/Identifique/Construa/Escreva/Compare/Clique/Selecione/Observe/Note/Tente/Use)', /(?:^|[.!?:]\s+|—\s*)(?:Toque|Ouça|Identifique|Construa|Escreva|Compare|Clique|Selecione|Observe|Note|Tente|Use|Escolha|Encontre|Imagine|Experimente|Cante|Conte|Repare|Pense|Veja|Abra|Ative|Desative)(?![\p{L}])/gu],
  ['proclisis at sentence start (Me/Te/Se/Nos/Lhe + verb) — PT-PT uses enclisis', /(?:^|[.!?]\s+)(?:Me|Te|Se|Nos|Lhe)\s+\p{Ll}+(?:a|e|o|m)(?![\p{L}])/gu],
  ['ASCII ordinal (3.a / 7.o) instead of 3.ª / 7.º', /\b\d+\.(?:a|o|as|os)(?![\p{L}])/gu],
  ['"semitom" (BR-leaning; PT-PT standard is meio-tom)', W('[Ss]emitons?')],
  ['"armadura de clave" (BR) vs PT-PT "armação de clave"', W('[Aa]rmaduras? de claves?')],
  ['"tom de X" for key (BR-leaning) vs "tonalidade"', W('tom de (?:Dó|Ré|Mi|Fá|Sol|Lá|Si|[A-G])')],
  ['double hyphen "--" used as dash', /\s--\s/g],
  ['"tu" register: você-form possessive "seu/sua" addressing reader (inspect)', W('[Ss]eu|[Ss]ua|[Ss]eus|[Ss]uas')],
  ['English words leaking (the/and/with/chord/scale/major/minor/key of/root/click/play)', W('the|and|with|chord|scale|major|minor|key of|click|play|note|notes|interval|degree')],
];

async function main() {
  const strings: [string, string][] = [];
  for (const f of fs.readdirSync(`${R}/i18n/content/pt`).filter((x) => x.endsWith('.ts'))) {
    walk((await import(`${R}/i18n/content/pt/${f}`)).default, f.replace('.ts', ''), strings);
  }
  walk(JSON.parse(fs.readFileSync(`${R}/i18n/locales/pt.json`, 'utf8')), 'pt.json', strings);
  if (PLANT) strings.push(['planted', 'Você deve tocar a tônica. Toque o acorde. Estás tocando bem. Me diga a 3.a nota do arquivo.']);
  const lines: string[] = [`PT strings scanned: ${strings.length}`];
  for (const [label, re] of MARKERS) {
    const hits: string[] = [];
    const tally: Record<string, number> = {};
    for (const [p, s] of strings) {
      const ms = [...s.matchAll(re)].map((m) => m[0].trim());
      if (ms.length) {
        for (const m of ms) tally[m] = (tally[m] ?? 0) + 1;
        hits.push(`  ${p}: ${JSON.stringify(ms)} :: ${s.slice(0, 220)}`);
      }
    }
    lines.push(`\n### ${label}: ${hits.length} strings; tally ${JSON.stringify(tally)}`);
    lines.push(...hits);
  }
  fs.writeFileSync(`${OUT}/ptbr${PLANT ? '.plant' : ''}.out.txt`, lines.join('\n'));
  console.log(lines.filter((l) => l.startsWith('\n###') || l.startsWith('PT')).join('\n').slice(0, 6000));
}
main().catch((e) => { console.error(e); process.exit(1); });
