const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const want: [number, string, number][] = [[3,'l3u11m1',2],[4,'l4u12m1',2],[4,'l4u12m5',2],[6,'l6u19m4',1],[3,'l3u11m1',1],[3,'l3u11m1',0],[4,'l4u13m3',2],[4,'l4u14m1',2],[4,'l4u14m3',2],[4,'l4u14m2',2],[5,'l5u16m5',0],[5,'l5u15m3',1],[6,'l6u19m1',1],[6,'l6u18m1',0],[7,'l7u21m2',2],[7,'l7u22m4',2],[7,'l7u23m1',0],[8,'l8u27m1',1],[6,'l6u18m4',0],[9,'l9u32m4',0],[3,'l3u9m4',0]];
(async () => {
  for (const [n, id, ci] of want) {
    const cur = (await import(`${R}/core/constants/curriculumL${n}.ts`))[`L${n}_UNITS`] as any[];
    const m = cur.flatMap((u: any) => u.modules).find((x: any) => x.id === id);
    const pt = (await import(`${R}/i18n/content/pt/curriculumL${n}.ts`)).default.modules[id];
    const es = (await import(`${R}/i18n/content/es/curriculumL${n}.ts`)).default.modules[id];
    const c = m.concepts[ci];
    console.log(`## ${id}.concepts[${ci}]  query=${JSON.stringify(c.tryThisQuery)}\n  EN label: ${c.tryThisLabel}\n  PT label: ${pt.concepts[ci].tryThisLabel}\n  ES label: ${es.concepts[ci].tryThisLabel}\n  EN expl: ${c.explanation.slice(0,700)}\n  PT expl: ${pt.concepts[ci].explanation.slice(0,700)}\n`);
  }
})();
