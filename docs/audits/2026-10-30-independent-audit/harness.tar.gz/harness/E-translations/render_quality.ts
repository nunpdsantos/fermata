const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
(async () => {
  const { generateAllForLevel } = await import(`${R}/data/exercises/exerciseGenerator.ts`);
  const { applyTemplateOverlay } = await import(`${R}/i18n/content/contentResolver.ts`);
  const labels = new Set<string>(); const prompts: string[] = [];
  for (let n = 1; n <= 9; n++) {
    const en = (await import(`${R}/data/exercises/templatesL${n}.ts`)).default as any[];
    for (const lang of ['pt', 'es'] as const) {
      const ov = (await import(`${R}/i18n/content/${lang}/templatesL${n}.ts`)).default;
      const gen = generateAllForLevel(applyTemplateOverlay(en, ov), lang) as Record<string, any[]>;
      for (const exs of Object.values(gen)) for (const e of exs) {
        if (e.config.type === 'ear_training' && (e.config.mode === 'chord' || e.config.mode === 'scale')) e.config.choices.forEach((c: any) => labels.add(`${lang} ${e.config.mode}: ${c.label}`));
        if (e.config.type === 'chord_build' && /quality/.test(JSON.stringify(en.find((c) => c.moduleId === e.id.replace(/g\d+$/, ''))?.templates.map((t: any) => t.promptTemplate)))) prompts.push(`${lang} ${e.id}: ${e.prompt}`);
      }
    }
  }
  console.log([...labels].sort().join('\n'));
  console.log('--- chord_build prompts using {quality} (sample)');
  console.log(prompts.slice(0, 400).filter((p, i, a) => a.findIndex((q) => q.split(': ')[1].replace(/\b[A-G][#b]?\b/g, 'X') === p.split(': ')[1].replace(/\b[A-G][#b]?\b/g, 'X')) === i).join('\n'));
})();
