/*
 * Render every generated curriculum exercise (EN/PT/ES) and every drill item
 * (EN/PT/ES), then check:
 *  - generated configs identical across languages (grading parity) except choice labels
 *  - no leftover {tokens}; no English scale/quality words in PT/ES prompts
 *  - musicTerms dictionary covers every scaleType/quality the templates use
 *  - drill: rendered PT/ES strings containing English words
 * Run: cd <repo> && npx tsx render_generated.ts [--plant]
 */
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
import fs from 'node:fs';
import i18next from '/Users/nunosantos/Documents/Base/Music/new_music_app/node_modules/i18next/dist/esm/i18next.js';
const OUT = '/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/E-translations';
const PLANT = process.argv.includes('--plant');

const ENGLISH = /(?<![\p{L}])(major|minor|harmonic|melodic|dorian|phrygian|lydian|mixolydian|locrian|pentatonic|whole tone|chromatic|diminished|augmented|dominant|half|seventh|chord|scale|ascending|descending|cadence|Tonic|Predominant|Dominant|perfect|imperfect|plagal|interrupted|deceptive|authentic|Root|Octave|Tritone|Minor|Major|Perfect|Augmented|Diminished|up|down|toward|the|from|then|lower|raise)(?![\p{L}])/gu;

async function main() {
  const lines: string[] = [];
  const { generateAllForLevel } = await import(`${R}/data/exercises/exerciseGenerator.ts`);
  const { applyTemplateOverlay } = await import(`${R}/i18n/content/contentResolver.ts`);
  const mt = await import(`${R}/i18n/content/musicTerms.ts`);
  const musicTermsSrc = fs.readFileSync(`${R}/i18n/content/musicTerms.ts`, 'utf8');

  // ---- musicTerms coverage ----
  const usedScale = new Set<string>(), usedQual = new Set<string>(), usedDir = new Set<string>();
  let genCount = 0, configDiff = 0, leftovers = 0, englishHits = 0;
  for (let n = 1; n <= 9; n++) {
    const en = (await import(`${R}/data/exercises/templatesL${n}.ts`)).default as any[];
    for (const c of en) for (const t of c.templates) {
      (t.params.scaleTypes ?? []).forEach((s: string) => usedScale.add(s));
      (t.params.chordQualities ?? []).forEach((s: string) => usedQual.add(s));
      (t.params.directions ?? []).forEach((s: string) => usedDir.add(s));
    }
    const genEn = generateAllForLevel(en, 'en');
    for (const lang of ['pt', 'es'] as const) {
      const ov = (await import(`${R}/i18n/content/${lang}/templatesL${n}.ts`)).default;
      const gen = generateAllForLevel(applyTemplateOverlay(en, ov), lang);
      for (const [mod, exs] of Object.entries(genEn) as [string, any[]][]) {
        const other = (gen as any)[mod] as any[] | undefined;
        if (!other || other.length !== exs.length) { lines.push(`GEN-COUNT ${lang} ${mod}: EN ${exs.length} vs ${other?.length}`); configDiff++; continue; }
        exs.forEach((e, i) => {
          if (lang === 'pt') genCount++;
          const o = other[i];
          const strip = (c: any) => JSON.stringify({ ...c, choices: c.choices?.map((x: any) => x.correct) });
          if (strip(e.config) !== strip(o.config)) { lines.push(`GEN-CONFIG-DIFF ${lang} ${e.id}\n  EN ${JSON.stringify(e.config)}\n  ${lang} ${JSON.stringify(o.config)}`); configDiff++; }
          if (e.config.choices && o.config.choices) {
            // correct-index parity
            const ei = e.config.choices.findIndex((x: any) => x.correct), oi = o.config.choices.findIndex((x: any) => x.correct);
            if (ei !== oi) { lines.push(`GEN-CORRECT-IDX ${lang} ${e.id}`); configDiff++; }
          }
          let text = `${o.prompt} || ${o.hint}`;
          if (PLANT && lang === 'pt' && genCount === 1) text += ' {root} major';
          if (/\{[a-zA-Z]+\}/.test(text)) { lines.push(`GEN-LEFTOVER ${lang} ${o.id}: ${text}`); leftovers++; }
          const eng = [...text.matchAll(ENGLISH)].map((m) => m[0]);
          const choiceEng = (o.config.choices ?? []).flatMap((c: any) => [...c.label.matchAll(ENGLISH)].map((m) => m[0]));
          if (eng.length || choiceEng.length) { lines.push(`GEN-ENGLISH ${lang} ${o.id} ${JSON.stringify([...eng, ...choiceEng])}: ${text.slice(0, 200)} ${o.config.choices ? '| choices: ' + o.config.choices.map((c: any) => c.label).join(' / ') : ''}`); englishHits++; }
        });
      }
    }
  }
  lines.unshift(`# generated exercises per lang: ${genCount}; config/grading diffs: ${configDiff}; leftover tokens: ${leftovers}; strings with English words: ${englishHits}`);
  // dictionary coverage
  for (const [label, set, fn] of [['scaleType', usedScale, mt.translateScaleType], ['quality', usedQual, mt.translateChordQuality], ['direction', usedDir, mt.translateDirection]] as const) {
    for (const k of set) for (const lang of ['pt', 'es'] as const) {
      const v = (fn as any)(k, lang);
      if (v === k.replace(/_/g, ' ') && !/blues/.test(k)) lines.push(`MUSICTERMS-MISSING ${lang} ${label} '${k}' -> falls back to '${v}'`);
    }
  }
  lines.push(`# template vocab used: scaleTypes ${[...usedScale]}; qualities ${[...usedQual]}; directions ${[...usedDir]}`);

  // ---- Drill rendering ----
  const loc = (l: string) => JSON.parse(fs.readFileSync(`${R}/i18n/locales/${l}.json`, 'utf8'));
  await i18next.init({ resources: { en: { translation: loc('en') }, pt: { translation: loc('pt') }, es: { translation: loc('es') } }, lng: 'en', fallbackLng: 'en', interpolation: { escapeValue: false } });
  const { generateDrillBank } = await import(`${R}/core/utils/drillBank/index.ts`);
  const bank = generateDrillBank();
  const famEng: Record<string, number> = {};
  const samples: Record<string, string[]> = {};
  for (const lang of ['pt', 'es']) {
    let hit = 0;
    for (const it of bank as any[]) {
      const p = i18next.t(it.promptKey, { ...it.promptParams, lng: lang });
      const w = i18next.t(it.whyKey, { ...it.whyParams, lng: lang });
      const ch = it.input?.choices ?? [];
      const all = [p, w, ...ch].join(' || ');
      const eng = [...all.matchAll(ENGLISH)].map((m) => m[0]);
      if (eng.length) {
        hit++;
        const k = `${lang}:${it.family}`;
        famEng[k] = (famEng[k] ?? 0) + 1;
        (samples[k] ??= []).length < 3 && samples[k].push(`  ${it.id}\n    prompt: ${p}\n    why: ${w}\n    choices: ${ch.join(' / ')}`);
      }
    }
    lines.push(`# drill ${lang}: ${bank.length} items, ${hit} render English words (prompt/why/choices)`);
  }
  lines.push(`# drill English by family: ${JSON.stringify(famEng)}`);
  for (const [k, v] of Object.entries(samples)) lines.push(`## ${k}`, ...v);
  // plural check: legacy _plural keys
  for (const lang of ['en', 'pt', 'es']) {
    lines.push(`# i18next ${i18next.constructor.name} plural render ${lang}: scaleMissing count=2 -> "${i18next.t('exerciseFeedback.scaleMissing', { count: 2, lng: lang })}" ; count=1 -> "${i18next.t('exerciseFeedback.scaleMissing', { count: 1, lng: lang })}"; panel.octaveCount n=2 -> "${i18next.t('panel.octaveCount', { n: 2, lng: lang })}"`);
  }
  fs.writeFileSync(`${OUT}/render_generated${PLANT ? '.plant' : ''}.out.txt`, lines.join('\n'));
  console.log(lines.filter((l) => l.startsWith('#') || l.startsWith('MUSICTERMS')).join('\n'));
}
main().catch((e) => { console.error(e); process.exit(1); });
