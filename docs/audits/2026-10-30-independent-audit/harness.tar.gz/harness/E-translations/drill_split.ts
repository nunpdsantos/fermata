const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
import fs from 'node:fs';
import i18next from '/Users/nunosantos/Documents/Base/Music/new_music_app/node_modules/i18next/dist/esm/i18next.js';
(async () => {
  const loc = (l: string) => JSON.parse(fs.readFileSync(`${R}/i18n/locales/${l}.json`, 'utf8'));
  await i18next.init({ resources: { en: { translation: loc('en') }, pt: { translation: loc('pt') } }, lng: 'pt', fallbackLng: 'en', interpolation: { escapeValue: false } });
  const { generateDrillBank } = await import(`${R}/core/utils/drillBank/index.ts`);
  const bank = generateDrillBank() as any[];
  const fam: Record<string, number> = {};
  const cats = { degreeNames: 0, keyModeWords: 0, functionOrCadence: 0, englishClause: 0, anyNotCovered: 0 };
  const DEG = /\b(Tonic|Supertonic|Mediant|Subdominant|Dominant|Submediant|Leading tone|Subtonic)\b/;
  const KEY = /\b[A-G][♯♭#b]? (major|minor)\b/; // key / scale names e.g. "C major"
  const FUNC = /(pre-dominant|cadence|\(RU:|perfect\)|imperfect\)|plagal\)|interrupted\))/;
  const CLAUSE = /\b(home|away from tonic|builds tension|creates rest|the reference stack|with the 7th lowered|lowered|then)\b/;
  for (const it of bank) {
    fam[it.family] = (fam[it.family] ?? 0) + 1;
    const txt = [i18next.t(it.promptKey, it.promptParams), i18next.t(it.whyKey, it.whyParams), ...(it.input?.choices ?? [])].join(' || ');
    let any = false;
    if (DEG.test(txt)) { cats.degreeNames++; any = true; }
    if (KEY.test(txt) && (it.family === 'keysig' || it.family === 'scale' || it.family === 'roman' || it.family === 'function' || it.family === 'circle' || it.family === 'degree')) { cats.keyModeWords++; any = true; }
    if (FUNC.test(txt)) { cats.functionOrCadence++; any = true; }
    if (CLAUSE.test(txt)) { cats.englishClause++; }
    if (any) cats.anyNotCovered++;
  }
  console.log('family sizes', JSON.stringify(fam));
  console.log('PT drill items showing English outside the chord-quality/interval convention:', JSON.stringify(cats), 'of', bank.length);
})();
