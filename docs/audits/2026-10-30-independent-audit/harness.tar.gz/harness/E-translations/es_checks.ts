/*
 * Spanish-specific mechanical checks over every ES string (overlays + es.json):
 *  - closing ? / ! without the opening ¿ / ¡ in the same sentence (RAE: signos dobles)
 *  - opening ¿/¡ without closing
 *  - English quotes "..." vs Spanish «...» consistency (inventory only)
 *  - ASCII ordinals 3.a / 7.o vs 3.ª / 7.º
 *  - leftover PT words in ES (copy-paste contamination): não, você, também, então, ção, ões, lh, nh
 * Run: cd <repo> && npx tsx es_checks.ts [--plant]
 */
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
import fs from 'node:fs';
const OUT = '/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/E-translations';
const PLANT = process.argv.includes('--plant');
function walk(o: unknown, path: string, acc: [string, string][]) {
  if (typeof o === 'string') acc.push([path, o]);
  else if (Array.isArray(o)) o.forEach((v, i) => walk(v, `${path}[${i}]`, acc));
  else if (o && typeof o === 'object') for (const [k, v] of Object.entries(o)) walk(v, path ? `${path}.${k}` : k, acc);
}
async function main() {
  const strings: [string, string][] = [];
  for (const f of fs.readdirSync(`${R}/i18n/content/es`).filter((x) => x.endsWith('.ts'))) walk((await import(`${R}/i18n/content/es/${f}`)).default, f.replace('.ts', ''), strings);
  walk(JSON.parse(fs.readFileSync(`${R}/i18n/locales/es.json`, 'utf8')), 'es.json', strings);
  if (PLANT) strings.push(['planted', 'Cual es la tónica? Hola! ¿Bien? Não sei. 3.a nota']);
  const out: string[] = [`ES strings: ${strings.length}`];
  const cats: Record<string, string[]> = { missingOpenQ: [], missingOpenE: [], ptLeak: [], asciiOrd: [] };
  for (const [p, s] of strings) {
    // split into sentences on . : ; — keep ? ! attached
    const segs = s.split(/(?<=[.;:])\s+|\s+—\s+|\s+--\s+/);
    for (const seg of segs) {
      const q = (seg.match(/\?/g) ?? []).length, oq = (seg.match(/¿/g) ?? []).length;
      const e = (seg.match(/!/g) ?? []).length, oe = (seg.match(/¡/g) ?? []).length;
      if (q > oq) cats.missingOpenQ.push(`${p}: ${seg.slice(0, 160)}`);
      if (e > oe) cats.missingOpenE.push(`${p}: ${seg.slice(0, 160)}`);
    }
    if (/(?<![\p{L}])(?:não|você|também|então|também|muito|uma|são|está-se|ção|ções)(?![\p{L}])|ões(?![\p{L}])/u.test(s)) cats.ptLeak.push(`${p}: ${s.slice(0, 160)}`);
    if (/\b\d+\.(?:a|o|as|os)(?![\p{L}])/u.test(s)) cats.asciiOrd.push(`${p}: ${(s.match(/\b\d+\.(?:a|o|as|os)(?![\p{L}])/gu) ?? []).join(',')}`);
  }
  for (const [k, v] of Object.entries(cats)) { out.push(`\n### ${k}: ${v.length}`); out.push(...v); }
  fs.writeFileSync(`${OUT}/es_checks${PLANT ? '.plant' : ''}.out.txt`, out.join('\n'));
  console.log(out.filter((l) => l.startsWith('\n###') || l.startsWith('ES')).join(''));
}
main().catch((e) => { console.error(e); process.exit(1); });
