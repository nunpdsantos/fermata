#!/usr/bin/env python3
"""
Staleness check: EN source text changed AFTER the PT/ES overlay entry was last edited.
Uses read-only `git blame --line-porcelain` (PT blame ignores the diacritics-only
mass commit 228f541 so it does not mask staleness).
Granularity: hand-authored exercise id; template module id; curriculum module id.
Run: python3 -I staleness.py
"""
import subprocess, re, sys, collections, json

REPO = '/Users/nunosantos/Documents/Base/Music/new_music_app'
OUT = '/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/E-translations'
IGNORE = {'pt': ['228f541'], 'es': [], 'en': []}

def blame(path, lang):
    args = ['git', '-C', REPO, 'blame', '--line-porcelain']
    for r in IGNORE[lang]:
        args += ['--ignore-rev', r]
    args.append(path)
    out = subprocess.run(args, capture_output=True, text=True, check=True).stdout
    lines, cur = [], {}
    for ln in out.split('\n'):
        if ln.startswith('\t'):
            lines.append((cur.get('sha', '')[:7], int(cur.get('committer-time', '0')), ln[1:]))
        elif re.match(r'^[0-9a-f]{40} ', ln):
            cur = {'sha': ln.split()[0]}
        elif ln.startswith('committer-time '):
            cur['committer-time'] = ln.split()[1]
    return lines

TEXT_LINE = re.compile(r"(prompt|hint|label|promptTemplate|hintTemplate|title|subtitle|explanation|instruction|tryThisLabel|description)\s*:|^\s*['\"`]")

def blocks(lines, start_re, text_only=True):
    """Return {key: (max_time, sha)} where blocks start at lines matching start_re."""
    res = {}
    key = None
    for sha, t, txt in lines:
        m = start_re.search(txt)
        if m:
            key = m.group(1)
        if key is None:
            continue
        if text_only and not TEXT_LINE.search(txt):
            continue
        if key not in res or t > res[key][0]:
            res[key] = (t, sha)
    return res

def main(plant=False):
    rows = []
    for n in range(1, 10):
        en_ex = blame(f'src/data/exercises/exercisesL{n}.ts', 'en')
        en_ex_b = blocks(en_ex, re.compile(r"id:\s*'(l\d+u\d+m\d+e[\w]+)'"))
        en_tm = blame(f'src/data/exercises/templatesL{n}.ts', 'en')
        en_tm_b = blocks(en_tm, re.compile(r"moduleId:\s*'(l\d+u\d+m\d+)'"))
        en_cu = blame(f'src/core/constants/curriculumL{n}.ts', 'en')
        en_cu_b = blocks(en_cu, re.compile(r"\bid:\s*'(l\d+u\d+m\d+)'"))
        for lang in ['pt', 'es']:
            ov_ex = blocks(blame(f'src/i18n/content/{lang}/exercisesL{n}.ts', lang), re.compile(r"^\s{2}(l\d+u\d+m\d+e[\w]+):\s*\{"), text_only=False)
            ov_tm = blocks(blame(f'src/i18n/content/{lang}/templatesL{n}.ts', lang), re.compile(r"^\s{2}(l\d+u\d+m\d+):\s*\["), text_only=False)
            ov_cu = blocks(blame(f'src/i18n/content/{lang}/curriculumL{n}.ts', lang), re.compile(r"^\s{4}(l\d+u\d+m\d+):\s*\{"), text_only=False)
            for kind, en_b, ov_b in [('exercise', en_ex_b, ov_ex), ('template', en_tm_b, ov_tm), ('curriculum', en_cu_b, ov_cu)]:
                for key, (t, sha) in en_b.items():
                    if key not in ov_b:
                        rows.append((lang, kind, key, 'NO-OVERLAY-BLOCK', sha, '', 0))
                        continue
                    ot, osha = ov_b[key]
                    if plant and key == 'l1u1m1e1':
                        ot = 0
                    if t > ot:
                        rows.append((lang, kind, key, 'EN-NEWER', sha, osha, t - ot))
    # sanity: block parsing found things
    with open(f'{OUT}/staleness{".plant" if plant else ""}.out.txt', 'w') as f:
        cnt = collections.Counter((r[0], r[1], r[3]) for r in rows)
        f.write('# counts ' + json.dumps({f'{k[0]}:{k[1]}:{k[2]}': v for k, v in cnt.items()}) + '\n')
        bysha = collections.Counter((r[0], r[1], r[4]) for r in rows if r[3] == 'EN-NEWER')
        f.write('# EN-newer by (lang, kind, EN commit): ' + json.dumps({f'{a}:{b}:{c}': v for (a, b, c), v in bysha.items()}) + '\n')
        for r in rows:
            f.write(f'{r[0]}\t{r[1]}\t{r[2]}\t{r[3]}\tEN@{r[4]}\tOV@{r[5]}\tdays={r[6]/86400:.0f}\n')
    print(open(f'{OUT}/staleness{".plant" if plant else ""}.out.txt').read().split('\n')[:2])

if __name__ == '__main__':
    main('--plant' in sys.argv)
