/*
 * Track E structural audit — exhaustive parity checks for PT/ES vs EN.
 * Run: cd <repo> && npx tsx <this file> [--plant]
 * --plant injects known-bad cases to prove each check can fail.
 */
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
import fs from 'node:fs';

const PLANT = process.argv.includes('--plant');
const out: string[] = [];
const log = (s: string) => out.push(s);
const counts: Record<string, number> = {};
const bump = (k: string, n = 1) => (counts[k] = (counts[k] ?? 0) + n);

// ---------- 1. Locale JSON ----------
type J = Record<string, unknown>;
function flatten(o: J, p = ''): Record<string, string> {
  const r: Record<string, string> = {};
  for (const [k, v] of Object.entries(o)) {
    const key = p ? `${p}.${k}` : k;
    if (v && typeof v === 'object') Object.assign(r, flatten(v as J, key));
    else r[key] = String(v);
  }
  return r;
}
const en = flatten(JSON.parse(fs.readFileSync(`${R}/i18n/locales/en.json`, 'utf8')));
const loc: Record<string, Record<string, string>> = {
  pt: flatten(JSON.parse(fs.readFileSync(`${R}/i18n/locales/pt.json`, 'utf8'))),
  es: flatten(JSON.parse(fs.readFileSync(`${R}/i18n/locales/es.json`, 'utf8'))),
};
if (PLANT) {
  delete loc.pt['nav.explore'];
  loc.es['planted.extra'] = 'x';
  const k = Object.keys(en).find((x) => /\{\{/.test(en[x]))!;
  loc.pt[k] = loc.pt[k].replace(/\{\{(\w+)\}\}/, '{{wrong}}');
}
const PH = /\{\{\s*([\w.]+)\s*\}\}/g;
const phs = (s: string) => [...new Set([...s.matchAll(PH)].map((m) => m[1]))].sort().join(',');
const PLURAL = /_(zero|one|two|few|many|other)$/;
log(`# Locale JSON: EN ${Object.keys(en).length} leaf keys; PT ${Object.keys(loc.pt).length}; ES ${Object.keys(loc.es).length}`);
for (const lang of ['pt', 'es']) {
  const L = loc[lang];
  for (const k of Object.keys(en)) {
    if (!(k in L)) { log(`LOCALE-MISSING ${lang} ${k} EN="${en[k]}"`); bump(`locale-missing-${lang}`); continue; }
    if (phs(en[k]) !== phs(L[k])) { log(`LOCALE-PLACEHOLDER ${lang} ${k}\n  EN: ${en[k]}\n  ${lang}: ${L[k]}`); bump(`locale-ph-${lang}`); }
    if (L[k].trim() === '' && en[k].trim() !== '') { log(`LOCALE-EMPTY ${lang} ${k}`); bump(`locale-empty-${lang}`); }
    if (L[k] === en[k] && /[a-z]{3,}/i.test(en[k])) { log(`LOCALE-IDENTICAL-TO-EN ${lang} ${k} = "${en[k]}"`); bump(`locale-identical-${lang}`); }
  }
  for (const k of Object.keys(L)) if (!(k in en)) { log(`LOCALE-EXTRA ${lang} ${k} = "${L[k]}"`); bump(`locale-extra-${lang}`); }
  // plural forms: if EN has foo_one/foo_other, lang must have the same base forms (pt/es use one/other; pt also 'many' in newer CLDR)
  const bases = new Set(Object.keys(en).filter((k) => PLURAL.test(k)).map((k) => k.replace(PLURAL, '')));
  for (const b of bases) {
    const enF = Object.keys(en).filter((k) => k.replace(PLURAL, '') === b && PLURAL.test(k)).map((k) => k.match(PLURAL)![1]).sort();
    const lF = Object.keys(L).filter((k) => k.replace(PLURAL, '') === b && PLURAL.test(k)).map((k) => k.match(PLURAL)![1]).sort();
    if (enF.join() !== lF.join()) { log(`LOCALE-PLURAL ${lang} ${b}: EN[${enF}] ${lang}[${lF}]`); bump(`locale-plural-${lang}`); }
  }
}
// Count-bearing keys without plural forms (EN interpolates {{count}} but no _one/_other)
for (const k of Object.keys(en)) {
  if (/\{\{\s*count\s*\}\}/.test(en[k]) && !PLURAL.test(k)) { log(`LOCALE-COUNT-NO-PLURAL ${k} EN="${en[k]}" PT="${loc.pt[k]}" ES="${loc.es[k]}"`); bump('locale-count-no-plural'); }
}

// ---------- 2..5 overlays (async imports) ----------
async function main() {
  const levels = [1, 2, 3, 4, 5, 6, 7, 8, 9];
  const totals = { modules: 0, concepts: 0, tasks: 0, objectives: 0, exercises: 0, exChoices: 0, templates: 0, tmplModules: 0, songs: 0 };
  for (const n of levels) {
    const cur = (await import(`${R}/core/constants/curriculumL${n}.ts`))[`L${n}_UNITS`] as any[];
    const exEn = (await import(`${R}/data/exercises/exercisesL${n}.ts`)).default as Record<string, any[]>;
    const tmEn = (await import(`${R}/data/exercises/templatesL${n}.ts`)).default as any[];
    for (const lang of ['pt', 'es']) {
      const cov = structuredClone((await import(`${R}/i18n/content/${lang}/curriculumL${n}.ts`)).default) as any;
      const xov = structuredClone((await import(`${R}/i18n/content/${lang}/exercisesL${n}.ts`)).default) as any;
      const tov = structuredClone((await import(`${R}/i18n/content/${lang}/templatesL${n}.ts`)).default) as any;
      if (PLANT && n === 1 && lang === 'pt') {
        cov.modules['l1u1m1'].concepts.pop();
        delete cov.units['u1'];
        xov['l1u1m1e4'].choices.pop();
        xov['planted_ghost'] = { prompt: 'x' };
        delete xov['l1u1m1e1'].hint;
        const firstT = Object.keys(tov)[0];
        tov[firstT].push({ promptTemplate: 'x', hintTemplate: 'y' });
      }
      // Curriculum
      for (const u of cur) {
        if (!cov.units[u.id]) { log(`CUR-UNIT-MISSING ${lang} L${n} ${u.id} "${u.title}"`); bump(`cur-unit-missing-${lang}`); }
        for (const m of u.modules) {
          if (lang === 'pt') { totals.modules++; totals.concepts += m.concepts.length; totals.tasks += m.tasks.length; totals.objectives += m.objectives.length; }
          const o = cov.modules[m.id];
          if (!o) { log(`CUR-MODULE-MISSING ${lang} ${m.id}`); bump(`cur-mod-missing-${lang}`); continue; }
          for (const f of ['concepts', 'tasks', 'objectives'] as const) {
            if ((o[f]?.length ?? 0) !== m[f].length) { log(`CUR-COUNT ${lang} ${m.id}.${f}: EN ${m[f].length} vs ${o[f]?.length}`); bump(`cur-count-${lang}`); }
          }
          for (const [i, c] of (o.concepts ?? []).entries()) {
            for (const f of ['title', 'explanation', 'tryThisLabel']) if (!c?.[f]?.trim()) { log(`CUR-EMPTY ${lang} ${m.id}.concepts[${i}].${f}`); bump(`cur-empty-${lang}`); }
          }
          for (const f of ['title', 'subtitle']) if (!o[f]?.trim()) { log(`CUR-EMPTY ${lang} ${m.id}.${f}`); bump(`cur-empty-${lang}`); }
        }
      }
      const enModIds = new Set(cur.flatMap((u: any) => u.modules.map((m: any) => m.id)));
      for (const id of Object.keys(cov.modules)) if (!enModIds.has(id)) { log(`CUR-MODULE-EXTRA ${lang} ${id}`); bump(`cur-mod-extra-${lang}`); }
      const enUnitIds = new Set(cur.map((u: any) => u.id));
      for (const id of Object.keys(cov.units)) if (!enUnitIds.has(id)) { log(`CUR-UNIT-EXTRA ${lang} L${n} ${id}`); bump(`cur-unit-extra-${lang}`); }

      // Exercises
      const enEx = Object.values(exEn).flat();
      const enIds = new Set(enEx.map((e) => e.id));
      for (const e of enEx) {
        if (lang === 'pt') { totals.exercises++; }
        const o = xov[e.id];
        if (!o) { log(`EX-MISSING ${lang} ${e.id} (${e.type}) EN prompt="${e.prompt}"`); bump(`ex-missing-${lang}`); continue; }
        if (!o.prompt?.trim()) { log(`EX-EMPTY-PROMPT ${lang} ${e.id}`); bump(`ex-empty-${lang}`); }
        if (e.hint && !o.hint) { log(`EX-HINT-FALLS-BACK-TO-EN ${lang} ${e.id} EN hint="${e.hint}"`); bump(`ex-hint-en-${lang}`); }
        const enCh = (e.config as any).choices as { label: string; correct: boolean }[] | undefined;
        const appliesChoices = e.config.type === 'multiple_choice' || e.config.type === 'ear_training';
        if (enCh && appliesChoices) {
          if (lang === 'pt') totals.exChoices++;
          if (!o.choices) { log(`EX-CHOICES-MISSING ${lang} ${e.id} (EN labels shown): ${JSON.stringify(enCh.map((c) => c.label))}`); bump(`ex-choices-missing-${lang}`); }
          else if (o.choices.length !== enCh.length) { log(`EX-CHOICE-COUNT ${lang} ${e.id}: EN ${enCh.length} vs ${o.choices.length}\n  EN: ${JSON.stringify(enCh.map((c) => c.label))}\n  ${lang}: ${JSON.stringify(o.choices)}`); bump(`ex-choice-count-${lang}`); }
          if (o.choices) {
            const dup = o.choices.filter((c: string, i: number) => o.choices.indexOf(c) !== i);
            if (dup.length) { log(`EX-CHOICE-DUP ${lang} ${e.id}: ${JSON.stringify(dup)}`); bump(`ex-choice-dup-${lang}`); }
          }
        }
        if (o.choices && !(enCh && appliesChoices)) { log(`EX-CHOICES-IGNORED ${lang} ${e.id}: overlay has choices but EN ${e.config.type} has none applied`); bump(`ex-choices-ignored-${lang}`); }
      }
      for (const id of Object.keys(xov)) if (!enIds.has(id)) { log(`EX-EXTRA ${lang} ${id}`); bump(`ex-extra-${lang}`); }

      // Templates
      for (const cfg of tmEn) {
        if (lang === 'pt') { totals.tmplModules++; totals.templates += cfg.templates.length; }
        const o = tov[cfg.moduleId];
        if (!o) { log(`TMPL-MODULE-MISSING ${lang} ${cfg.moduleId} (EN prompts shown): ${cfg.templates.map((t: any) => t.promptTemplate).join(' | ')}`); bump(`tmpl-mod-missing-${lang}`); continue; }
        if (o.length !== cfg.templates.length) { log(`TMPL-COUNT ${lang} ${cfg.moduleId}: EN ${cfg.templates.length} vs ${o.length}`); bump(`tmpl-count-${lang}`); }
        cfg.templates.forEach((t: any, i: number) => {
          const ov = o[i];
          if (!ov) return;
          const cs = t.params.choiceSets as any[][] | undefined;
          if (cs) {
            if (!ov.choiceSets) { log(`TMPL-CHOICESETS-MISSING ${lang} ${cfg.moduleId}[${i}] (EN labels shown)`); bump(`tmpl-cs-missing-${lang}`); }
            else {
              if (ov.choiceSets.length !== cs.length) { log(`TMPL-CHOICESET-COUNT ${lang} ${cfg.moduleId}[${i}]: EN ${cs.length} vs ${ov.choiceSets.length}`); bump(`tmpl-cs-count-${lang}`); }
              cs.forEach((set, si) => {
                const os = ov.choiceSets[si];
                if (os && os.length !== set.length) { log(`TMPL-CHOICE-COUNT ${lang} ${cfg.moduleId}[${i}] set ${si}: EN ${set.length} vs ${os.length}\n  EN: ${JSON.stringify(set.map((c: any) => c.label))}\n  ${lang}: ${JSON.stringify(os)}`); bump(`tmpl-choice-count-${lang}`); }
                if (os) { const dup = os.filter((c: string, k: number) => os.indexOf(c) !== k); if (dup.length) { log(`TMPL-CHOICE-DUP ${lang} ${cfg.moduleId}[${i}] set ${si}: ${JSON.stringify(dup)}`); bump(`tmpl-choice-dup-${lang}`); } }
              });
            }
          } else if (ov.choiceSets) { log(`TMPL-CHOICESETS-IGNORED ${lang} ${cfg.moduleId}[${i}]`); bump(`tmpl-cs-ignored-${lang}`); }
        });
      }
      const enT = new Set(tmEn.map((c: any) => c.moduleId));
      for (const id of Object.keys(tov)) if (!enT.has(id)) { log(`TMPL-MODULE-EXTRA ${lang} ${id}`); bump(`tmpl-mod-extra-${lang}`); }
    }
  }

  // Songs
  const songMod = await import(`${R}/data/songReferences.ts`);
  const srcSongs = fs.readFileSync(`${R}/data/songReferences.ts`, 'utf8');
  const allIds = [...new Set([...srcSongs.matchAll(/^\s{2}'?(l\d+u\d+m\d+)'?:\s*\[/gm)].map((m) => m[1]))];
  for (const lang of ['pt', 'es']) {
    const so = structuredClone((await import(`${R}/i18n/content/${lang}/songs.ts`)).default) as Record<string, string[]>;
    for (const id of allIds) {
      const en = songMod.getSongReferences(id);
      if (lang === 'pt') totals.songs += en.length;
      if (!so[id]) { log(`SONG-MODULE-MISSING ${lang} ${id}`); bump(`song-missing-${lang}`); continue; }
      if (so[id].length !== en.length) { log(`SONG-COUNT ${lang} ${id}: EN ${en.length} vs ${so[id].length}`); bump(`song-count-${lang}`); }
    }
    for (const id of Object.keys(so)) if (!allIds.includes(id)) { log(`SONG-EXTRA ${lang} ${id}`); bump(`song-extra-${lang}`); }
  }

  // Level meta
  const LEVEL_METADATA = [...fs.readFileSync(`${R}/data/curriculumLoader.ts`, 'utf8').matchAll(/\{ id: '(l\d)', number/g)].map((m) => ({ id: m[1] }));
  if (LEVEL_METADATA.length !== 9) throw new Error('levelmeta parse failed');
  for (const lang of ['pt', 'es']) {
    const lm = (await import(`${R}/i18n/content/${lang}/levelMeta.ts`)).default as Record<string, any>;
    for (const m of LEVEL_METADATA) if (!lm[m.id]) { log(`LEVELMETA-MISSING ${lang} ${m.id}`); bump(`levelmeta-missing-${lang}`); }
  }

  log(`\n# Totals (EN): ${JSON.stringify(totals)}  songModules=${allIds.length}`);
  log(`# Counts: ${JSON.stringify(counts, null, 0)}`);
  const file = PLANT ? 'structural.plant.out.txt' : 'structural.out.txt';
  fs.writeFileSync(`/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/E-translations/${file}`, out.join('\n'));
  console.log(out.filter((l) => l.startsWith('#')).join('\n'));
}
main().catch((e) => { console.error(e); process.exit(1); });
