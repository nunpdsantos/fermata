const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
(async () => {
  const sp = await import(`${R}/core/utils/scaleParser.ts`);
  const cp = await import(`${R}/core/utils/chordParser.ts`);
  const qs = ['D harmonic minor', 'Ré menor harmónica', 'Re menor armónica', 'escala de Dó maior', 'Dó maior', 'Do mayor', 'Sol mixolídio', 'C major chord', 'acorde de Dó maior', 'Cmaj7', 'Dó7', 'Lá menor'];
  for (const q of qs) {
    const s = sp.extractScaleFromQuery(q); const c = cp.extractChordFromQuery(q);
    console.log(JSON.stringify(q).padEnd(26), 'scale:', s ? sp.formatParsedScaleName(s) : null, '| chord:', c ? cp.formatParsedChordName(c) : null);
  }
})();
