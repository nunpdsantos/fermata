const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src/data/exercises/';
const { generateAllForLevel } = await import(R + 'exerciseGenerator.ts');
for (let L = 1; L <= 9; L++) {
  const g = generateAllForLevel((await import(R + `templatesL${L}.ts`)).default, 'en');
  for (const exs of Object.values(g) as any[]) for (const e of exs) {
    const c = e.config;
    if (['interval_id', 'scale_degree_id', 'note_id'].includes(c.type) || (c.type === 'ear_training' && c.mode === 'interval'))
      console.log(`${e.id} [${c.type}${c.mode ? ':' + c.mode : ''}] ${JSON.stringify({ ...c, type: undefined, choices: undefined })}\n    PROMPT: ${e.prompt}`);
  }
}
