const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src/data/exercises/';
const spellingPromise: string[] = []; const coupled: string[] = [];
for (let L = 1; L <= 9; L++) {
  const tmpl = (await import(R + `templatesL${L}.ts`)).default;
  for (const m of tmpl) for (const t of m.templates) {
    const p = t.params;
    if (t.type === 'chord_build' && p.roots && p.chordQualities && p.roots.length === p.chordQualities.length && p.chordQualities.length > 1)
      coupled.push(`${m.moduleId}: roots=${p.roots.map((r: string, i: number) => r + (p.accidentals?.[i] ?? '')).join(',')} qualities=${p.chordQualities.join(',')}`);
    if ((t.type === 'scale_build' || t.type === 'chord_build') && /sharp|flat|spell|correct (sharps|flats)|enharmonic|letter/i.test(t.promptTemplate))
      spellingPromise.push(`${m.moduleId} [${t.type}]: "${t.promptTemplate}"`);
  }
}
console.log('chord_build templates where roots.length === qualities.length (generator pairs quality to root index):', coupled.length); coupled.forEach((c) => console.log('  ' + c));
console.log('build templates whose prompt asks for spelling (input is pitch-class only):', spellingPromise.length); spellingPromise.forEach((c) => console.log('  ' + c));
