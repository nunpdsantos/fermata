// Probe drill grading: normalisation, near-miss reachability, enharmonic choice distractors.
import { generateDrillBank } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/utils/drillBank/index.ts';
import { gradeAnswer, normalizeDisplay } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/components/drill/grading.ts';
import { parse, pc, fmtA } from './oracle';
const bank = generateDrillBank();
const byId = new Map(bank.map((i) => [i.id, i]));
const show = (label: string, r: unknown) => console.log(`${label}: ${JSON.stringify(r)}`);

// 1. noteChips: unicode, ascii, order, enharmonic, double accidentals
const cdim7 = byId.get('seventh:name-to-notes:C:diminished7')!;
show('C°7 unicode exact', gradeAnswer(cdim7, { format: 'noteChips', notes: ['C', 'E♭', 'G♭', 'B𝄫'] }));
show('C°7 ascii exact', gradeAnswer(cdim7, { format: 'noteChips', notes: ['C', 'Eb', 'Gb', 'Bbb'] }));
show('C°7 reordered', gradeAnswer(cdim7, { format: 'noteChips', notes: ['B𝄫', 'C', 'G♭', 'E♭'] }));
show('C°7 with A instead of B𝄫 (enharmonic)', gradeAnswer(cdim7, { format: 'noteChips', notes: ['C', 'E♭', 'G♭', 'A'] }));
show('C°7 lowercase ascii', gradeAnswer(cdim7, { format: 'noteChips', notes: ['c', 'eb', 'gb', 'bbb'] }));
show('C°7 with stray space', gradeAnswer(cdim7, { format: 'noteChips', notes: ['C ', 'E♭', 'G♭', 'B𝄫'] }));
show('C°7 two single flats ♭♭', gradeAnswer(cdim7, { format: 'noteChips', notes: ['C', 'E♭', 'G♭', 'B♭♭'] }));
// 2. choice: strict string equality
const na = byId.get('interval:note-above:D:M3')!;
show('D M3 above: F♯', gradeAnswer(na, { format: 'choice', choice: 'F♯' }));
show('D M3 above: F# (ascii)', gradeAnswer(na, { format: 'choice', choice: 'F#' }));
show('D M3 above: G♭ (enharmonic distractor)', gradeAnswer(na, { format: 'choice', choice: 'G♭' }));
console.log('  choices offered:', JSON.stringify((na.input as any).choices));
// 3. accidentalSlots: can near-miss ever fire? Enumerate every slot answer differing in one slot.
let slotItems = 0, nearMissReachable = 0;
for (const it of bank) {
  if (it.input.format !== 'accidentalSlots') continue; slotItems++;
  const sp = (it.answer as any).spelled as string[];
  for (let i = 0; i < 7; i++) for (const acc of ['', '♯', '♭']) {
    const tryS = sp.map((s) => s.replace('#', '♯').replace('b', '♭'));
    tryS[i] = it.input.letters[i] + acc;
    const r = gradeAnswer(it, { format: 'accidentalSlots', spelled: tryS });
    if (r.nearMiss) nearMissReachable++;
  }
}
console.log(`accidentalSlots items ${slotItems}; single-slot variants yielding nearMiss: ${nearMissReachable}`);
// 4. rootQuality: near-miss requires a root spelling not among offered roots?
let rqItems = 0, rqNear = 0;
for (const it of bank) {
  if (it.input.format !== 'rootQuality') continue; rqItems++;
  const a = it.answer as any;
  for (const r of it.input.roots) for (const q of it.input.qualities) if (gradeAnswer(it, { format: 'rootQuality', root: r, quality: q }).nearMiss) rqNear++;
}
console.log(`rootQuality items ${rqItems}; offered (root,quality) combos yielding nearMiss: ${rqNear}`);
// 5. choice items whose distractors include an enharmonic respelling of the correct note (graded plain wrong, never nearMiss)
let enhItems = 0; const enhEx: string[] = [];
for (const it of bank) {
  if (it.input.format !== 'choice' || it.answer.kind !== 'choice') continue;
  let cor; try { cor = parse(it.answer.correct); } catch { continue; }
  const enh = it.input.choices.filter((c) => { try { const n = parse(c); return c !== it.answer.correct && (it.answer as any).kind && pc(n) === pc(cor!); } catch { return false; } });
  if (enh.length) { enhItems++; const r = gradeAnswer(it, { format: 'choice', choice: enh[0] }); if (enhEx.length < 4) enhEx.push(`${it.id}: pick ${enh[0]} for ${it.answer.correct} -> ${JSON.stringify(r)}`); }
}
console.log(`choice items with an enharmonic distractor (same pitch, wrong spelling): ${enhItems}`);
enhEx.forEach((e) => console.log('  ' + e));
// 6. normalizeDisplay round-trip of every display string used in the bank
let bad = 0;
for (const it of bank) {
  const strs = it.input.format === 'noteChips' ? it.input.chips : it.input.format === 'rootQuality' ? it.input.roots : [];
  for (const s of strs) { const n = normalizeDisplay(s); if (n !== fmtA(parse(s))) { bad++; console.log('normalize mismatch', s, n); } }
}
console.log('normalizeDisplay mismatches across chips/roots:', bad);
