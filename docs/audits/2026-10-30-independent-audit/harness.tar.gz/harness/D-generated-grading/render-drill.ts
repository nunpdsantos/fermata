// Render each drill item's prompt / choices / answer / why exactly as i18next would interpolate ({{x}} replace) for a language.
import { generateDrillBank } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/utils/drillBank/index.ts';
import { readFileSync, writeFileSync } from 'fs';
const lang = process.argv[2] ?? 'en';
const j = JSON.parse(readFileSync(`/Users/nunosantos/Documents/Base/Music/new_music_app/src/i18n/locales/${lang}.json`, 'utf8'));
const get = (k: string) => k.split('.').reduce((o: any, p) => o?.[p], j);
const interp = (k: string, p: Record<string, unknown>) => {
  const tpl = get(k);
  if (typeof tpl !== 'string') return `<<MISSING ${k}>>`;
  return tpl.replace(/\{\{(\w+)\}\}/g, (_, n) => (n in p ? String(p[n]) : `<<UNSET ${n}>>`));
};
const lines: string[] = [];
for (const it of generateDrillBank()) {
  const a = it.answer as any;
  const ans = a.kind === 'choice' ? a.correct : a.kind === 'notes' ? a.notes.join(' ') : a.kind === 'accidentals' ? a.spelled.join(' ') : `${a.root} ${a.quality}`;
  const inp = it.input as any;
  const opts = inp.choices ?? inp.chips ?? inp.letters ?? [...(inp.roots ?? []), '|', ...(inp.qualities ?? [])];
  lines.push(`${it.id}\n  Q: ${interp(it.promptKey, it.promptParams)}\n  OPTIONS: ${JSON.stringify(opts)}\n  ANSWER(canonicalAnswer shown on wrong): ${ans}\n  WHY: ${interp(it.whyKey, it.whyParams)}`);
}
writeFileSync(`rendered-${lang}.txt`, lines.join('\n'));
console.log('rendered', lines.length, 'items ->', `rendered-${lang}.txt`);
