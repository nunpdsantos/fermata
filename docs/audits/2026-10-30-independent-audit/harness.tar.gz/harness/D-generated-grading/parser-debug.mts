const { parseChordSymbol, chordFromParsed } = await import('/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/utils/chordParser.ts');
for (const s of ['C𝄪mi', 'C##mi', 'Cbbmi', 'C𝄫mi', 'D##mi', 'Ebbmi', 'C##m', 'C##min', 'Ebbm', 'GMm7', 'G Mm7', 'Bbmi', 'Dó', 'Ré menor', 'Lá', 'Fá#m', 'H7', 'Hm']) {
  const p = parseChordSymbol(s);
  console.log(JSON.stringify(s), '->', p ? `${p.root.natural}${p.root.accidental} ${p.quality} [${chordFromParsed(p).notes.map((n: any) => n.natural + n.accidental).join(' ')}]${p.algorithmicDisplayName ? ' algo:' + p.algorithmicDisplayName : ''}` : null);
}
