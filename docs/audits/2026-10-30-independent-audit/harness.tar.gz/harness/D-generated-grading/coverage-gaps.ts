import { generateDrillBank } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/utils/drillBank/index.ts';
import { fifteenMajorKeys, relMinorOf, scale, fmtU } from './oracle';
const bank = generateDrillBank();
const ids = new Set(bank.map((i) => i.id));
// 1. which major / minor scale spellings are missing from the bank (expected: 15 major + 15x3 minor)
const missing: string[] = [];
for (const k of fifteenMajorKeys()) {
  const t = fmtU(k).replace('♯', '#').replace('♭', 'b');
  if (!ids.has(`scale:spell:${t}:major`)) missing.push(`${fmtU(k)} major`);
  const m = relMinorOf(k); const mt = fmtU(m).replace('♯', '#').replace('♭', 'b').toLowerCase();
  for (const ty of ['natural_minor', 'harmonic_minor', 'melodic_minor'] as const)
    if (!ids.has(`scale:spell:${mt}:${ty}`)) missing.push(`${fmtU(m)} ${ty} = ${scale(m, ty).map(fmtU).join(' ')}`);
}
console.log('scale-spelling items absent from bank:', missing.length); missing.forEach((m) => console.log('  ' + m));
// 2. new-item introduction order: fresh items are taken in global rank order, newPerSession=4 (default)
const sorted = [...bank].sort((a, b) => a.rank - b.rank);
const firstIdx: Record<string, number> = {};
sorted.forEach((it, i) => { if (!(it.family in firstIdx)) firstIdx[it.family] = i; });
for (const [f, i] of Object.entries(firstIdx)) console.log(`first ${f} item is fresh-item #${i + 1} -> introduced in session ~${Math.floor(i / 4) + 1} (all families on, 4 new/session)`);
