const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src/data/exercises/';
const { generateAllForLevel } = await import(R + 'exerciseGenerator.ts');
const types: Record<string, number> = {}; const scaleTypes = new Set<string>(); const quals = new Set<string>(); const earModes: Record<string, number> = {};
let gen = 0, auth = 0; const short: string[] = [];
for (let L = 1; L <= 9; L++) {
  const tmpl = (await import(R + `templatesL${L}.ts`)).default;
  const authored = (await import(R + `exercisesL${L}.ts`)).default;
  const g = generateAllForLevel(tmpl, 'en');
  for (const c of tmpl) { const n = (g[c.moduleId] ?? []).length; if (n < c.targetCount) short.push(`${c.moduleId}: ${n}/${c.targetCount}`); }
  for (const [src, map] of [['gen', g], ['auth', authored]] as const) for (const exs of Object.values(map) as any[]) for (const e of exs) {
    src === 'gen' ? gen++ : auth++;
    const c = e.config; types[`${src}:${c.type}`] = (types[`${src}:${c.type}`] ?? 0) + 1;
    if (c.scaleType) scaleTypes.add(c.scaleType); if (c.quality) quals.add(c.quality);
    if (c.type === 'ear_training') earModes[`${src}:${c.mode}`] = (earModes[`${src}:${c.mode}`] ?? 0) + 1;
  }
}
console.log({ gen, auth, types, earModes, scaleTypes: [...scaleTypes], quals: [...quals] });
console.log('modules generating fewer than targetCount:', short.length, short);
