// Known-positive / known-negative checks of the independent oracle (textbook facts).
import { parse, fmtU, fmtA, intervalName, keySig, relMinorOf, relMajorOf, scale, chord, up, diatonicTriads, labelSemis, fifteenMajorKeys } from './oracle';
let fails = 0;
function eq(label: string, got: unknown, exp: unknown) {
  const ok = JSON.stringify(got) === JSON.stringify(exp);
  if (!ok) fails++;
  console.log(`${ok ? 'ok  ' : 'FAIL'} ${label}: got ${JSON.stringify(got)} expected ${JSON.stringify(exp)}`);
}
eq('C-E', intervalName(parse('C'), parse('E')).label, 'Major 3rd');
eq('F-B', intervalName(parse('F'), parse('B')).label, 'Augmented 4th');
eq('B-F', intervalName(parse('B'), parse('F')).label, 'Diminished 5th');
eq('C-E#', intervalName(parse('C'), parse('E#')).label, 'Augmented 3rd');
eq('E-C', intervalName(parse('E'), parse('C')).label, 'Minor 6th');
eq('C#-Bb', intervalName(parse('C#'), parse('Bb')).label, 'Diminished 7th');
eq('F#->Db is NOT a P5', intervalName(parse('F#'), parse('Db')).label, 'Diminished 6th');
eq('P5 above F#', fmtU(up(parse('F#'), 4, 7)), 'C♯');
eq('P5 below Db', fmtU(up(parse('Db'), 3, 5)), 'G♭');
eq('keySig D', [keySig(parse('D')).count, keySig(parse('D')).type], [2, '#']);
eq('keySig Cb', [keySig(parse('Cb')).count, keySig(parse('Cb')).type], [7, 'b']);
eq('keySig F accs', keySig(parse('F')).accs.map(fmtU), ['B♭']);
eq('rel minor Eb', fmtU(relMinorOf(parse('Eb'))), 'C');
eq('rel minor F#', fmtU(relMinorOf(parse('F#'))), 'D♯');
eq('rel major g#', fmtU(relMajorOf(parse('G#'))), 'B');
eq('A harmonic minor', scale(parse('A'), 'harmonic_minor').map(fmtA), ['A', 'B', 'C', 'D', 'E', 'F', 'G#']);
eq('C# major', scale(parse('C#'), 'major').map(fmtA), ['C#', 'D#', 'E#', 'F#', 'G#', 'A#', 'B#']);
eq('Cdim7', chord(parse('C'), 'diminished7').map(fmtA), ['C', 'Eb', 'Gb', 'Bbb']);
eq('Bø7', chord(parse('B'), 'half_diminished7').map(fmtA), ['B', 'D', 'F', 'A']);
eq('C#aug', chord(parse('C#'), 'augmented').map(fmtA), ['C#', 'E#', 'G##']);
eq('C major numerals', diatonicTriads(scale(parse('C'), 'major')).map((d) => d.numeral), ['I', 'ii', 'iii', 'IV', 'V', 'vi', 'vii°']);
eq('A nat minor numerals', diatonicTriads(scale(parse('A'), 'natural_minor')).map((d) => d.numeral), ['i', 'ii°', 'III', 'iv', 'v', 'VI', 'VII']);
eq('A harm minor numerals', diatonicTriads(scale(parse('A'), 'harmonic_minor')).map((d) => d.numeral), ['i', 'ii°', 'III+', 'iv', 'V', 'VI', 'vii°']);
eq('labelSemis Tritone', labelSemis('Tritone'), 6);
eq('labelSemis Perfect 3rd invalid', labelSemis('Perfect 3rd'), null);
eq('labelSemis Minor 6th', labelSemis('Minor 6th'), 8);
eq('15 keys', fifteenMajorKeys().map(fmtU), ['C', 'G', 'D', 'A', 'E', 'B', 'F♯', 'C♯', 'F', 'B♭', 'E♭', 'A♭', 'D♭', 'G♭', 'C♭']);
console.log(fails === 0 ? 'ORACLE SELFTEST: all pass' : `ORACLE SELFTEST: ${fails} FAIL`);
process.exit(fails === 0 ? 0 : 1);
