// For every chord-spelling (noteChips) item: does each non-root chord tone have at least one
// same-letter alternative chip (i.e. does the item actually test the tone's accidental)?
// And for sevenths: is the quality-defining "other" 7th present (e.g. B♭ for C maj7, B for C7)?
import { generateDrillBank } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/utils/drillBank/index.ts';
import { parse, fmtU, up } from './oracle';
const PLANT = process.argv.includes('--plant');
const bank = generateDrillBank().filter((i) => i.input.format === 'noteChips');
if (PLANT) { const it = bank.find((i) => i.id === 'triad:name-to-notes:C:major')!; (it.input as any).chips = ['C', 'E', 'G', 'D', 'F', 'A', 'B', 'C♯', 'D♭', 'F♯', 'A♭', 'B♭']; }
let tested = 0, untested = 0; const perTone: Record<string, number> = {}; const perToneTotal: Record<string, number> = {};
let sevMissingTrap = 0; const examples: string[] = [];
for (const it of bank) {
  const ans = (it.answer as any).notes.map(parse);
  const chips = (it.input as any).chips.map(parse);
  const toneNames = ans.length === 3 ? ['root', '3rd', '5th'] : ['root', '3rd', '5th', '7th'];
  const fam = it.family;
  ans.forEach((n: any, idx: number) => {
    if (idx === 0) return;
    const key = `${fam}:${toneNames[idx]}`;
    perToneTotal[key] = (perToneTotal[key] ?? 0) + 1;
    const alt = chips.some((c: any) => c.L === n.L && c.a !== n.a);
    if (alt) tested++; else { untested++; perTone[key] = (perTone[key] ?? 0) + 1; if (examples.length < 6) examples.push(`${it.id}: no alternative ${n.L}-chip for the ${toneNames[idx]} (${fmtU(n)}); chips=${(it.input as any).chips.join(' ')}`); }
  });
  if (fam === 'seventh') {
    // quality trap: the 7th a half step away (maj7<->m7, m7<->d7)
    const q = it.id.split(':')[3];
    const root = ans[0];
    const trap = q === 'major7' ? up(root, 6, 10) : q === 'diminished7' ? up(root, 6, 10) : up(root, 6, 11);
    if (!chips.some((c: any) => c.L === trap.L && c.a === trap.a)) sevMissingTrap++;
  }
}
console.log(`noteChips items: ${bank.length} (plant=${PLANT})`);
console.log(`non-root chord tones with >=1 same-letter wrong-accidental chip: ${tested}; with NONE (tone untested, pickable by letter alone): ${untested}`);
for (const k of Object.keys(perToneTotal).sort()) console.log(`  ${k}: untested ${perTone[k] ?? 0} / ${perToneTotal[k]}`);
console.log(`seventh items lacking the half-step 7th "quality trap" chip: ${sevMissingTrap} / ${bank.filter(i=>i.family==='seventh').length}`);
console.log('examples:'); examples.forEach((e) => console.log('  ' + e));
