// notes -> name: 21 roots x 10 qualities x every rotation (root position + inversions), spelled by the oracle.
import { parse, fmtA, pc, chord as oChord, LETTERS } from './oracle.ts';
const { identifyChordFromNotes } = await import('/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/utils/reverseChordParser.ts');
const PLANT = process.argv.includes('--plant');
const Q = ['major', 'minor', 'diminished', 'augmented', 'major7', 'dominant7', 'minor7', 'half_diminished7', 'diminished7', 'minor_major7'];
const stats: Record<string, number> = {}; const ex: Record<string, string[]> = {};
const bump = (k: string, e: string) => { stats[k] = (stats[k] ?? 0) + 1; (ex[k] ??= []).length < 4 && ex[k].push(e); };
const toN = (o: any) => ({ natural: o.L, accidental: (['bb', 'b', '', '#', '##'] as const)[o.a + 2] });
for (const L of LETTERS) for (const a of ['', '#', 'b']) for (const q of Q) {
  const root = parse(L + a);
  const tones = oChord(root, q);
  if (tones.some((t) => Math.abs(t.a) > 2)) continue;
  for (let inv = 0; inv < tones.length; inv++) {
    const input = [...tones.slice(inv), ...tones.slice(0, inv)];
    const res = identifyChordFromNotes(input.map(toN));
    let top = res.results[0];
    if (PLANT && L === 'C' && a === '' && q === 'major' && inv === 0) top = { ...top, chord: { ...top.chord, quality: 'minor' } };
    const label = `${input.map(fmtA).join(' ')} (${fmtA(root)} ${q}, inv ${inv})`;
    if (!top) { bump('no-result', label); continue; }
    const tRoot = parse(top.chord.root.natural + top.chord.root.accidental);
    const inPcs = [...new Set(input.map(pc))].sort().join();
    let topPcs = '';
    try { topPcs = [...new Set(oChord(tRoot, top.chord.quality).map(pc))].sort().join(); } catch { topPcs = 'n/a'; }
    if (fmtA(tRoot) === fmtA(root) && top.chord.quality === q) bump(inv === 0 ? 'correct root-pos' : 'correct inversion', label);
    else if (topPcs === inPcs) {
      const sameSpelling = top.chord.notes.map((n: any) => n.natural + n.accidental).sort().join() === input.map(fmtA).sort().join();
      bump(sameSpelling ? 'alternative name, same notes & spelling' : 'alternative name, RESPELLED (name does not match the written notes)', `${label} -> ${fmtA(tRoot)} ${top.chord.quality} [${top.chord.notes.map((n: any) => n.natural + n.accidental).join(' ')}]`);
    } else bump('WRONG', `${label} -> ${fmtA(tRoot)} ${top.chord.quality} conf=${top.confidence}`);
    if (top.confidence !== 'exact') bump('top-not-exact', label);
  }
}
console.log(`plant=${PLANT}`, JSON.stringify(stats, null, 1));
for (const [k, v] of Object.entries(ex)) if (!k.startsWith('correct')) { console.log(k + ':'); v.forEach((e) => console.log('   ' + e)); }
