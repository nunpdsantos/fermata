// For every interval_id exercise (authored + generated, EN): the two notes ExercisePrompt.tsx:42-63 puts on the staff
// (display logic replicated verbatim below), named by the ORACLE from their letters, vs the label the grader accepts.
import { parse, intervalName, labelSemis } from './oracle.ts';
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src/';
const { generateAllForLevel } = await import(R + 'data/exercises/exerciseGenerator.ts');
const { validateAnswer } = await import(R + 'components/learn/exercises/validateExercise.ts');
const PLANT = process.argv.includes('--plant');
// --- replicated display spelling (ExercisePrompt.tsx lines 48-62) ---
const NATURALS = ['C', 'C', 'D', 'D', 'E', 'F', 'F', 'G', 'G', 'A', 'A', 'B'];
const ACCIDENTALS = ['', '#', '', '#', '', '', '#', '', '#', '', '#', ''];
const rootPCs: Record<string, number> = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };
function displayed(c: any) {
  let rootPC = rootPCs[c.root] ?? 0;
  if (c.rootAccidental === '#') rootPC += 1; if (c.rootAccidental === 'b') rootPC -= 1;
  const s = c.direction === 'descending' ? -c.targetSemitones : c.targetSemitones;
  const tpc = (((rootPC + s) % 12) + 12) % 12;
  return { root: c.root + (c.rootAccidental || ''), target: NATURALS[tpc] + ACCIDENTALS[tpc] };
}
const ORD = ['Unison', '2nd', '3rd', '4th', '5th', '6th', '7th', 'Octave'];
let total = 0, mismatch = 0; const rows: string[] = [];
for (let L = 1; L <= 9; L++) {
  const gen = generateAllForLevel((await import(R + `data/exercises/templatesL${L}.ts`)).default, 'en');
  const auth = (await import(R + `data/exercises/exercisesL${L}.ts`)).default;
  for (const [src, map] of [['gen', gen], ['auth', auth]] as const) for (const exs of Object.values(map) as any[]) for (const e of exs) {
    const c = e.config; if (c.type !== 'interval_id') continue;
    total++;
    const d = displayed(c);
    if (PLANT && e.id === 'l1u3m3g6') d.target = 'D#'; // A–D♯ (A4) where a P5 is graded: must be flagged
    const lo = c.direction === 'descending' ? parse(d.target) : parse(d.root);
    const hi = c.direction === 'descending' ? parse(d.root) : parse(d.target);
    const shown = c.targetSemitones === 12 ? (lo.L === hi.L && lo.a === hi.a ? { label: 'Perfect Octave', num: 8 } : { label: '?', num: 0 }) : intervalName(lo, hi);
    const graded = validateAnswer(c, String(c.targetSemitones)).expected as string; // the label the learner must pick
    const gradedNum = graded === 'Tritone' ? null : graded === 'Octave' ? 8 : ORD.indexOf(graded.split(' ')[1]) + 1;
    const shownNum = (shown as any).num;
    const ok = gradedNum === null ? ['Augmented 4th', 'Diminished 5th'].includes(shown.label) : shownNum === gradedNum && (graded === 'Octave' || shown.label === graded);
    if (!ok) { mismatch++; rows.push(`${src}:${e.id} staff shows ${d.root}${c.direction === 'descending' ? ' down to ' : '–'}${d.target} = ${shown.label} (by letters) but the accepted answer is "${graded}" | prompt: ${e.prompt}`); }
  }
}
console.log(`interval_id exercises: ${total} (plant=${PLANT}); notated interval contradicts the graded label: ${mismatch}`);
rows.forEach((r) => console.log(' - ' + r));
