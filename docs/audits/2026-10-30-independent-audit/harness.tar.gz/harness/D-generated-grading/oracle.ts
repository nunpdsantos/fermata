/**
 * Independent first-principles music-theory oracle (audit track D).
 * Imports NOTHING from the app. All facts derived from:
 *   - letter names C D E F G A B with natural pitch classes 0 2 4 5 7 9 11
 *   - interval = (letter distance, semitone distance)
 *   - scale formulas as semitone sets on consecutive letters
 */
export const LETTERS = ['C', 'D', 'E', 'F', 'G', 'A', 'B'] as const;
export type Letter = (typeof LETTERS)[number];
const LPC: Record<Letter, number> = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };

export interface ONote { L: Letter; a: number } // a in semitones, -2..+2 (may exceed for triple)

export const mod12 = (x: number) => ((x % 12) + 12) % 12;
export const pc = (n: ONote) => mod12(LPC[n.L] + n.a);

/** Parse ASCII ("C#", "Bbb", "F##") or unicode ("C♯", "B𝄫", "F𝄪") note names. */
export function parse(s: string): ONote {
  const t = s.trim();
  const L = t[0].toUpperCase() as Letter;
  if (!LETTERS.includes(L)) throw new Error(`bad note ${s}`);
  const rest = t.slice(1);
  let a = 0;
  for (const ch of Array.from(rest)) {
    if (ch === '#' || ch === '♯') a += 1;
    else if (ch === 'b' || ch === '♭') a -= 1;
    else if (ch === '𝄪' || ch === 'x') a += 2;
    else if (ch === '𝄫') a -= 2;
    else throw new Error(`bad accidental in ${s}`);
  }
  return { L, a };
}
export function fmtU(n: ONote): string {
  const m: Record<number, string> = { [-2]: '𝄫', [-1]: '♭', 0: '', 1: '♯', 2: '𝄪' };
  if (!(n.a in m)) return `${n.L}(${n.a})`;
  return n.L + m[n.a];
}
export function fmtA(n: ONote): string {
  const m: Record<number, string> = { [-2]: 'bb', [-1]: 'b', 0: '', 1: '#', 2: '##' };
  if (!(n.a in m)) return `${n.L}(${n.a})`;
  return n.L + m[n.a];
}
export const eqNote = (x: ONote, y: ONote) => x.L === y.L && x.a === y.a;

/** Note `letterSteps` letters above n that sits `semis` semitones above n. */
export function up(n: ONote, letterSteps: number, semis: number): ONote {
  const li = LETTERS.indexOf(n.L);
  const L = LETTERS[(((li + letterSteps) % 7) + 7) % 7];
  let a = mod12(pc(n) + semis - LPC[L]);
  if (a > 6) a -= 12;
  return { L, a };
}

// ---- intervals -------------------------------------------------------------
const BASE = [0, 2, 4, 5, 7, 9, 11]; // major/perfect sizes for numbers 1..7
const PERFECT = new Set([1, 4, 5]);
const ORD = ['Unison', '2nd', '3rd', '4th', '5th', '6th', '7th'];

/** Name the ascending simple interval from lower to upper (within an octave). */
export function intervalName(lower: ONote, upper: ONote): { num: number; qual: string; label: string; semis: number } {
  const num = mod12(0) + (((LETTERS.indexOf(upper.L) - LETTERS.indexOf(lower.L)) % 7) + 7) % 7 + 1;
  const semis = mod12(pc(upper) - pc(lower));
  let d = semis - BASE[num - 1];
  if (d > 6) d -= 12;
  if (d < -6) d += 12;
  let qual: string;
  if (PERFECT.has(num)) qual = d === 0 ? 'Perfect' : d === 1 ? 'Augmented' : d === -1 ? 'Diminished' : d === 2 ? 'Doubly-augmented' : d === -2 ? 'Doubly-diminished' : `?${d}`;
  else qual = d === 0 ? 'Major' : d === -1 ? 'Minor' : d === 1 ? 'Augmented' : d === -2 ? 'Diminished' : `?${d}`;
  return { num, qual, label: `${qual} ${ORD[num - 1]}`, semis };
}

/** Semitone size of a label such as "Major 3rd", "Perfect Unison", "Tritone", "Octave". */
export function labelSemis(label: string): number | null {
  if (label === 'Tritone') return 6;
  if (label === 'Octave' || label === 'Perfect Octave' || label === 'Perfect 8th') return 12;
  const m = label.match(/^(Major|Minor|Perfect|Augmented|Diminished) (Unison|2nd|3rd|4th|5th|6th|7th|8th)$/);
  if (!m) return null;
  const num = ['Unison', '2nd', '3rd', '4th', '5th', '6th', '7th', '8th'].indexOf(m[2]) + 1;
  const base = num === 8 ? 12 : BASE[num - 1];
  const perfect = num === 8 || PERFECT.has(num);
  const q = m[1];
  if (perfect && (q === 'Major' || q === 'Minor')) return null; // non-existent
  if (!perfect && q === 'Perfect') return null; // non-existent
  const delta = perfect
    ? { Perfect: 0, Augmented: 1, Diminished: -1 }[q]!
    : { Major: 0, Minor: -1, Augmented: 1, Diminished: -2 }[q]!;
  return base + delta;
}

// ---- scales ----------------------------------------------------------------
export const FORMULA = {
  major: [0, 2, 4, 5, 7, 9, 11],
  natural_minor: [0, 2, 3, 5, 7, 8, 10],
  harmonic_minor: [0, 2, 3, 5, 7, 8, 11],
  melodic_minor: [0, 2, 3, 5, 7, 9, 11], // ascending form
} as const;
export type ScaleKind = keyof typeof FORMULA;
export function scale(tonic: ONote, kind: ScaleKind): ONote[] {
  return FORMULA[kind].map((s, i) => up(tonic, i, s));
}

export const SHARP_ORDER: Letter[] = ['F', 'C', 'G', 'D', 'A', 'E', 'B'];
export const FLAT_ORDER: Letter[] = ['B', 'E', 'A', 'D', 'G', 'C', 'F'];

/** Key signature of a major key, derived from its scale. Throws if the scale mixes sharps and flats or the set is not a prefix of the standard order. */
export function keySig(majorTonic: ONote): { count: number; type: '#' | 'b' | 'none'; accs: ONote[] } {
  const sc = scale(majorTonic, 'major');
  const sharps = sc.filter((n) => n.a > 0);
  const flats = sc.filter((n) => n.a < 0);
  if (sharps.length && flats.length) throw new Error('mixed signature');
  if (sharps.some((n) => n.a > 1) || flats.some((n) => n.a < -1)) throw new Error('double accidental in major scale');
  if (!sharps.length && !flats.length) return { count: 0, type: 'none', accs: [] };
  const type = sharps.length ? '#' : 'b';
  const altered = new Set((sharps.length ? sharps : flats).map((n) => n.L));
  const order = type === '#' ? SHARP_ORDER : FLAT_ORDER;
  const prefix = order.slice(0, altered.size);
  if (!prefix.every((l) => altered.has(l))) throw new Error('not a prefix of order');
  return { count: altered.size, type, accs: prefix.map((L) => ({ L, a: type === '#' ? 1 : -1 })) };
}
export const relMinorOf = (majorTonic: ONote) => scale(majorTonic, 'major')[5];
export const relMajorOf = (minorTonic: ONote) => scale(minorTonic, 'natural_minor')[2];

// ---- chords ----------------------------------------------------------------
/** [letterSteps, semis] for each chord tone above root. */
export const CHORD_SHAPES: Record<string, [number, number][]> = {
  major: [[0, 0], [2, 4], [4, 7]],
  minor: [[0, 0], [2, 3], [4, 7]],
  diminished: [[0, 0], [2, 3], [4, 6]],
  augmented: [[0, 0], [2, 4], [4, 8]],
  major7: [[0, 0], [2, 4], [4, 7], [6, 11]],
  dominant7: [[0, 0], [2, 4], [4, 7], [6, 10]],
  minor7: [[0, 0], [2, 3], [4, 7], [6, 10]],
  half_diminished7: [[0, 0], [2, 3], [4, 6], [6, 10]],
  diminished7: [[0, 0], [2, 3], [4, 6], [6, 9]],
  minor_major7: [[0, 0], [2, 3], [4, 7], [6, 11]],
  augmented7: [[0, 0], [2, 4], [4, 8], [6, 10]],
  augmented_major7: [[0, 0], [2, 4], [4, 8], [6, 11]],
  major6: [[0, 0], [2, 4], [4, 7], [5, 9]],
  minor6: [[0, 0], [2, 3], [4, 7], [5, 9]],
  sus2: [[0, 0], [1, 2], [4, 7]],
  sus4: [[0, 0], [3, 5], [4, 7]],
  power: [[0, 0], [4, 7]],
  add9: [[0, 0], [2, 4], [4, 7], [1, 14]],
  dominant7sus4: [[0, 0], [3, 5], [4, 7], [6, 10]],
  major9: [[0, 0], [2, 4], [4, 7], [6, 11], [1, 14]],
  minor9: [[0, 0], [2, 3], [4, 7], [6, 10], [1, 14]],
  dominant9: [[0, 0], [2, 4], [4, 7], [6, 10], [1, 14]],
  dominant7flat9: [[0, 0], [2, 4], [4, 7], [6, 10], [1, 13]],
  dominant7sharp9: [[0, 0], [2, 4], [4, 7], [6, 10], [1, 15]],
  dominant7flat5: [[0, 0], [2, 4], [4, 6], [6, 10]],
  dominant7sharp5: [[0, 0], [2, 4], [4, 8], [6, 10]],
  major7flat5: [[0, 0], [2, 4], [4, 6], [6, 11]],
  diminished_major7: [[0, 0], [2, 3], [4, 6], [6, 11]],
  six_nine: [[0, 0], [2, 4], [4, 7], [5, 9], [1, 14]],
  minor_six_nine: [[0, 0], [2, 3], [4, 7], [5, 9], [1, 14]],
  add11: [[0, 0], [2, 4], [4, 7], [3, 17]],
  sus2sus4: [[0, 0], [1, 2], [3, 5], [4, 7]],
  major7sharp11: [[0, 0], [2, 4], [4, 7], [6, 11], [3, 18]],
  dominant7sharp11: [[0, 0], [2, 4], [4, 7], [6, 10], [3, 18]],
  dominant7flat13: [[0, 0], [2, 4], [4, 7], [6, 10], [5, 20]],
  minor11: [[0, 0], [2, 3], [4, 7], [6, 10], [1, 14], [3, 17]],
  dominant13: [[0, 0], [2, 4], [4, 7], [6, 10], [1, 14], [5, 21]],
  major13: [[0, 0], [2, 4], [4, 7], [6, 11], [1, 14], [5, 21]],
  minor13: [[0, 0], [2, 3], [4, 7], [6, 10], [1, 14], [5, 21]],
  dominant9sharp11: [[0, 0], [2, 4], [4, 7], [6, 10], [1, 14], [3, 18]],
  major9sharp11: [[0, 0], [2, 4], [4, 7], [6, 11], [1, 14], [3, 18]],
  dominant13flat9: [[0, 0], [2, 4], [4, 7], [6, 10], [1, 13], [5, 21]],
  dominant9sus4: [[0, 0], [3, 5], [4, 7], [6, 10], [1, 14]],
  dominant11: [[0, 0], [4, 7], [6, 10], [1, 14], [3, 17]],
  major11: [[0, 0], [4, 7], [6, 11], [1, 14], [3, 17]],
  dominant7sharp5flat9: [[0, 0], [2, 4], [4, 8], [6, 10], [1, 13]],
  dominant7flat5flat9: [[0, 0], [2, 4], [4, 6], [6, 10], [1, 13]],
  dominant7sharp5sharp9: [[0, 0], [2, 4], [4, 8], [6, 10], [1, 15]],
  dominant7flat5sharp9: [[0, 0], [2, 4], [4, 6], [6, 10], [1, 15]],
};
export function chord(root: ONote, quality: string): ONote[] {
  const shape = CHORD_SHAPES[quality];
  if (!shape) throw new Error(`oracle: unknown quality ${quality}`);
  return shape.map(([l, s]) => up(root, l, s));
}

/** Classify a 3-note stack (root, third, fifth) by its intervals. */
export function triadQuality(r: ONote, t: ONote, f: ONote): string {
  const third = intervalName(r, t);
  const fifth = intervalName(r, f);
  if (third.num !== 3 || fifth.num !== 5) return '?';
  const key = `${third.qual}/${fifth.qual}`;
  return (
    {
      'Major/Perfect': 'major',
      'Minor/Perfect': 'minor',
      'Minor/Diminished': 'diminished',
      'Major/Augmented': 'augmented',
    } as Record<string, string>
  )[key] ?? '?';
}

/** Diatonic triads of a 7-note scale. */
export function diatonicTriads(sc: ONote[]): { root: ONote; quality: string; numeral: string }[] {
  const ROMAN = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII'];
  return sc.map((root, i) => {
    const q = triadQuality(root, sc[(i + 2) % 7], sc[(i + 4) % 7]);
    let num = ROMAN[i];
    if (q === 'minor' || q === 'diminished') num = num.toLowerCase();
    if (q === 'diminished') num += '°';
    if (q === 'augmented') num += '+';
    return { root, quality: q, numeral: num };
  });
}

/** Harmonic function (standard tonic / predominant / dominant grouping, major key). */
export const FUNCTION_OF: Record<string, 'T' | 'PD' | 'D'> = { I: 'T', vi: 'T', ii: 'PD', IV: 'PD', V: 'D', 'vii°': 'D' };

/** Standard degree names (major-key context). */
export const DEGREE_NAMES = ['Tonic', 'Supertonic', 'Mediant', 'Subdominant', 'Dominant', 'Submediant', 'Leading Tone'];

/** The 15 major keys spelled from first principles: tonics a P5 apart from C going both ways, up to 7 accidentals. */
export function fifteenMajorKeys(): ONote[] {
  const out: ONote[] = [{ L: 'C', a: 0 }];
  let x: ONote = { L: 'C', a: 0 };
  for (let i = 0; i < 7; i++) { x = up(x, 4, 7); out.push(x); }
  x = { L: 'C', a: 0 };
  for (let i = 0; i < 7; i++) { x = up(x, 3, 5); out.push(x); } // P4 up = P5 down (pitch class)
  return out;
}
