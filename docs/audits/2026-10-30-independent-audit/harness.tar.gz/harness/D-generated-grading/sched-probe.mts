const mem = new Map<string, string>();
(globalThis as any).localStorage = { getItem: (k: string) => mem.get(k) ?? null, setItem: (k: string, v: string) => mem.set(k, v), removeItem: (k: string) => mem.delete(k) };
const { applyAnswer, isDue } = await import('/Users/nunosantos/Documents/Base/Music/new_music_app/src/services/drillScheduler.ts');
const { composeSession } = await import('/Users/nunosantos/Documents/Base/Music/new_music_app/src/services/drillSession.ts');
const { generateDrillBank } = await import('/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/utils/drillBank/index.ts');
const { useDrillStore, isSessionComplete, DEFAULT_SETTINGS } = await import('/Users/nunosantos/Documents/Base/Music/new_music_app/src/state/drillStore.ts');
const MIN = 60_000, DAY = 86_400_000;
const t0 = Date.UTC(2026, 9, 1, 9, 0, 0);

// Scenario A: the learner gets the item WRONG on first try in every session, then right on the in-session requeue.
{
  let st: any; const log: string[] = [];
  const sessions = [{ id: 'sA', t: t0 }, { id: 'sB', t: t0 + 2 * DAY }, { id: 'sC', t: t0 + 5 * DAY }];
  for (const s of sessions) {
    st = applyAnswer(st, false, 4000, s.t, s.id); log.push(`${s.id} first try WRONG -> ${st.tier}`);
    st = applyAnswer(st, true, 1200, s.t + 3 * MIN, s.id); log.push(`${s.id} requeue right (1.2s) -> ${st.tier}`);
  }
  console.log('Scenario A (never right first time):'); log.forEach((l) => console.log('  ' + l));
}
// Scenario A-control: same but wrong on the requeue too in session C -> must not be byHeart
{
  let st: any;
  for (const [i, s] of [['sA', t0], ['sB', t0 + 2 * DAY], ['sC', t0 + 5 * DAY]].entries()) {
    st = applyAnswer(st, false, 4000, s[1] as number, s[0] as string);
    st = applyAnswer(st, i < 2, 1200, (s[1] as number) + 3 * MIN, s[0] as string);
  }
  console.log('Scenario A-control (last session ends wrong):', st.tier);
}
// Scenario B: three back-to-back sessions within ~10 minutes, all first-try correct & fast.
{
  let st: any; const log: string[] = [];
  st = applyAnswer(st, true, 2000, t0, 's1'); log.push(`s1 intro correct -> ${st.tier}, due in ${((st.card.due - t0) / MIN).toFixed(1)} min`);
  st = applyAnswer(st, true, 1500, t0 + 2 * MIN, 's1'); log.push(`s1 second exposure correct -> ${st.tier}, due in ${((st.card.due - t0 - 2 * MIN) / MIN).toFixed(1)} min`);
  // is it re-presented 3 minutes later? compose a session with only this item reviewed
  const bank = generateDrillBank();
  const item = bank.find((i: any) => i.id === 'degree:num-to-name:1');
  const states: any = { [item.id]: st };
  const q = composeSession(bank, states, DEFAULT_SETTINGS, t0 + 5 * MIN, 42);
  log.push(`session composed at +5 min: item due? ${isDue(st, t0 + 5 * MIN)}; included in queue? ${q.includes(item.id)} (position ${q.indexOf(item.id)}, queue length ${q.length})`);
  st = applyAnswer(st, true, 1400, t0 + 6 * MIN, 's2'); log.push(`s2 (+6 min) correct -> ${st.tier}`);
  st = applyAnswer(st, true, 1300, t0 + 10 * MIN, 's3'); log.push(`s3 (+10 min) correct -> ${st.tier}`);
  console.log('Scenario B (3 sessions inside 10 minutes):'); log.forEach((l) => console.log('  ' + l));
}
// Scenario C: new learner, default settings — how many questions does session 1 actually contain vs the "of N" shown?
{
  const bank = generateDrillBank();
  const byId = new Map(bank.map((i: any) => [i.id, i]));
  const S = () => useDrillStore.getState();
  S().resetDrillData();
  let now = t0; S().startSession(bank, now);
  while (!isSessionComplete(S().activeSession!, S().settings)) {
    const s = S().activeSession!; now += 4000;
    S().recordAnswer(byId.get(s.queue[s.index]) as any, true, 2000, now);
  }
  const s = S().activeSession!;
  console.log(`Scenario C: default settings length=${S().settings.length}, newPerSession=${S().settings.newPerSession}; session 1 ended after asked=${s.asked} (queue length ${s.queue.length}); QuestionCard denominator = settings.length = ${S().settings.length}`);
}
