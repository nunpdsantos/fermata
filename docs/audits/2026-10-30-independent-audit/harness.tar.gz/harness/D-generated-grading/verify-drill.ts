/**
 * Exhaustive verification of every generated Drill item against the independent oracle.
 * Usage: npx tsx verify-drill.ts [--plant]   (--plant injects known-bad items to prove the checks fire)
 * The app is consulted ONLY for the items under test (generateDrillBank); every expected value is the oracle's.
 */
import { generateDrillBank } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/utils/drillBank/index.ts';
import type { DrillItem } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/types/drill.ts';
import {
  parse, fmtU, fmtA, eqNote, up, intervalName, labelSemis, keySig, relMinorOf, relMajorOf,
  scale, chord, diatonicTriads, FUNCTION_OF, DEGREE_NAMES, SHARP_ORDER, FLAT_ORDER, fifteenMajorKeys,
  type ONote, type ScaleKind,
} from './oracle';

const PLANT = process.argv.includes('--plant');
const bank: DrillItem[] = structuredClone(generateDrillBank());

if (PLANT) {
  // Known-bad cases: each must be caught.
  const set = (id: string, f: (i: DrillItem) => void) => { const it = bank.find((x) => x.id === id); if (!it) throw new Error('plant: no ' + id); f(it); };
  set('interval:note-above:E:M3', (i) => { (i.answer as any).correct = 'A♭'; });        // wrong spelling
  set('triad:name-to-notes:C:major', (i) => { (i.answer as any).notes = ['C', 'E', 'G#']; }); // wrong notes
  set('keysig:rel-minor:Eb', (i) => { (i.answer as any).correct = 'G minor'; });          // wrong key
  set('interval:semitones-to-name:6', (i) => { (i.input as any).choices = ['Tritone', 'Augmented 4th', 'Perfect 4th', 'Perfect 5th']; }); // 2 correct choices
  set('roman:pattern:major:5', (i) => { (i.input as any).choices = ['major (V)', 'major (V)', 'minor (v)', 'diminished (v°)']; }); // duplicate chip
  set('triad:notes-to-name:C:augmented', (i) => { (i.answer as any).root = 'E'; }); // wrong root
  set('interval:pair-to-name:C:E', (i) => { (i.input as any).choices = ['Major 3rd', 'Perfect 3rd', 'Minor 3rd', 'Major 2nd']; }); // non-existent label
  set('scale:spell:D:major', (i) => { (i.answer as any).spelled = ['D', 'E', 'F', 'G', 'A', 'B', 'C#']; });
}

type Problem = { id: string; check: string; detail: string };
const problems: Problem[] = [];
const P = (it: DrillItem, check: string, detail: string) => problems.push({ id: it.id, check, detail });
const choicesOf = (it: DrillItem) => (it.input.format === 'choice' ? it.input.choices : []);
const correctChoice = (it: DrillItem) => (it.answer.kind === 'choice' ? it.answer.correct : null);

/** "C♯ major" / "a minor" / "A natural minor" → tonic + kind */
function parseKey(s: string): { tonic: ONote; kind: ScaleKind | 'minor' } {
  const m = s.match(/^(\S+) (major|minor|natural minor|harmonic minor|melodic minor)$/);
  if (!m) throw new Error('parseKey ' + s);
  const kind = m[2] === 'major' ? 'major' : m[2] === 'minor' ? 'minor' : (m[2].replace(' ', '_') as ScaleKind);
  return { tonic: parse(m[1]), kind };
}
const countStr = (k: ReturnType<typeof keySig>) => (k.type === 'none' ? '0' : `${k.count}${k.type === '#' ? '♯' : '♭'}`);
const KEYS = fifteenMajorKeys();
const TRIAD_Q: Record<string, string> = { major: 'major', minor: 'minor', diminished: 'diminished', augmented: 'augmented' };
const SEV_Q: Record<string, string> = { 'Major 7th': 'major7', 'Dominant 7th': 'dominant7', 'Minor 7th': 'minor7', 'Half-Diminished 7th': 'half_diminished7', 'Diminished 7th': 'diminished7' };

/** The canonical expected answer per item (oracle), plus an optional per-choice correctness predicate. */
function expected(it: DrillItem): { answer: string | string[]; isCorrect?: (c: string) => boolean } | null {
  const p = it.promptParams as Record<string, any>;
  switch (it.promptKey) {
    case 'drill.prompts.keyToCount': {
      const k = parseKey(p.key);
      const major = k.kind === 'major' ? k.tonic : relMajorOf(k.tonic);
      return { answer: countStr(keySig(major)) };
    }
    case 'drill.prompts.keyToAcc': {
      const k = parseKey(p.key);
      return { answer: keySig(k.tonic).accs.map(fmtU).join(' ') };
    }
    case 'drill.prompts.sigToKeyMajor':
    case 'drill.prompts.sigToKeyMinor': {
      const majors = KEYS.filter((t) => countStr(keySig(t)) === p.sig);
      if (majors.length !== 1) return { answer: `AMBIGUOUS(${majors.map(fmtU)})` };
      return it.promptKey.endsWith('Major')
        ? { answer: `${fmtU(majors[0])} major` }
        : { answer: `${fmtU(relMinorOf(majors[0]))} minor` };
    }
    case 'drill.prompts.relMinor': return { answer: `${fmtU(relMinorOf(parse(p.key)))} minor` };
    case 'drill.prompts.relMajor': return { answer: `${fmtU(relMajorOf(parse(p.key)))} major` };
    case 'drill.prompts.nextSharp': { const i = SHARP_ORDER.indexOf(parse(p.acc).L); return { answer: fmtU({ L: SHARP_ORDER[i + 1], a: 1 }) }; }
    case 'drill.prompts.nextFlat': { const i = FLAT_ORDER.indexOf(parse(p.acc).L); return { answer: fmtU({ L: FLAT_ORDER[i + 1], a: -1 }) }; }
    case 'drill.prompts.fifthUp': return { answer: fmtU(up(parse(p.note), 4, 7)) };
    case 'drill.prompts.fifthDown': return { answer: fmtU(up(parse(p.note), 3, 5)) };
    case 'drill.prompts.numToName': return { answer: DEGREE_NAMES[Number(p.num) - 1] };
    case 'drill.prompts.nameToNum': return { answer: String(DEGREE_NAMES.indexOf(p.name) + 1) };
    case 'drill.prompts.pairToName': {
      const n = intervalName(parse(String(p.lower)), parse(String(p.upper)));
      return { answer: n.label, isCorrect: (c) => c === n.label || (c === 'Tritone' && n.semis === 6 && (n.label === 'Augmented 4th' || n.label === 'Diminished 5th')) };
    }
    case 'drill.prompts.noteAbove': {
      const m = String(p.interval).match(/^(major|minor|perfect) (\d)(st|nd|rd|th)$/);
      if (!m) throw new Error('interval ' + p.interval);
      const num = Number(m[2]);
      const semis = labelSemis(`${m[1][0].toUpperCase()}${m[1].slice(1)} ${num}${m[3]}`)!;
      return { answer: fmtU(up(parse(p.root), num - 1, semis)) };
    }
    case 'drill.prompts.letterThird': return { answer: up({ L: p.letter, a: 0 }, 2, 0).L };
    case 'drill.prompts.semitonesToName': {
      const n = Number(p.n);
      const labels: Record<number, string> = { 1: 'Minor 2nd', 2: 'Major 2nd', 3: 'Minor 3rd', 4: 'Major 3rd', 5: 'Perfect 4th', 6: 'Tritone', 7: 'Perfect 5th', 8: 'Minor 6th', 9: 'Major 6th', 10: 'Minor 7th', 11: 'Major 7th', 12: 'Octave' };
      return { answer: labels[n], isCorrect: (c) => labelSemis(c) === n };
    }
    case 'drill.prompts.spellChord': {
      const m = String(p.chord).match(/^(\S+) (.+)$/)!;
      const q = TRIAD_Q[m[2]] ?? SEV_Q[m[2]];
      if (!q) throw new Error('quality ' + m[2]);
      return { answer: chord(parse(m[1]), q).map(fmtA) };
    }
    case 'drill.prompts.nameChord': {
      // answer computed separately (needs input qualities); return the set
      return null;
    }
    case 'drill.prompts.spellScale': {
      const k = parseKey(p.scale);
      return { answer: scale(k.tonic, k.kind === 'minor' ? 'natural_minor' : k.kind).map(fmtA) };
    }
    case 'drill.prompts.degreeOf': {
      const k = parseKey(p.key);
      return { answer: fmtU(scale(k.tonic, k.kind === 'minor' ? 'natural_minor' : k.kind)[Number(p.num) - 1]) };
    }
    case 'drill.prompts.degreeToChord': {
      const k = parseKey(p.key);
      const dia = diatonicTriads(scale(k.tonic, k.kind === 'major' ? 'major' : 'natural_minor'));
      const d = dia.find((x) => x.numeral === p.numeral);
      if (!d) return { answer: `NUMERAL-NOT-DIATONIC(${p.numeral})` };
      return { answer: `${fmtU(d.root)} ${d.quality}` };
    }
    case 'drill.prompts.chordToDegree': {
      const k = parseKey(p.key);
      const dia = diatonicTriads(scale(k.tonic, k.kind === 'major' ? 'major' : 'natural_minor'));
      const [r, q] = String(p.chord).split(' ');
      const d = dia.find((x) => fmtU(x.root) === r && x.quality === q);
      return { answer: d ? d.numeral : `CHORD-NOT-DIATONIC(${p.chord})` };
    }
    case 'drill.prompts.pattern': {
      const dia = diatonicTriads(scale(parse('C'), p.mode === 'major' ? 'major' : 'natural_minor'));
      const d = dia[Number(p.num) - 1];
      return { answer: `${d.quality} (${d.numeral})` };
    }
    case 'drill.prompts.harmonicFact': {
      const d = diatonicTriads(scale(parse('A'), 'harmonic_minor'))[Number(p.num) - 1];
      return { answer: `${d.quality} (${d.numeral})` };
    }
    case 'drill.prompts.isDiatonic': {
      const k = parseKey(p.key);
      const dia = diatonicTriads(scale(k.tonic, 'major'));
      const [r, q] = String(p.chord).split(' ');
      return { answer: dia.some((x) => fmtU(x.root) === r && x.quality === q) ? 'Yes' : 'No' };
    }
    case 'drill.prompts.chordFunction': {
      const k = parseKey(p.key);
      const dia = diatonicTriads(scale(k.tonic, 'major'));
      const m = String(p.chord).match(/^(\S+) (\S+) \((.+)\)$/)!;
      const d = dia.find((x) => x.numeral === m[3]);
      if (!d || fmtU(d.root) !== m[1] || d.quality !== m[2]) return { answer: `PROMPT-CHORD-MISMATCH(${p.chord})` };
      const f = FUNCTION_OF[m[3]];
      return { answer: f === 'T' ? 'Tonic' : f === 'PD' ? 'Subdominant (pre-dominant)' : 'Dominant' };
    }
    case 'drill.prompts.cadence': {
      const [a, b] = String(p.pair).split(' → ');
      // Definitions: cadence on V = half; V→I authentic; IV→I plagal; V→vi deceptive.
      if (b === 'V') return { answer: 'Half cadence' };
      if (a === 'V' && b === 'I') return { answer: 'Perfect authentic cadence', isCorrect: (c) => c === 'Perfect authentic cadence' || c === 'Imperfect authentic cadence' || c === 'Authentic cadence' };
      if (a === 'IV' && b === 'I') return { answer: 'Plagal cadence' };
      if (a === 'V' && b === 'vi') return { answer: 'Deceptive cadence' };
      return { answer: '?' };
    }
    case 'drill.prompts.v7Of': return { answer: `${fmtU(scale(parse(p.key), 'major')[4])}7` };
  }
  return { answer: `UNHANDLED ${it.promptKey}` };
}

let checked = 0;
for (const it of bank) {
  checked++;
  // --- structural checks common to all formats
  if (it.input.format === 'choice') {
    const ch = it.input.choices;
    if (new Set(ch).size !== ch.length) P(it, 'duplicate-choice', JSON.stringify(ch));
    if (!ch.includes(correctChoice(it)!)) P(it, 'answer-not-in-choices', `${correctChoice(it)} ∉ ${JSON.stringify(ch)}`);
    if (ch.length < 4 && !['drill.prompts.isDiatonic', 'drill.prompts.chordFunction'].includes(it.promptKey)) P(it, 'fewer-than-4-choices', JSON.stringify(ch));
  }
  if (it.input.format === 'noteChips') {
    const chips = it.input.chips;
    if (new Set(chips).size !== chips.length) P(it, 'duplicate-chip', JSON.stringify(chips));
    if (it.answer.kind === 'notes') {
      for (const n of it.answer.notes) if (!chips.some((c) => fmtA(parse(c)) === n)) P(it, 'correct-note-missing-from-chips', `${n} ∉ ${chips}`);
      if (it.input.expectedCount !== it.answer.notes.length) P(it, 'expectedCount-mismatch', `${it.input.expectedCount} vs ${it.answer.notes.length}`);
    }
  }
  if (it.input.format === 'accidentalSlots' && it.answer.kind === 'accidentals') {
    const letters = it.input.letters;
    const sp = it.answer.spelled.map(parse);
    if (sp.some((n, i) => n.L !== letters[i])) P(it, 'slot-letters-mismatch', `${letters} vs ${it.answer.spelled}`);
    if (sp.some((n) => Math.abs(n.a) > 1)) P(it, 'answer-unreachable-in-slots(needs double accidental)', it.answer.spelled.join(' '));
  }

  // --- semantic check
  if (it.promptKey === 'drill.prompts.nameChord') {
    if (it.input.format !== 'rootQuality' || it.answer.kind !== 'rootQuality') { P(it, 'format', 'unexpected'); continue; }
    const shown = String(it.promptParams.notes).split(' – ').map(parse);
    const key = (ns: ONote[]) => ns.map(fmtA).sort().join(',');
    const matches: string[] = [];
    for (const r of it.input.roots) for (const q of it.input.qualities) {
      if (key(chord(parse(r), q)) === key(shown)) matches.push(`${fmtA(parse(r))} ${q}`);
    }
    const ans = `${it.answer.root} ${it.answer.quality}`;
    if (matches.length !== 1 || matches[0] !== ans) P(it, 'nameChord-wrong-or-ambiguous', `oracle matches ${JSON.stringify(matches)} app ${ans}`);
    continue;
  }
  const exp = expected(it);
  if (!exp) continue;
  let got: string | string[];
  if (it.answer.kind === 'choice') got = it.answer.correct;
  else if (it.answer.kind === 'notes') got = it.answer.notes;
  else if (it.answer.kind === 'accidentals') got = it.answer.spelled;
  else got = `${it.answer.root} ${it.answer.quality}`;
  const same = Array.isArray(exp.answer)
    ? Array.isArray(got) && (it.answer.kind === 'notes' ? [...got].sort().join() === [...exp.answer].sort().join() : got.join() === exp.answer.join())
    : got === exp.answer;
  if (!same) P(it, 'WRONG-ANSWER', `prompt=${JSON.stringify(it.promptParams)} app=${JSON.stringify(got)} oracle=${JSON.stringify(exp.answer)}`);
  // distractor-also-correct
  if (it.input.format === 'choice') {
    const pred = exp.isCorrect ?? ((c: string) => c === exp.answer);
    const correctOnes = it.input.choices.filter(pred);
    if (correctOnes.length > 1) P(it, 'MULTIPLE-CORRECT-CHOICES', `${JSON.stringify(correctOnes)} prompt=${JSON.stringify(it.promptParams)}`);
    // well-formed interval labels
    if (['drill.prompts.pairToName', 'drill.prompts.semitonesToName'].includes(it.promptKey))
      for (const c of it.input.choices) if (labelSemis(c) === null) P(it, 'nonexistent-interval-label', c);
  }
}

// --- id uniqueness and duplicate prompts
const ids = new Map<string, number>();
for (const it of bank) ids.set(it.id, (ids.get(it.id) ?? 0) + 1);
for (const [id, n] of ids) if (n > 1) problems.push({ id, check: 'duplicate-id', detail: `${n}x` });
const promptGroups = new Map<string, DrillItem[]>();
for (const it of bank) {
  const k = `${it.promptKey}|${JSON.stringify(it.promptParams)}`;
  promptGroups.set(k, [...(promptGroups.get(k) ?? []), it]);
}
for (const [k, its] of promptGroups) if (its.length > 1) problems.push({ id: its.map((i) => i.id).join(' & '), check: 'duplicate-prompt', detail: k });

// --- report
const byCheck: Record<string, number> = {};
for (const p of problems) byCheck[p.check] = (byCheck[p.check] ?? 0) + 1;
console.log(`items checked: ${checked} (plant=${PLANT})`);
console.log('problems by check:', JSON.stringify(byCheck, null, 1));
for (const p of problems) console.log(`- [${p.check}] ${p.id} :: ${p.detail}`);
process.exit(0);
