// Hydrate the real drill store from a persisted blob in which ONE of 3 item records is malformed.
const mem = new Map<string, string>();
const good = (id: string) => ({ card: { due: 1, stability: 1, difficulty: 5, elapsed_days: 0, scheduled_days: 1, reps: 3, lapses: 0, state: 2, learning_steps: 0 }, history: [{ ts: 1, correct: true, ms: 1500, sessionId: 's1' }], tier: 'review', introCorrectCount: 2 });
const variant = process.argv[2] ?? 'bad';
const items: any = { 'degree:num-to-name:1': good('a'), 'degree:num-to-name:2': good('b'), 'degree:num-to-name:3': good('c') };
if (variant === 'bad') delete items['degree:num-to-name:3'].history; // e.g. a field lost in a future refactor / partial write
mem.set('fermata-drill-v1', JSON.stringify({ state: { items, settings: { length: 24, newPerSession: 4, families: {}, sound: true, showTimer: false }, sprintBests: { 'degree': 9 }, lifetime: { answered: 120, correct: 100 }, activeSession: null }, version: 1 }));
(globalThis as any).localStorage = { getItem: (k: string) => mem.get(k) ?? null, setItem: (k: string, v: string) => mem.set(k, v), removeItem: (k: string) => mem.delete(k) };
const { useDrillStore } = await import('/Users/nunosantos/Documents/Base/Music/new_music_app/src/state/drillStore.ts');
await new Promise((r) => setTimeout(r, 20));
const s = useDrillStore.getState();
console.log(`variant=${variant}: items after hydrate = ${Object.keys(s.items).length}, lifetime.answered = ${s.lifetime.answered}, sprintBests = ${JSON.stringify(s.sprintBests)}`);
