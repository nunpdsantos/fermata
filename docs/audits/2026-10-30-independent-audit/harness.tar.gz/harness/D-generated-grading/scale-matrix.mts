// scale names -> parseScaleSymbol -> buildScale, vs oracle formulas (pitch classes + letter-correctness for 7-note scales)
import { parse, fmtA, pc, up, LETTERS } from './oracle.ts';
const { parseScaleSymbol } = await import('/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/utils/scaleParser.ts');
const { buildScale } = await import('/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/constants/scales.ts');
const PLANT = process.argv.includes('--plant');
const NAMES: [string, number[]][] = [
  ['major', [0, 2, 4, 5, 7, 9, 11]], ['ionian', [0, 2, 4, 5, 7, 9, 11]], ['minor', [0, 2, 3, 5, 7, 8, 10]], ['natural minor', [0, 2, 3, 5, 7, 8, 10]],
  ['aeolian', [0, 2, 3, 5, 7, 8, 10]], ['harmonic minor', [0, 2, 3, 5, 7, 8, 11]], ['melodic minor', [0, 2, 3, 5, 7, 9, 11]],
  ['dorian', [0, 2, 3, 5, 7, 9, 10]], ['phrygian', [0, 1, 3, 5, 7, 8, 10]], ['lydian', [0, 2, 4, 6, 7, 9, 11]], ['mixolydian', [0, 2, 4, 5, 7, 9, 10]],
  ['locrian', [0, 1, 3, 5, 6, 8, 10]], ['major pentatonic', [0, 2, 4, 7, 9]], ['minor pentatonic', [0, 3, 5, 7, 10]], ['blues', [0, 3, 5, 6, 7, 10]],
  ['whole tone', [0, 2, 4, 6, 8, 10]], ['altered', [0, 1, 3, 4, 6, 8, 10]], ['lydian dominant', [0, 2, 4, 6, 7, 9, 10]], ['phrygian dominant', [0, 1, 4, 5, 7, 8, 10]],
];
if (PLANT) NAMES.push(['dorian', [0, 2, 4, 5, 7, 9, 10]]);
let n = 0; const fails: string[] = [];
for (const L of LETTERS) for (const [aIn, aA] of [['', ''], ['#', '#'], ['b', 'b'], ['♯', '#'], ['♭', 'b']]) for (const [name, semis] of NAMES) {
  n++;
  const input = `${L}${aIn} ${name}`;
  const p = parseScaleSymbol(input);
  if (!p) { fails.push(`${input}: null`); continue; }
  const root = parse(L + aA);
  if (fmtA(parse(p.root.natural + p.root.accidental)) !== fmtA(root)) { fails.push(`${input}: root ${p.root.natural}${p.root.accidental}`); continue; }
  const st = ({ ionian: 'major', aeolian: 'natural_minor' } as any)[p.scaleType] ?? p.scaleType; /* consumers' MODE_TO_SCALE (quickSearchResults.ts:31, queryExecutor.ts:23) */ const notes = buildScale(p.root, st).notes;
  const got = notes.map((x: any) => pc(parse(x.natural + x.accidental)));
  const exp = semis.map((s) => (pc(root) + s) % 12);
  if (got.join() !== exp.join()) { fails.push(`${input}: pcs ${got} vs ${exp} (${p.scaleType})`); continue; }
  if (semis.length === 7) {
    const want = semis.map((s, i) => fmtA(up(root, i, s)));
    const have = notes.map((x: any) => x.natural + x.accidental);
    if (want.some((w) => /\(/.test(w))) continue; // triple accidental: pitch check only
    if (want.join(' ') !== have.join(' ')) fails.push(`${input}: spelled ${have.join(' ')} vs ${want.join(' ')}`);
  }
}
console.log(`inputs ${n} plant=${PLANT} failures ${fails.length}`); fails.slice(0, 20).forEach((f) => console.log(' - ' + f));
