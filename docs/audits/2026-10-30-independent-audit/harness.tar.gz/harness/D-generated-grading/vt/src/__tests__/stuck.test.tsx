// Renders the real DrillView with the queue state the store produced in store-sim.out (index 7, before the miss).
import { describe, it, expect, afterEach } from 'vitest';
import * as React from '/Users/nunosantos/Documents/Base/Music/new_music_app/node_modules/react/index.js';
import { render, screen, fireEvent, act, cleanup } from '/Users/nunosantos/Documents/Base/Music/new_music_app/node_modules/@testing-library/react/dist/index.js';
import { DrillView } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/views/DrillView.tsx';
import { useDrillStore } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/state/drillStore.ts';
import { LazyMotion, domAnimation } from '/Users/nunosantos/Documents/Base/Music/new_music_app/node_modules/framer-motion/dist/es/index.mjs';

const Q = ['triad:name-to-notes:C:major','triad:notes-to-name:C:major','triad:name-to-notes:C:minor','triad:notes-to-name:C:minor','triad:name-to-notes:C:major','triad:notes-to-name:C:major','triad:name-to-notes:C:minor','triad:notes-to-name:C:minor'];

describe('adjacent duplicate after end-of-queue miss', () => {
  afterEach(() => cleanup());
  it('second showing of the same rootQuality item accepts an answer', async () => {
    useDrillStore.setState({
      settings: { ...useDrillStore.getState().settings, sound: false },
      activeSession: { id: 's1', queue: Q, index: 7, asked: 7, correct: 7, startedAt: 1, seed: 1, missRequeues: {} },
    });
    render(React.createElement(LazyMotion as any, { features: domAnimation }, React.createElement(DrillView)));
    // prompt for C minor triad notes → pick root C, then a WRONG quality (Major)
    fireEvent.click(screen.getByRole('button', { name: 'C' }));
    fireEvent.click(screen.getByRole('button', { name: 'Major' }));
    const s1 = useDrillStore.getState().activeSession!;
    console.log('after miss: asked', s1.asked, 'index', s1.index, 'next id', s1.queue[s1.index], 'queue tail', s1.queue.slice(-2));
    // feedback → Continue
    fireEvent.click(screen.getByRole('button', { name: 'Continue' }));
    // same item shown again; try to answer correctly: root C then Minor
    fireEvent.click(screen.getByRole('button', { name: 'C' }));
    const minor = screen.getByRole('button', { name: 'Minor' });
    fireEvent.click(minor);
    await act(async () => { await new Promise((r) => setTimeout(r, 50)); });
    const s2 = useDrillStore.getState().activeSession!;
    console.log('after retry taps: asked', s2.asked, '(was', s1.asked + ')');
    expect(s2.asked).toBe(s1.asked + 1); // FAILS if the input stayed locked
  });

  it('CONTROL: same click sequence on a different next item registers', async () => {
    useDrillStore.setState({
      settings: { ...useDrillStore.getState().settings, sound: false },
      activeSession: { id: 's2', queue: [...Q, 'triad:notes-to-name:C:major'], index: 7, asked: 7, correct: 7, startedAt: 1, seed: 1, missRequeues: {} },
    });
    render(React.createElement(LazyMotion as any, { features: domAnimation }, React.createElement(DrillView)));
    fireEvent.click(screen.getAllByRole('button', { name: 'C' })[0]);
    fireEvent.click(screen.getAllByRole('button', { name: 'Major' })[0]);
    const s1 = useDrillStore.getState().activeSession!;
    console.log('CONTROL after miss: next id', s1.queue[s1.index]);
    fireEvent.click(screen.getAllByRole('button', { name: 'Continue' })[0]);
    fireEvent.click(screen.getAllByRole('button', { name: 'C' })[0]);
    fireEvent.click(screen.getAllByRole('button', { name: 'Major' })[0]);
    await act(async () => { await new Promise((r) => setTimeout(r, 50)); });
    const s2 = useDrillStore.getState().activeSession!;
    console.log('CONTROL after retry taps: asked', s2.asked, '(was', s1.asked + ')');
    expect(s2.asked).toBe(s1.asked + 1);
  });
});
