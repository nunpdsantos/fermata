// Feedback display checks on the real DrillView.
import { describe, it, expect, afterEach } from 'vitest';
import * as React from '/Users/nunosantos/Documents/Base/Music/new_music_app/node_modules/react/index.js';
import { render, screen, fireEvent, cleanup } from '/Users/nunosantos/Documents/Base/Music/new_music_app/node_modules/@testing-library/react/dist/index.js';
import { DrillView } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/views/DrillView.tsx';
import { useDrillStore } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/state/drillStore.ts';
import { LazyMotion, domAnimation } from '/Users/nunosantos/Documents/Base/Music/new_music_app/node_modules/framer-motion/dist/es/index.mjs';
const mount = (queue: string[]) => {
  useDrillStore.setState({ settings: { ...useDrillStore.getState().settings, sound: false }, activeSession: { id: 'sX', queue, index: 0, asked: 0, correct: 0, startedAt: 1, seed: 1, missRequeues: {} } });
  return render(React.createElement(LazyMotion as any, { features: domAnimation }, React.createElement(DrillView)));
};
describe('drill feedback display', () => {
  afterEach(() => cleanup());
  it('rootQuality wrong answer: what does the strip print as the correct answer?', () => {
    const { container } = mount(['seventh:notes-to-name:C#:half_diminished7', 'degree:num-to-name:1']);
    fireEvent.click(screen.getByRole('button', { name: 'G' }));
    fireEvent.click(screen.getByRole('button', { name: 'Major 7th' }));
    const title = container.querySelector('[aria-live="polite"] p')!.textContent!;
    expect(title).toBe('Not quite — C♯ Half-Diminished 7th'); // what a learner should read
  });
  it('noteChips wrong answer: answer text glyphs', () => {
    const { container } = mount(['triad:name-to-notes:C#:augmented', 'degree:num-to-name:1']);
    for (const n of ['C♯', 'E♯', 'A']) fireEvent.click(screen.getByRole('button', { name: n }));
    const title = container.querySelector('[aria-live="polite"] p')!.textContent!;
    expect(title).toBe('Same sound, wrong spelling — the correct spelling here is C♯ E♯ G𝄪');
  });
  it('choice wrong answer: is the tapped wrong chip marked?', () => {
    mount(['interval:note-above:D:M3', 'degree:num-to-name:1']);
    const wrong = screen.getByRole('button', { name: 'G♭' });
    fireEvent.click(wrong);
    const cls = screen.getByRole('button', { name: 'G♭' }).className;
    console.log('TAPPED WRONG CHIP CLASS:', cls);
    expect(cls).toMatch(/red/);
  });
  it('CONTROL: correct chip is marked green after a wrong tap', () => {
    mount(['interval:note-above:D:M3', 'degree:num-to-name:1']);
    fireEvent.click(screen.getByRole('button', { name: 'G♭' }));
    expect(screen.getByRole('button', { name: 'F♯' }).className).toMatch(/emerald/);
  });
});
