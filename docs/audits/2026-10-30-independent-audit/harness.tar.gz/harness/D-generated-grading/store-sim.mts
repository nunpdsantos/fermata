// Drive the real drillStore (in-memory localStorage shim) to find (a) an adjacent duplicate
// in the live queue while the session is still running, and (b) the stale-id skip repeat.
const mem = new Map<string, string>();
(globalThis as any).localStorage = { getItem: (k: string) => mem.get(k) ?? null, setItem: (k: string, v: string) => mem.set(k, v), removeItem: (k: string) => mem.delete(k) };
const { useDrillStore, isSessionComplete } = await import('/Users/nunosantos/Documents/Base/Music/new_music_app/src/state/drillStore.ts');
const { generateDrillBank } = await import('/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/utils/drillBank/index.ts');
const bank = generateDrillBank();
const byId = new Map(bank.map((i: any) => [i.id, i]));
const S = () => useDrillStore.getState();

// ---- (a) New learner, only "Triads" enabled (Settings > Topics), defaults otherwise.
const fam: any = Object.fromEntries(['keysig','circle','scale','degree','interval','triad','seventh','roman','function'].map((f) => [f, f === 'triad']));
S().updateSettings({ families: fam });
let now = Date.UTC(2026, 9, 30, 9, 0, 0);
S().startSession(bank, now);
console.log('initial queue:', JSON.stringify(S().activeSession!.queue));
let step = 0;
while (true) {
  const s = S().activeSession!;
  if (isSessionComplete(s, S().settings)) { console.log('session complete at asked', s.asked); break; }
  const id = s.queue[s.index];
  const prevId = s.index > 0 ? s.queue[s.index - 1] : null;
  if (id === prevId) {
    console.log(`ADJACENT DUPLICATE: index ${s.index} shows ${id} again immediately (asked=${s.asked}, length=${S().settings.length}, complete=${isSessionComplete(s, S().settings)}); input format=${(byId.get(id) as any).input.format}`);
    console.log('queue now:', JSON.stringify(s.queue));
    break;
  }
  const item = byId.get(id)!;
  // policy: answer correctly, except miss the item that sits at the very end of the queue
  const correct = s.index !== s.queue.length - 1;
  now += 5000;
  S().recordAnswer(item as any, correct, 2000, now);
  step++;
  if (step > 60) break;
}

// ---- (b) Stale id at the head of a resumed queue (bank changed between releases)
S().resetDrillProgress();
const A = bank[0].id, B = bank[1].id;
useDrillStore.setState({ activeSession: { id: 's1', queue: ['degree:removed-in-new-release', A, B], index: 0, asked: 0, correct: 0, startedAt: 1, seed: 1, missRequeues: {} } });
// replicate the runner's currentKnownId (useDrillRunner.ts:85-94): first known id at or after index
const currentKnownId = (s: any) => { for (let i = s.index; i < s.queue.length; i++) if (byId.has(s.queue[i])) return s.queue[i]; return null; };
const shown1 = currentKnownId(S().activeSession);
S().recordAnswer(byId.get(shown1)! as any, true, 1500, 10_000);
const shown2 = currentKnownId(S().activeSession);
console.log(`stale-head resume: first shown ${shown1}; after answering it, next shown ${shown2} (index=${S().activeSession!.index}, asked=${S().activeSession!.asked})`);
