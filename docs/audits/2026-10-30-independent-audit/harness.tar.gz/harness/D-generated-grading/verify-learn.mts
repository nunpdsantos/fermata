/**
 * Learn exercises (authored 385 + generated 485, EN/PT/ES): verify generated answers and graders
 * against the independent oracle, structural integrity of choices, option-position uniformity,
 * ear-training playback math, and build-exercise note counts.
 * Usage: npx tsx verify-learn.mts [--plant]
 */
import { parse, pc, up, scale as oScale, chord as oChord, type ONote } from './oracle.ts';
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src/';
const { generateAllForLevel } = await import(R + 'data/exercises/exerciseGenerator.ts');
const { applyTemplateOverlay, applyExerciseOverlay } = await import(R + 'i18n/content/contentResolver.ts');
const { validateAnswer } = await import(R + 'components/learn/exercises/validateExercise.ts');
const H = await import(R + 'components/learn/exercises/exerciseHelpers.ts');
const PLANT = process.argv.includes('--plant');

const SCALE_SEMIS: Record<string, number[]> = {
  major: [0, 2, 4, 5, 7, 9, 11], natural_minor: [0, 2, 3, 5, 7, 8, 10], harmonic_minor: [0, 2, 3, 5, 7, 8, 11],
  melodic_minor: [0, 2, 3, 5, 7, 9, 11], dorian: [0, 2, 3, 5, 7, 9, 10], phrygian: [0, 1, 3, 5, 7, 8, 10],
  lydian: [0, 2, 4, 6, 7, 9, 11], mixolydian: [0, 2, 4, 5, 7, 9, 10], locrian: [0, 1, 3, 5, 6, 8, 10],
  whole_tone: [0, 2, 4, 6, 8, 10], blues: [0, 3, 5, 6, 7, 10], pentatonic_minor: [0, 3, 5, 7, 10],
  pentatonic_major: [0, 2, 4, 7, 9], chromatic: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11],
  altered: [0, 1, 3, 4, 6, 8, 10], diminished_half_whole: [0, 1, 3, 4, 6, 7, 9, 10],
};
const DIATONIC_7 = new Set(['major', 'natural_minor', 'harmonic_minor', 'melodic_minor', 'dorian', 'phrygian', 'lydian', 'mixolydian', 'locrian', 'altered']);
const MODE_FROM_MAJOR: Record<string, number> = { dorian: 1, phrygian: 2, lydian: 3, mixolydian: 4, locrian: 6 };

type P = { lang: string; id: string; check: string; detail: string };
const problems: P[] = [];
const posHist: Record<string, number[]> = {};
let counted = 0;

function rootOf(c: any, rk = 'root', ak = 'rootAccidental'): ONote { return parse(String(c[rk]) + String(c[ak] ?? '')); }

function check(lang: string, src: string, e: any) {
  counted++;
  const c = e.config;
  const P = (check: string, detail: string) => problems.push({ lang, id: `${src}:${e.id}`, check, detail });
  switch (c.type) {
    case 'scale_build': {
      const semis = SCALE_SEMIS[c.scaleType];
      if (!semis) { P('unknown-scale', c.scaleType); break; }
      const root = rootOf(c);
      const pcs = new Set(semis.map((s) => (pc(root) + s) % 12));
      // spelled oracle (7-note diatonic types) to cross-check pcs
      if (DIATONIC_7.has(c.scaleType) && ['major', 'natural_minor', 'harmonic_minor', 'melodic_minor'].includes(c.scaleType)) {
        const sp = oScale(root, c.scaleType); const s2 = new Set(sp.map(pc));
        if ([...s2].some((x) => !pcs.has(x))) P('oracle-internal', 'spelled vs pcs');
        if (sp.some((n) => Math.abs(n.a) > 2)) P('scale-needs-triple-accidental', `${c.root}${c.rootAccidental} ${c.scaleType}`);
      }
      const ok = validateAnswer(c, pcs);
      if (!ok.correct) P('GRADER-REJECTS-ORACLE-ANSWER', `${c.root}${c.rootAccidental} ${c.scaleType} oracle pcs ${[...pcs]}`);
      // wrong answer must be rejected
      const wrong = new Set(pcs); wrong.delete([...pcs][1]); wrong.add(([...pcs][1] + 1) % 12);
      if (validateAnswer(c, wrong).correct && !pcs.has(([...pcs][1] + 1) % 12)) P('GRADER-ACCEPTS-WRONG', JSON.stringify([...wrong]));
      if (c.noteCount !== pcs.size) P('noteCount-mismatch', `${c.root}${c.rootAccidental} ${c.scaleType}: counter says ${c.noteCount}, scale has ${pcs.size} pitch classes`);
      break;
    }
    case 'chord_build': {
      const root = rootOf(c);
      let notes: ONote[];
      try { notes = oChord(root, c.quality); } catch { P('unknown-quality', c.quality); break; }
      const pcs = new Set(notes.map(pc));
      if (!validateAnswer(c, pcs).correct) P('GRADER-REJECTS-ORACLE-ANSWER', `${c.root}${c.rootAccidental} ${c.quality}`);
      if (c.noteCount !== pcs.size) P('noteCount-mismatch', `${c.root}${c.rootAccidental} ${c.quality}: counter says ${c.noteCount}, chord has ${pcs.size} pitch classes`);
      if (notes.some((n) => Math.abs(n.a) > 2)) P('chord-needs-triple-accidental', `${c.root}${c.rootAccidental} ${c.quality}`);
      break;
    }
    case 'scale_degree_id': {
      const root = rootOf(c);
      const semis = SCALE_SEMIS[c.scaleType];
      if (!semis || semis.length !== 7) { P('degree-on-non-heptatonic', c.scaleType); break; }
      const sp = semis.map((s, i) => up(root, i, s));
      const n = parse(String(c.note) + String(c.noteAccidental ?? ''));
      const idx = sp.findIndex((x) => x.L === n.L && x.a === n.a);
      if (idx + 1 !== c.correctDegree) P('WRONG-DEGREE', `${c.root}${c.rootAccidental} ${c.scaleType}: note ${c.note}${c.noteAccidental} oracle degree ${idx + 1} app ${c.correctDegree}`);
      if (!validateAnswer(c, String(c.correctDegree)).correct) P('GRADER-REJECTS', '');
      if (c.correctDegree === 7 && /minor|dorian|phrygian|mixolydian|locrian/.test(c.scaleType) && c.scaleType !== 'harmonic_minor' && c.scaleType !== 'melodic_minor')
        P('degree7-labelled-leading-tone-in-scale-with-subtonic', `${c.scaleType} (degree 7 is a whole step below the tonic = subtonic)`);
      break;
    }
    case 'note_id': {
      const opts = H.generateNoteChoices(c.note, c.accidental);
      const corr = opts.filter((o: any) => o.correct);
      if (corr.length !== 1) P('note-choices-correct-count', String(corr.length));
      if (!validateAnswer(c, corr[0].value).correct) P('GRADER-REJECTS', corr[0].value);
      const flats = opts.filter((o: any) => /b/.test(o.label.slice(1)));
      const sharps = opts.filter((o: any) => /#/.test(o.label.slice(1)));
      if (corr[0].label.slice(1) === 'b' && flats.length === 1) P('TELL-only-flat-option-is-correct', opts.map((o: any) => o.label).join(' '));
      break;
    }
    case 'interval_id': {
      if (!validateAnswer(c, String(c.targetSemitones)).correct) P('GRADER-REJECTS', '');
      const opts = H.generateIntervalChoices(c.targetSemitones);
      if (opts.filter((o: any) => o.correct).length !== 1) P('interval-choices', '');
      if (new Set(opts.map((o: any) => o.label)).size !== opts.length) P('dup-interval-labels', opts.map((o: any) => o.label).join('|'));
      break;
    }
    case 'multiple_choice': {
      const ch = c.choices;
      const k = ch.filter((x: any) => x.correct).length;
      if (k !== 1) P('MC-correct-count', `${k} correct: ${JSON.stringify(ch.filter((x: any) => x.correct).map((x: any) => x.label))}`);
      if (new Set(ch.map((x: any) => x.label)).size !== ch.length) P('MC-duplicate-labels', JSON.stringify(ch.map((x: any) => x.label)));
      if (lang === 'en') {
        const opts = H.generateMultipleChoiceOptions(ch, e.id);
        const pos = opts.findIndex((o: any) => o.correct);
        const key = `${ch.length} options`;
        (posHist[key] ??= new Array(ch.length).fill(0))[pos]++;
        const authoredPos = ch.findIndex((x: any) => x.correct);
        (posHist[`authored-order ${ch.length} options`] ??= new Array(ch.length).fill(0))[authoredPos]++;
      }
      break;
    }
    case 'ear_training': {
      if (c.mode === 'interval') {
        // replicate the runner's played pitches (ExerciseRunner.tsx playEarAudio) vs the intended interval
        const NAT = ['C', 'C', 'D', 'D', 'E', 'F', 'F', 'G', 'G', 'A', 'A', 'B'];
        const rootPCs: Record<string, number> = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };
        let rpc = rootPCs[c.root]; if (c.rootAccidental === '#') rpc += 1; if (c.rootAccidental === 'b') rpc -= 1;
        const semis = c.direction === 'descending' ? -c.targetSemitones : c.targetSemitones;
        const tpc = (((rpc + semis) % 12) + 12) % 12;
        const oct = c.rootOctave ?? 4;
        const toct = oct + (rpc + semis >= 12 ? 1 : rpc + semis < 0 ? -1 : 0);
        const rootMidi = 12 + 12 * oct + pc(rootOf(c));          // core playNote: 12 + 12*oct + pitchClass
        const targMidi = 12 + 12 * toct + tpc;
        if (targMidi - rootMidi !== semis) P('EAR-INTERVAL-PLAYS-WRONG-SIZE', `${c.root}${c.rootAccidental}${oct} ${c.direction} ${c.targetSemitones}: sounds ${targMidi - rootMidi} semitones`);
        const opts = H.generateIntervalChoices(c.targetSemitones);
        if (new Set(opts.map((o: any) => o.label)).size !== opts.length) P('dup-interval-labels', '');
      } else if (c.mode === 'note') {
        const opts = H.generateNoteChoices(c.note, c.accidental ?? '');
        const corr = opts.find((o: any) => o.correct);
        const flats = opts.filter((o: any) => /b/.test(o.label.slice(1)));
        if (corr.label.slice(1) === 'b' && flats.length === 1) P('TELL-only-flat-option-is-correct', opts.map((o: any) => o.label).join(' '));
      } else {
        const ch = c.choices ?? [];
        if (ch.filter((x: any) => x.correct).length !== 1) P('EAR-correct-count', JSON.stringify(ch));
        if (new Set(ch.map((x: any) => x.label)).size !== ch.length) P('EAR-duplicate-labels', JSON.stringify(ch.map((x: any) => x.label)));
        if (c.mode === 'progression') {
          const playable = ['I', 'ii', 'iii', 'IV', 'V', 'vi', 'vii'];
          for (const num of c.progression ?? []) if (!playable.includes(String(num).replace('°', ''))) P('EAR-PROGRESSION-CHORD-NOT-PLAYED', `${num} in ${JSON.stringify(c.progression)} (runner only finds major-key diatonic triads)`);
        }
        if (c.mode === 'chord') { try { oChord(parse(c.chordRoot + (c.chordRootAccidental ?? '')), c.quality); } catch { P('unknown-quality', c.quality); } }
      }
      break;
    }
  }
}

const OV = (lang: string, kind: string, L: number) => import(R + `i18n/content/${lang}/${kind}L${L}.ts`).then((m) => m.default).catch(() => null);
for (const lang of ['en', 'pt', 'es']) {
  for (let L = 1; L <= 9; L++) {
    let tmpl = (await import(R + `data/exercises/templatesL${L}.ts`)).default;
    let authored = (await import(R + `data/exercises/exercisesL${L}.ts`)).default;
    if (lang !== 'en') {
      tmpl = applyTemplateOverlay(tmpl, await OV(lang, 'templates', L));
      authored = applyExerciseOverlay(authored, await OV(lang, 'exercises', L));
    }
    const gen = generateAllForLevel(tmpl, lang);
    if (PLANT && lang === 'en' && L === 1) {
      const first = Object.values(gen)[0] as any[];
      first.push({ id: 'PLANT1', config: { type: 'chord_build', root: 'C', rootAccidental: '', quality: 'major7', noteCount: 3 } });
      first.push({ id: 'PLANT2', config: { type: 'multiple_choice', choices: [{ label: 'a', correct: true }, { label: 'a', correct: true }] } });
      first.push({ id: 'PLANT3', config: { type: 'scale_degree_id', root: 'C', rootAccidental: '', scaleType: 'major', note: 'E', noteAccidental: '', correctDegree: 4 } });
      first.push({ id: 'PLANT4', config: { type: 'ear_training', mode: 'progression', root: 'C', progression: ['i', 'iv', 'V'], choices: [{ label: 'x', correct: true }, { label: 'y', correct: false }] } });
      first.push({ id: 'PLANT5', config: { type: 'ear_training', mode: 'interval', root: 'B', rootAccidental: '#', rootOctave: 4, targetSemitones: 4, direction: 'ascending' } });
    }
    for (const [src, map] of [['gen', gen], ['auth', authored]] as const) for (const exs of Object.values(map) as any[]) for (const e of exs) check(lang, src, e);
  }
}
const by: Record<string, number> = {};
for (const p of problems) by[`${p.lang}:${p.check}`] = (by[`${p.lang}:${p.check}`] ?? 0) + 1;
console.log(`exercise instances checked: ${counted} (3 languages) plant=${PLANT}`);
console.log('problems:', JSON.stringify(by, null, 1));
console.log('correct-option position histogram (EN multiple_choice, after the runner\'s seeded shuffle vs as authored):', JSON.stringify(posHist));
const seen = new Set<string>();
for (const p of problems) { const k = p.check + p.detail; if (seen.has(k) && !p.check.startsWith('MC')) continue; seen.add(k); console.log(`- [${p.lang}] [${p.check}] ${p.id} :: ${p.detail}`); }
