import { generateDrillBank } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/utils/drillBank/index.ts';
import { writeFileSync } from 'fs';
const bank = generateDrillBank();
const fam: Record<string, number> = {};
const pk: Record<string, number> = {};
for (const i of bank) { fam[i.family] = (fam[i.family] ?? 0) + 1; pk[i.promptKey] = (pk[i.promptKey] ?? 0) + 1; }
console.log('total', bank.length);
console.log(JSON.stringify(fam));
console.log(JSON.stringify(pk, null, 0));
writeFileSync(process.argv[2] ?? 'bank.json', JSON.stringify(bank, null, 1));
