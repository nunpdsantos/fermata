/**
 * Chord-symbol parser matrix: every root spelling (7 letters x {'',#,b,##,bb} in ASCII and unicode,
 * plus lowercase roots) x common notations of each supported quality, plus slash chords.
 * parse -> chordFromParsed -> spelled notes, compared with the independent oracle.
 * Usage: npx tsx parser-matrix.mts [--plant]
 */
import { parse, fmtA, pc, chord as oChord, LETTERS } from './oracle.ts';
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/utils/';
const { parseChordSymbol, chordFromParsed, formatParsedChordName } = await import(R + 'chordParser.ts');
const PLANT = process.argv.includes('--plant');

// notation -> oracle quality (independent expectation)
const NOTATIONS: [string, string][] = [
  ['', 'major'], ['maj', 'major'], ['M', 'major'], ['major', 'major'],
  ['m', 'minor'], ['min', 'minor'], ['-', 'minor'], ['mi', 'minor'], ['minor', 'minor'],
  ['dim', 'diminished'], ['°', 'diminished'], ['o', 'diminished'], ['º', 'diminished'],
  ['aug', 'augmented'], ['+', 'augmented'],
  ['7', 'dominant7'], ['dom7', 'dominant7'],
  ['maj7', 'major7'], ['M7', 'major7'], ['Δ7', 'major7'], ['Δ', 'major7'], ['ma7', 'major7'], ['j7', 'major7'], ['major7', 'major7'],
  ['m7', 'minor7'], ['min7', 'minor7'], ['-7', 'minor7'], ['mi7', 'minor7'],
  ['m7b5', 'half_diminished7'], ['ø', 'half_diminished7'], ['ø7', 'half_diminished7'], ['m7♭5', 'half_diminished7'], ['-7b5', 'half_diminished7'], ['min7b5', 'half_diminished7'],
  ['dim7', 'diminished7'], ['°7', 'diminished7'], ['o7', 'diminished7'],
  ['mMaj7', 'minor_major7'], ['m(maj7)', 'minor_major7'], ['mM7', 'minor_major7'], ['-Δ7', 'minor_major7'], ['mmaj7', 'minor_major7'],
  ['6', 'major6'], ['m6', 'minor6'],
  ['sus2', 'sus2'], ['sus4', 'sus4'], ['sus', 'sus4'], ['7sus4', 'dominant7sus4'],
  ['add9', 'add9'], ['add2', 'add9'],
  ['9', 'dominant9'], ['m9', 'minor9'], ['maj9', 'major9'],
  ['7b9', 'dominant7flat9'], ['7#9', 'dominant7sharp9'], ['7b5', 'dominant7flat5'], ['7#5', 'dominant7sharp5'], ['aug7', 'augmented7'], ['+7', 'augmented7'],
  ['6/9', 'six_nine'], ['5', 'power'],
  // classical (Kostka/Payne-style) seventh-chord quality labels: MM7 = major 7th, Mm7 = dominant 7th, mm7 = minor 7th
  ['MM7', 'major7'], ['Mm7', 'dominant7'], ['mm7', 'minor7'],
];
if (PLANT) NOTATIONS.push(['m', 'major'] as [string, string]); // deliberately wrong expectation: must be reported

const ROOT_ACC: [string, string][] = [['', ''], ['#', '#'], ['b', 'b'], ['##', '##'], ['bb', 'bb'], ['♯', '#'], ['♭', 'b'], ['𝄪', '##'], ['𝄫', 'bb']];
const fails: string[] = []; const failByNot: Record<string, number> = {}; let total = 0, tripleSkipped = 0;
for (const L of LETTERS) for (const [accIn, accA] of ROOT_ACC) for (const lower of [false, true]) {
  if (lower && accIn !== '' && accIn !== '#') continue; // lowercase root sampled on '' and '#'
  for (const [nt, q] of NOTATIONS) {
    const input = `${lower ? L.toLowerCase() : L}${accIn}${nt}`;
    total++;
    const root = parse(L + accA);
    const exp = oChord(root, q);
    const p = parseChordSymbol(input);
    const key = nt === '' ? '(empty)' : nt;
    if (!p) { fails.push(`${input}: parse returned null (expected ${L}${accA} ${q})`); failByNot[key] = (failByNot[key] ?? 0) + 1; continue; }
    const got = chordFromParsed(p).notes;
    const pcsOk = [...new Set(got.map((n: any) => pc(parse(n.natural + n.accidental))))].sort().join() === [...new Set(exp.map(pc))].sort().join();
    const rootOk = fmtA(parse(p.root.natural + p.root.accidental)) === fmtA(root);
    if (exp.some((n) => Math.abs(n.a) > 2)) { tripleSkipped++; if (!pcsOk || !rootOk) { fails.push(`${input}: (triple-acc case) pcs/root wrong: ${p.root.natural}${p.root.accidental} ${p.quality}`); failByNot[key] = (failByNot[key] ?? 0) + 1; } continue; }
    const spelledOk = got.map((n: any) => n.natural + n.accidental).join(' ') === exp.map(fmtA).join(' ');
    if (!rootOk || !pcsOk || !spelledOk || p.quality !== q) {
      failByNot[key] = (failByNot[key] ?? 0) + 1;
      fails.push(`${input}: app ${p.root.natural}${p.root.accidental} ${p.quality} [${got.map((n: any) => n.natural + n.accidental).join(' ')}] "${formatParsedChordName(p)}" vs oracle ${fmtA(root)} ${q} [${exp.map(fmtA).join(' ')}]${pcsOk ? ' (same pitch classes)' : ' (DIFFERENT pitch classes)'}`);
    }
  }
}
// slash chords
const SLASH: [string, string, string, string][] = [
  ['C/E', 'C', 'major', 'E'], ['C/G', 'C', 'major', 'G'], ['C/Bb', 'C', 'major', 'Bb'], ['C/B♭', 'C', 'major', 'Bb'], ['D/F#', 'D', 'major', 'F#'], ['D/F♯', 'D', 'major', 'F#'],
  ['Am7/G', 'A', 'minor7', 'G'], ['F#m/C#', 'F#', 'minor', 'C#'], ['Bb/D', 'Bb', 'major', 'D'], ['Gb/Bb', 'Gb', 'major', 'Bb'], ['Cmaj7/B', 'C', 'major7', 'B'],
  ['G7/F', 'G', 'dominant7', 'F'], ['Ebm/Gb', 'Eb', 'minor', 'Gb'], ['C/Fb', 'C', 'major', 'Fb'], ['Cdim7/A', 'C', 'diminished7', 'A'], ['C6/9', 'C', 'six_nine', ''],
];
for (const [input, r, q, bass] of SLASH) {
  total++;
  const p = parseChordSymbol(input);
  if (!p) { fails.push(`${input}: null`); failByNot['slash'] = (failByNot['slash'] ?? 0) + 1; continue; }
  const gotBass = p.bassNote ? fmtA(parse(p.bassNote.natural + p.bassNote.accidental)) : '';
  const ok = fmtA(parse(p.root.natural + p.root.accidental)) === r && p.quality === q && gotBass === bass;
  if (!ok) { fails.push(`${input}: app root ${p.root.natural}${p.root.accidental} ${p.quality} bass ${gotBass || '-'} vs expected ${r} ${q} bass ${bass || '-'}`); failByNot['slash'] = (failByNot['slash'] ?? 0) + 1; }
}
console.log(`inputs: ${total} (plant=${PLANT}); triple-accidental cases compared by pitch class only: ${tripleSkipped}`);
console.log('failures by notation:', JSON.stringify(failByNot));
const shown: Record<string, number> = {};
for (const f of fails) { const k = f.split(':')[0].replace(/^[A-Ga-g][#b♯♭𝄪𝄫]*/, ''); shown[k] = (shown[k] ?? 0) + 1; if (shown[k] <= 3) console.log('- ' + f); }
