# All 9 levels: template block header comment vs curriculum module title (side by side, for eyeballing
# the "template written for a different module plan" root cause). Usage: python3 -I <this>
import re
REPO='/Users/nunosantos/Documents/Base/Music/new_music_app'
for L in range(1,10):
    tpl=open(f'{REPO}/src/data/exercises/templatesL{L}.ts').read()
    cur=open(f'{REPO}/src/core/constants/curriculumL{L}.ts').read()
    heads=dict(re.findall(r"// -+ (l\d+u\d+m\d+):? (.*?) -+", tpl))
    titles=dict(re.findall(r"const (l\d+u\d+m\d+): CurriculumModule = \{.*?\n  title: '(.*?)',", cur, re.S))
    print(f"L{L}: {len(titles)} modules, {len(heads)} template headers")
    for mid,t in titles.items():
        print(f"   {mid:9} curr='{t}'  ||  tpl='{heads.get(mid)}'")
