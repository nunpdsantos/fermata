// Resolve every L9 tryThisQuery / task query through the same parsers the executor uses.
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const { parseScaleSymbol } = await import(R + '/core/utils/scaleParser.ts');
const { parseChordSymbol, chordFromParsed, looksLikeChordSymbol } = await import(R + '/core/utils/chordParser.ts');
const { buildScale } = await import(R + '/core/constants/scales.ts');
const { L9_UNITS } = await import(R + '/core/constants/curriculumL9.ts');
const n2s = (n: any) => n.natural + n.accidental;
const qs = new Set<string>();
for (const u of L9_UNITS) { if (u.milestone) qs.add(u.milestone.tryThisQuery); for (const m of u.modules) { m.concepts.forEach((c: any) => qs.add(c.tryThisQuery)); m.tasks.forEach((t: any) => t.query && qs.add(t.query)); } }
const ROOTLESS = ['major','minor','natural minor','harmonic minor','melodic minor','chromatic','whole tone','blues','major blues','pentatonic','major pentatonic','pentatonic major','minor pentatonic','pentatonic minor','altered','diminished'];
for (const q of qs) {
  let r = '';
  if (/^key\s+of/i.test(q)) r = 'KEY';
  else if (ROOTLESS.includes(q.toLowerCase().replace(/\s+scale$/, '').trim())) r = 'ROOTLESS scale (keeps current key)';
  else {
    const s = parseScaleSymbol(q) ?? parseScaleSymbol(q.replace(/\s+scale$/i, ''));
    if (s) r = `scale ${n2s(s.root)} ${s.scaleType}: ${buildScale(s.root, s.scaleType === 'aeolian' ? 'natural_minor' : s.scaleType === 'ionian' ? 'major' : s.scaleType).notes.map(n2s).join(' ')}`;
    else {
      const w = q.replace(/\s+chord$/i, '').replace(/\s+major$/i, '').replace(/\s+minor$/i, 'm');
      const c = parseChordSymbol(w);
      if (c) { const ch = chordFromParsed(c); r = `chord ${ch.quality}: ${ch.notes.map(n2s).join(' ')}`; } else r = 'FALLBACK';
    }
  }
  console.log(`${q.padEnd(26)} -> ${r}`);
}
