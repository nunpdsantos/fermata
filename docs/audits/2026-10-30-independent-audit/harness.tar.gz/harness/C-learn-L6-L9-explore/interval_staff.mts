// interval_id exercises: does the staff (ExercisePrompt's sharps-only spelling) show the interval
// the answer key names? Oracle: generic interval number for each semitone count.
// Replicates ExercisePrompt.tsx staffNotes computation as "actual". Usage: npx tsx <this> [--plant]
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const { generateAllForLevel, mergeExerciseMaps } = await import(R + '/data/exercises/exerciseGenerator.ts');
const NUM: Record<number, number[]> = { 1: [2], 2: [2], 3: [3], 4: [3], 5: [4], 6: [4, 5], 7: [5], 8: [6], 9: [6], 10: [7], 11: [7], 12: [8] };
const L = 'CDEFGAB';
const items: any[] = [];
for (let lv = 1; lv <= 9; lv++) {
  const ex = (await import(`${R}/data/exercises/exercisesL${lv}.ts`)).default;
  const tp = (await import(`${R}/data/exercises/templatesL${lv}.ts`)).default;
  for (const list of Object.values(mergeExerciseMaps(ex, generateAllForLevel(tp, 'en'))) as any) for (const e of list) if (e.type === 'interval_id') items.push(e);
}
if (process.argv.includes('--plant')) items.push({ id: 'PLANT', config: { root: 'C', rootAccidental: '', rootOctave: 4, targetSemitones: 3, direction: 'ascending' } });
const NATURALS = ['C', 'C', 'D', 'D', 'E', 'F', 'F', 'G', 'G', 'A', 'A', 'B'];
const ACC = ['', '#', '', '#', '', '', '#', '', '#', '', '#', ''];
const rootPCs: Record<string, number> = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };
let bad = 0;
for (const e of items) {
  const c = e.config;
  let rootPC = rootPCs[c.root]; if (c.rootAccidental === '#') rootPC++; if (c.rootAccidental === 'b') rootPC--;
  const s = c.direction === 'descending' ? -c.targetSemitones : c.targetSemitones;
  const tpc = (((rootPC + s) % 12) + 12) % 12;
  const tgtLetter = NATURALS[tpc];
  const d = c.direction === 'descending' ? (L.indexOf(c.root) - L.indexOf(tgtLetter) + 7) % 7 : (L.indexOf(tgtLetter) - L.indexOf(c.root) + 7) % 7;
  const shownNum = c.targetSemitones === 12 ? 8 : d + 1;
  if (!NUM[c.targetSemitones].includes(shownNum)) { bad++; console.log(`${e.id}: ${c.root}${c.rootAccidental}${c.rootOctave} ${c.direction} ${c.targetSemitones}st -> staff shows ${c.root}${c.rootAccidental} & ${tgtLetter}${ACC[tpc]} (a ${shownNum}th-type interval) but key expects a ${NUM[c.targetSemitones].join('/')}`); }
}
console.log(`interval_id exercises: ${items.length}; staff mis-spelled: ${bad}`);
