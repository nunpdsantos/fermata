// Prompts of GENERATED exercises in the L3/L4 modules whose template header names another topic.
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const { generateAllForLevel } = await import(R + '/data/exercises/exerciseGenerator.ts');
const want = ['l3u10m3','l3u10m4','l3u11m1','l3u11m2','l3u11m3','l3u11m4','l3u11m5','l4u13m2','l4u13m3','l4u13m4','l4u13m5'];
for (const L of [3, 4]) {
  const gen = generateAllForLevel((await import(`${R}/data/exercises/templatesL${L}.ts`)).default, 'en');
  for (const m of want) if (gen[m]) { console.log(`${m} (${gen[m].length} generated)`); for (const e of gen[m].slice(0, 3)) console.log('   ', e.prompt.slice(0, 110)); }
}
