# Count generated L6/L8 multiple-choice prompts that say "this <thing>" while no stimulus is shown
# (multiple_choice has no notation/audio payload; the referent can only be in the prompt text).
# Plant: a synthetic prompt "Identify this chord." must be counted.
import json, re, sys
D='/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/C-learn-L6-L9-explore'
ex=json.load(open(D+'/all_exercises.json'))
if '--plant' in sys.argv: ex.append({'level':'6','id':'PLANTg1','type':'multiple_choice','prompt':'Identify this chord.','config':{}})
pat=re.compile(r"\bthis (?!question)\w", re.I)
hits=[e for e in ex if e['level'] in ('6','8') and e['type']=='multiple_choice' and pat.search(e['prompt'])]
from collections import Counter
c=Counter(e['prompt'] for e in hits)
for p,n in c.items(): print(n, p)
print('total', len(hits))
