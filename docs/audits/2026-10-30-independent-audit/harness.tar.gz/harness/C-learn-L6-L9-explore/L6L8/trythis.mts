// Route every L6/L8 Try-This / task / milestone query through the same parser chain
// as src/utils/queryExecutor.ts (replicated here minus the store) and print what it selects.
// Expectations are written by hand from first principles in EXPECT below; mismatches are flagged.
// Usage: cd <repo> && npx tsx <this> [--plant]
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const { L6_UNITS } = await import(R + '/core/constants/curriculumL6.ts');
const { L8_UNITS } = await import(R + '/core/constants/curriculumL8.ts');
const { parseChordSymbol, chordFromParsed, looksLikeChordSymbol } = await import(R + '/core/utils/chordParser.ts');
const { parseScaleSymbol } = await import(R + '/core/utils/scaleParser.ts');
const { buildScale } = await import(R + '/core/constants/scales.ts');
const { getPitchClass } = await import(R + '/core/constants/notes.ts');

const ROOTLESS: Record<string, string> = {
  major: 'major', minor: 'natural_minor', 'natural minor': 'natural_minor', 'harmonic minor': 'harmonic_minor',
  'melodic minor': 'melodic_minor', chromatic: 'chromatic', 'whole tone': 'whole_tone', blues: 'blues',
  'major blues': 'major_blues', pentatonic: 'pentatonic_major', 'major pentatonic': 'pentatonic_major',
  'pentatonic major': 'pentatonic_major', 'minor pentatonic': 'pentatonic_minor', 'pentatonic minor': 'pentatonic_minor',
  altered: 'altered', diminished: 'diminished_whole_half',
};
const WORDS: Array<[RegExp, string]> = [
  [/\s+diminished\s+7th$/i, 'dim7'], [/\s+diminished\s+seventh$/i, 'dim7'], [/\s+dominant\s+7th$/i, '7'],
  [/\s+dominant\s+seventh$/i, '7'], [/\s+major\s+7th$/i, 'maj7'], [/\s+major\s+seventh$/i, 'maj7'],
  [/\s+minor\s+7th$/i, 'm7'], [/\s+minor\s+seventh$/i, 'm7'], [/\s+major$/i, ''], [/\s+minor$/i, 'm'],
  [/\s+diminished$/i, 'dim'], [/\s+augmented$/i, 'aug'],
];
function norm(q: string) {
  const s = q.replace(/\s+chord$/i, '');
  if (s === q && !/\s/.test(q)) return null;
  for (const [p, suf] of WORDS) if (p.test(s)) { const r = s.replace(p, '').trim(); if (/^[A-Ga-g][#b]?$/.test(r)) return r + suf; }
  return null;
}
const nn = (n: any) => n.natural + n.accidental;
function route(query: string): string {
  const q = query.trim();
  const km = q.match(/^key\s+of\s+([A-Ga-g][#b]?)(\s+major|\s+minor)?$/i);
  if (km) return `key ${km[1]}${km[2]?.trim().toLowerCase() === 'minor' ? ' natural_minor' : ''}`;
  if (q.toLowerCase() === 'circle of fifths') return 'circle';
  const rl = ROOTLESS[q.toLowerCase().replace(/\s+scale$/, '').trim()];
  if (rl) return `scale (current key) ${rl}`;
  const ps = parseScaleSymbol(q) ?? parseScaleSymbol(q.replace(/\s+scale$/i, ''));
  if (ps) {
    const st = ({ ionian: 'major', aeolian: 'natural_minor' } as any)[ps.scaleType] ?? ps.scaleType;
    const notes = buildScale(ps.root, st).notes.map(nn).join(' ');
    return `scale ${nn(ps.root)} ${st} [${notes}]`;
  }
  const wf = norm(q);
  const ci = wf ?? (looksLikeChordSymbol(q) ? q : null);
  const pc = ci ? parseChordSymbol(ci) : null;
  if (pc) {
    const ch = chordFromParsed(pc);
    return `chord ${nn(pc.root)} ${pc.quality}${pc.bassNote ? ' /' + nn(pc.bassNote) : ''} [${ch.notes.map(nn).join(' ')}]`;
  }
  return 'FALLBACK (dead query)';
}

// Hand-written expectations (from the label/explanation text, derived independently).
const EXPECT: Record<string, RegExp> = {
  'Db major chord': /^chord Db major \[Db F Ab\]/,
  'Db/F': /^chord Db major \/F/,
  'C minor scale': /^scale C natural_minor/,
  'key of C': /^key C$/,
  'Ab major chord': /^chord Ab major \[Ab C Eb\]/,
  'G major chord': /^chord G major \[G B D\]/,
  'Ab7': /^chord Ab dominant7 \[Ab C Eb Gb\]/,
  'C/G': /^chord C major \/G/,
  'circle of fifths': /^circle$/,
  'Bdim7': /^chord B diminished7 \[B D F Ab\]/,
  'A minor scale': /^scale A natural_minor/,
  'C major chord': /^chord C major \[C E G\]/,
  'E major chord': /^chord E major \[E G# B\]/,
  'C7#5': /^chord C (dominant7sharp5|augmented7) \[C E G# Bb\]/,
  'whole tone scale': /whole_tone/,
  // label: "8 notes alternating whole and half steps" (L6) / "octatonic" (L8): W-H from C = C D Eb F Gb Ab A B
  'C diminished scale': /^scale C diminished_whole_half \[C D Eb F (Gb|F#) (Ab|G#) A B\]/,
  'C major scale': /^scale C major/, 'G major scale': /^scale G major/, 'D major scale': /^scale D major/,
  'C/E': /^chord C major \/E/,
  'key of G': /^key G$/, 'Bb major scale': /^scale Bb major/,
  'key of A minor': /^key A natural_minor$/,
  'Bdim': /^chord B diminished \[B D F\]/,
  'A natural minor scale': /^scale A natural_minor/,
  'G7': /^chord G dominant7 \[G B D F\]/,
  'Am': /^chord A minor \[A C E\]/,
  'key of Bb': /^key Bb$/, 'key of F': /^key F$/,
  'C chromatic scale': /^scale C chromatic/,
  'Cm': /^chord C minor \[C Eb G\]/,
  'C diminished 7th chord': /^chord C diminished7 \[C Eb Gb (Bbb|A)\]/,
  'C augmented chord': /^chord C augmented \[C E G#\]/,
  'D dorian scale': /^scale D dorian \[D E F G A B C\]/,
  'A harmonic minor scale': /^scale A harmonic_minor \[A B C D E F G#\]/,
  'C whole tone scale': /^scale C whole_tone \[C D E F# G# A#\]/,
};
if (process.argv.includes('--plant')) EXPECT['Db major chord'] = /^chord D major/; // must be flagged

const queries = new Map<string, string[]>();
const add = (q: string | undefined, where: string) => { if (!q) return; if (!queries.has(q)) queries.set(q, []); queries.get(q)!.push(where); };
for (const [lv, units] of [['L6', L6_UNITS], ['L8', L8_UNITS]] as const) {
  for (const u of units as any[]) {
    for (const m of u.modules) {
      m.concepts.forEach((c: any, i: number) => { add(c.tryThisQuery, `${m.id} concept${i + 1}`); add(c.childTryThisQuery, `${m.id} concept${i + 1} child`); });
      m.tasks.forEach((t: any) => add(t.query, t.id));
    }
    if (u.milestone) add(u.milestone.tryThisQuery, `${u.id} milestone`);
    if (u.completionContent) add(u.completionContent.tryThisQuery, `${u.id} completion`);
  }
}
let bad = 0;
for (const [q, where] of queries) {
  const r = route(q);
  const exp = EXPECT[q];
  const ok = exp ? exp.test(r) : false;
  if (!ok) bad++;
  console.log(`${ok ? 'ok  ' : (exp ? 'MISM' : 'NOEXP')} ${JSON.stringify(q)} -> ${r}   (${where.join(', ')})`);
}
console.log(`queries=${queries.size} flagged=${bad}`);
