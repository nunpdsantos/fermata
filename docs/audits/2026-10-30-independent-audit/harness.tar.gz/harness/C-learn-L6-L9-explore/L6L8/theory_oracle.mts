// Independent first-principles oracle for computable claims in L6/L8 lesson text and exercises.
// No app code is imported. Each check prints CLAIM / ORACLE / verdict.
// Usage: npx tsx <this> [--plant]
const PLANT = process.argv.includes('--plant');
const LET: Record<string, number> = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };
const ACC: Record<string, number> = { '': 0, '#': 1, b: -1, '##': 2, bb: -2 };
const pcOf = (n: string) => ((LET[n[0]] + ACC[n.slice(1)]) % 12 + 12) % 12;
const mod = (x: number) => ((x % 12) + 12) % 12;
let fails = 0;
function check(label: string, claim: unknown, oracle: unknown) {
  const ok = JSON.stringify(claim) === JSON.stringify(oracle);
  if (!ok) fails++;
  console.log(`${ok ? 'MATCH   ' : 'MISMATCH'} ${label}\n         claim=${JSON.stringify(claim)} oracle=${JSON.stringify(oracle)}`);
}

// ---------- set theory (Forte normal order / prime form, ICV) ----------
function normalOrder(set: number[]): number[] {
  const s = [...new Set(set.map(mod))].sort((a, b) => a - b);
  const n = s.length;
  const rots = s.map((_, i) => [...s.slice(i), ...s.slice(0, i).map((x) => x + 12)]);
  // Forte: smallest span first-to-last; ties -> smallest first-to-second, first-to-third, ...
  rots.sort((a, b) => {
    if (a[n - 1] - a[0] !== b[n - 1] - b[0]) return (a[n - 1] - a[0]) - (b[n - 1] - b[0]);
    for (let k = 1; k < n - 1; k++) if (a[k] - a[0] !== b[k] - b[0]) return (a[k] - a[0]) - (b[k] - b[0]);
    return a[0] - b[0];
  });
  return rots[0].map(mod);
}
const zero = (o: number[]) => o.map((x) => mod(x - o[0]));
function primeForm(set: number[]): number[] {
  const a = zero(normalOrder(set));
  const b = zero(normalOrder(set.map((x) => -x)));
  for (let k = a.length - 1; k >= 1; k--) {
    // Forte: compare span already equal; then pack to the left
  }
  for (let k = 1; k < a.length; k++) { if (a[k] !== b[k]) return a[k] < b[k] ? a : b; }
  return a;
}
function icv(set: number[]): number[] {
  const s = [...new Set(set.map(mod))];
  const v = [0, 0, 0, 0, 0, 0];
  for (let i = 0; i < s.length; i++) for (let j = i + 1; j < s.length; j++) { const d = mod(s[j] - s[i]); v[Math.min(d, 12 - d) - 1]++; }
  return v;
}
const notes = (ns: string[]) => ns.map(pcOf);

console.log('=== L8 set theory (curriculumL8.ts l8u27m1) ===');
check('{C,E,G} normal order = [0,4,7]', [0, 4, 7], normalOrder(notes(['C', 'E', 'G'])));
check('prime form of {C,E,G} = [0,3,7]', [0, 3, 7], primeForm(notes(['C', 'E', 'G'])));
check('{D,F,A} prime form = [0,3,7]', [0, 3, 7], primeForm(notes(['D', 'F', 'A'])));
check('ICV of [0,4,7] = <0,0,1,1,1,0>', [0, 0, 1, 1, 1, 0], icv([0, 4, 7]));
check('{0,1,4} normal order = [0,1,4]', [0, 1, 4], normalOrder([0, 1, 4]));
check('inversion {0,11,8} normalized to [0,3,4]', [0, 3, 4], zero(normalOrder([0, 11, 8])));
check('prime form of {0,1,4} = [0,1,4] (more left-packed than [0,3,4])', PLANT ? [0, 3, 4] : [0, 1, 4], primeForm([0, 1, 4]));
check('ICV [0,1,4] = <1,0,1,1,0,0>', [1, 0, 1, 1, 0, 0], icv([0, 1, 4]));
check('ICV [0,3,4] identical to [0,1,4]', icv([0, 1, 4]), icv([0, 3, 4]));
check('4-Z15 [0,1,4,6] and 4-Z29 [0,1,3,7] share ICV', icv([0, 1, 4, 6]), icv([0, 1, 3, 7]));
check('[0,1,4,6] and [0,1,3,7] are different set classes', true, JSON.stringify(primeForm([0, 1, 4, 6])) !== JSON.stringify(primeForm([0, 1, 3, 7])));
// smallest Z pair: enumerate all set classes of cardinality 2..4, find ICV collisions
for (const card of [2, 3, 4]) {
  const classes = new Map<string, number[]>();
  for (let mask = 0; mask < 4096; mask++) {
    const s = [...Array(12).keys()].filter((i) => mask & (1 << i));
    if (s.length !== card || !s.includes(0)) continue;
    classes.set(JSON.stringify(primeForm(s)), primeForm(s));
  }
  const byIcv = new Map<string, string[]>();
  for (const [k, pf] of classes) { const v = JSON.stringify(icv(pf)); byIcv.set(v, [...(byIcv.get(v) ?? []), k]); }
  const z = [...byIcv.values()].filter((g) => g.length > 1);
  console.log(`         card ${card}: ${classes.size} set classes, Z-groups: ${JSON.stringify(z)}`);
}
check('tasks t1: E,Bb,F#,C -> 4,10,6,0', [4, 10, 6, 0], notes(['E', 'Bb', 'F#', 'C']));
check('IC(4,10) = 6', 6, Math.min(mod(10 - 4), 12 - mod(10 - 4)));

console.log('\n=== octatonic (l6u19m4t2 "four tritones and four minor thirds") ===');
const octWH = [0, 2, 3, 5, 6, 8, 9, 11];
const vOct = icv(octWH);
check('octatonic tritone (ic6) count = 4', 4, vOct[5]);
check('octatonic minor-third (ic3) count = 4 (claimed)', 4, vOct[2]);
check('C W-H octatonic contains G (dominant)? claim l8u27m3t2: no', false, octWH.includes(7));
check('C W-H octatonic contains B (leading-tone pitch)? claim l8u27m3t2: no', false, octWH.includes(11));

console.log('\n=== equal divisions of the octave (l6u19m4 concept1, templatesL6 hint) ===');
const parts = (step: number) => 12 / step;
check('whole-tone scale: text "Division by 2"; number of equal parts', 2, parts(2));
check('dim7: text "Division by 3"; number of equal parts', 3, parts(3));
check('augmented triad: text "Division by 4"; number of equal parts', 4, parts(4));
const distinctTranspositions = (set: number[]) => new Set([...Array(12).keys()].map((t) => JSON.stringify(set.map((x) => mod(x + t)).sort((a, b) => a - b)))).size;
check('whole-tone transpositions = 2', 2, distinctTranspositions([0, 2, 4, 6, 8, 10]));
check('distinct dim7 chords = 3', 3, distinctTranspositions([0, 3, 6, 9]));
check('distinct augmented triads = 4', 4, distinctTranspositions([0, 4, 8]));

console.log('\n=== augmented sixths in C (l6u18m2/m3) ===');
const deg = { b6: 8, '1': 0, '2': 2, b3: 3, '#4': 6, '5': 7 } as const;
const Fr = [deg.b6, deg['1'], deg['2'], deg['#4']];
const WT0 = [0, 2, 4, 6, 8, 10];
check('Fr+6 (Ab C D F#) all in one whole-tone collection', true, Fr.every((x) => WT0.includes(x)));
check('Fr+6 contains two tritones', 2, icv(Fr)[5]);
check('aug 6th Ab->F# = 10 semitones', 10, mod(pcOf('F#') - pcOf('Ab')));
// Gr+6 lower three notes Ab C Eb: quality?
const triadQuality = (r: string, t: string, f: string) => {
  const a = mod(pcOf(t) - pcOf(r)), b = mod(pcOf(f) - pcOf(r));
  return a === 4 && b === 7 ? 'major' : a === 3 && b === 7 ? 'minor' : a === 3 && b === 6 ? 'diminished' : a === 4 && b === 8 ? 'augmented' : '?';
};
check('Gr+6 "minor quality in its lower three notes" (Ab-C-Eb)', 'minor', triadQuality('Ab', 'C', 'Eb'));
// parallel fifths Ab/Eb -> G/D
check('Gr+6 -> V: Ab-Eb is P5 and G-D is P5 (parallel fifths)', [7, 7], [mod(pcOf('Eb') - pcOf('Ab')), mod(pcOf('D') - pcOf('G'))]);
// Gr+6 in D, A
const ger = (key: string) => [8, 0, 3, 6].map((d) => mod(pcOf(key) + d));
check('Gr+6 in D = Bb D F G#', notes(['Bb', 'D', 'F', 'G#']), ger('D'));
check('Gr+6 in A = F A C D#', notes(['F', 'A', 'C', 'D#']), ger('A'));
check('Gr+6 in G (It+6 task) Eb-G-C# = b6,1,#4 of G', notes(['Eb', 'G', 'C#']), [8, 0, 6].map((d) => mod(pcOf('G') + d)));

console.log('\n=== Gr+6/V7 pivot target (l6u18m4, templatesL6:160, exercisesL6:191) ===');
// Gr+6 of key K = dom7 on b6 of K; as V7 it resolves to the key a P4 above its root
for (const K of ['C', 'D', 'A', 'F#']) {
  const root = mod(pcOf(K) + 8);
  const target = mod(root + 5);
  console.log(`         key ${K}: Gr+6 root pc ${root}, as V7 resolves to pc ${target}; semitones from tonic = ${mod(target - pcOf(K))}; from dominant = ${mod(target - (pcOf(K) + 7))}`);
}
check('templatesL6:160 claim "keys a half step away from the dominant": |target - dominant| in semitones (C)', 1, Math.min(mod(1 - 7), 12 - mod(1 - 7)));
// circle-of-fifths distance between tonics C and Db
const cofPos = (pc: number) => mod(pc * 7); // position on circle (# of fifths from C)
const cofDist = (a: number, b: number) => { const d = mod(cofPos(b) - cofPos(a)); return Math.min(d, 12 - d); };
check('C -> Db circle-of-fifths distance = 5 ("five positions")', 5, cofDist(0, 1));
check('exercisesL6:191 "up to a tritone or more apart": max possible circle distance is 6, pivot gives', 6, cofDist(0, 1));

console.log('\n=== dim7 four resolutions (l6u19m1) ===');
const bdim7 = notes(['B', 'D', 'F', 'Ab']);
check('Bdim7 notes +1 semitone = tonics C, Eb, Gb, A', notes(['C', 'Eb', 'Gb', 'A']), bdim7.map((x) => mod(x + 1)));
check('F#dim7 notes +1 = G, Bb, Db, E', notes(['G', 'Bb', 'Db', 'E']), notes(['F#', 'A', 'C', 'Eb']).map((x) => mod(x + 1)));
check('C dim7 notes +1 = Db, E, G, Bb (exercise l6u19m1e3 hint)', notes(['Db', 'E', 'G', 'Bb']), notes(['C', 'Eb', 'Gb', 'Bbb']).map((x) => mod(x + 1)));

console.log('\n=== CTo7 (l6u19m2) ===');
check('C-D#-F#-A is a dim7 (stacked m3s)', [3, 3, 3], [mod(pcOf('F#') - pcOf('D#')), mod(pcOf('A') - pcOf('F#')), mod(pcOf('C') - pcOf('A'))]);
check('G-A#-C#-E is a dim7', [3, 3, 3], [mod(pcOf('C#') - pcOf('A#')), mod(pcOf('E') - pcOf('C#')), mod(pcOf('G') - pcOf('E'))]);

console.log('\n=== chromatic mediants (exercisesL6:371 "doubly chromatic ... C major to Db minor") ===');
const maj = (r: number) => [r, mod(r + 4), mod(r + 7)], min = (r: number) => [r, mod(r + 3), mod(r + 7)];
const common = (a: number[], b: number[]) => a.filter((x) => b.includes(x)).length;
const ivlName = (s: number) => ['P1', 'm2', 'M2', 'm3', 'M3', 'P4', 'TT', 'P5', 'm6', 'M6', 'm7', 'M7'][s];
const Cmaj = maj(0);
for (let r = 0; r < 12; r++) {
  const cm = common(Cmaj, min(r));
  if (cm === 0) console.log(`         C major vs minor triad on pc ${r}: 0 common tones; root interval ${ivlName(r)}${[3, 4, 8, 9].includes(r) ? ' (third-related => doubly chromatic mediant)' : ' (NOT third-related)'}`);
}
check('Db minor root interval from C is a third (3,4,8,9 semitones)?', true, [3, 4, 8, 9].includes(pcOf('Db')));
check('C->E major common tones = 1', 1, common(Cmaj, maj(4)));
check('C->Ab major common tones = 1', 1, common(Cmaj, maj(8)));

console.log('\n=== invertible counterpoint (l6u20m3) — diatonic interval x inverts to (N+1)-x ===');
const inv = (x: number, N: number) => N + 1 - x;
check('at octave: 3->6, 5->4, 1->8, 2->7, 4->5', [6, 4, 8, 7, 5], [3, 5, 1, 2, 4].map((x) => inv(x, 8)));
check('at tenth: 3->8, 6->5', [8, 5], [3, 6].map((x) => inv(x, 10)));
check('at twelfth: 5->8', 8, inv(5, 12));
check('voice pairs for 2,3,4 voices (text: "exponentially")', [1, 3, 6], [2, 3, 4].map((n) => (n * (n - 1)) / 2));
check('triple counterpoint permutations = 6; quadruple = 24', [6, 24], [3 * 2 * 1, 4 * 3 * 2 * 1]);

console.log('\n=== transposing instruments (l6u20m4, l8u26m3) ===');
// written -> sounding: Bb clarinet sounds M2 (2 semitones) lower; F horn sounds P5 (7) lower
const sounding = (written: string, down: number) => mod(pcOf(written) - down);
check('Bb clarinet written C sounds Bb', pcOf('Bb'), sounding('C', 2));
check('Bb clarinet written D sounds C', pcOf('C'), sounding('D', 2));
check('F horn written G sounds C', pcOf('C'), sounding('G', 7));
check('Concert Bb major for a Bb clarinet is WRITTEN in (claim l6u20m4 label: "Bb major — the key a Bb clarinet reads in")', pcOf('Bb'), mod(pcOf('Bb') + 2));

console.log('\n=== polymodality / Petrushka (l8u27m3) ===');
const lyd = [0, 2, 4, 6, 7, 9, 11], mix = [0, 2, 4, 5, 7, 9, 10];
check('C Lydian ∪ C Mixolydian = 9 pitch classes', 9, new Set([...lyd, ...mix]).size);
check('C major + F# major triads = 6 distinct PCs', 6, new Set([...maj(0), ...maj(6)]).size);

console.log('\n=== rhythm (l8u27m5) ===');
check('metric modulation q=120, triplet 8th -> new 8th: new q', 180, (120 * 3) / 2);
check('polymeter 3/4 vs 4/4 realign every LCM beats', 12, 12);
// t1: 4 pulse beats vs 3 even claps over the same span: ratio
const ratio = (pulse: number, claps: number) => `${claps}:${pulse}`;
check('l8u27m5t1 "pulse of 4 beats" + "3 evenly-spaced claps into the same span" = "3-against-2"', '3:2', ratio(4, 3));
// coincidences: claps at k*4/3, beats at integers 0..3 -> only 0 coincides
const coincide = [0, 1, 2].filter((k) => Number.isInteger((k * 4) / 3)).length;
check('hands coincide only on beat 1', 1, coincide);

console.log('\n=== quartal chord (l8u27m3t1) C-F-Bb-Eb = stacked P4 ===');
check('C-F, F-Bb, Bb-Eb are all 5 semitones', [5, 5, 5], [mod(pcOf('F') - pcOf('C')), mod(pcOf('Bb') - pcOf('F')), mod(pcOf('Eb') - pcOf('Bb'))]);

console.log(`\nTOTAL MISMATCHES: ${fails}`);
