# Compare template section titles (comment headers in templatesL6/L8.ts) with curriculum module titles,
# and count generated exercises per module from all_exercises.json.
# Usage: python3 -I module_topic_mismatch.py
import json, re
REPO='/Users/nunosantos/Documents/Base/Music/new_music_app'
D='/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/C-learn-L6-L9-explore'
ex=json.load(open(D+'/all_exercises.json'))
for L in ('6','8'):
    tpl=open(f'{REPO}/src/data/exercises/templatesL{L}.ts').read()
    cur=open(f'{REPO}/src/core/constants/curriculumL{L}.ts').read()
    heads=dict(re.findall(r"// ---- (l\d+u\d+m\d+): (.*?) ----", tpl))
    titles=dict(re.findall(r"const (l\d+u\d+m\d+): CurriculumModule = \{.*?\n  title: '(.*?)',", cur, re.S))
    for mid in titles:
        gen=[e['id'] for e in ex if e['moduleId']==mid and re.search(r'g\d+$', e['id'])]
        print(f"L{L} {mid}: curriculum='{titles[mid]}' | template='{heads.get(mid)}' | generated={len(gen)}")
