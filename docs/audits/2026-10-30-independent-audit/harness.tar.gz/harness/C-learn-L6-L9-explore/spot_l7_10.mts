const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const { parseScaleSymbol } = await import(R + '/core/utils/scaleParser.ts');
for (const q of ['C double harmonic major', 'C double harmonic', 'C altered scale', 'C altered', 'D dorian'])
  console.log(q.padEnd(26), '->', JSON.stringify(parseScaleSymbol(q) ?? parseScaleSymbol(q.replace(/\s+scale$/i, ''))));
