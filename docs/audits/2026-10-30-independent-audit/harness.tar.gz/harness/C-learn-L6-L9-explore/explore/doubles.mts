// Count double accidentals (## / bb) in the note row Explore shows, per scale type, over the 12 KeySelector roots.
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const S = await import(R + '/core/constants/scales.ts');
const UI = ['C', 'C#', 'D', 'Eb', 'E', 'F', 'F#', 'G', 'Ab', 'A', 'Bb', 'B'];
const rows: string[] = [];
for (const sc of Object.keys(S.SCALE_FORMULAS)) {
  let cnt = 0; const ex: string[] = [];
  for (const r of UI) { const ns = S.buildScale({ natural: r[0], accidental: r.slice(1) }, sc).notes.map((n: any) => n.natural + n.accidental); const d = ns.filter((x: string) => x.endsWith('##') || x.endsWith('bb')); cnt += d.length; if (d.length && ex.length < 2) ex.push(`${r}: ${ns.join(' ')}`); }
  if (cnt) rows.push(`${sc.padEnd(22)} ${String(cnt).padStart(3)} double accidentals   e.g. ${ex.join(' || ')}`);
}
console.log(rows.join('\n'));
