// Plant for identify.mts: C E G A presented with A expected as root must be flagged (top result root is C).
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const { identifyChordFromNotes } = await import(R + '/core/utils/reverseChordParser.ts');
const n = (s: string) => ({ natural: s[0], accidental: s.slice(1) });
const top = identifyChordFromNotes(['C', 'E', 'G', 'A'].map(n)).results[0];
console.log('top:', top.chord.root.natural + top.chord.root.accidental, top.chord.quality, '-> root-check vs A would', top.chord.root.natural === 'A' ? 'PASS' : 'FLAG');
