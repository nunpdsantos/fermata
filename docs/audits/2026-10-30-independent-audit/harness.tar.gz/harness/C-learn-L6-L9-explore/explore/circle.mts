// Circle of Fifths display checks. Replicates CircleOfFifths.tsx selection logic (lines 61-68, 120-133, 362-372)
// using the app's own constants, and compares with oracle key signatures / triad numerals.
// Usage: cd <repo> && npx tsx <this> [--plant]
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const K = await import(R + '/components/theory/circleOfFifthsConstants.ts');
const S = await import(R + '/core/constants/scales.ts');
const { getPitchClass } = await import(R + '/core/constants/notes.ts');
const PLANT = process.argv.includes('--plant');
const LET = ['C', 'D', 'E', 'F', 'G', 'A', 'B'];
const LPC: Record<string, number> = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };
const mod = (n: number) => ((n % 12) + 12) % 12;
// oracle: key signature of a heptatonic diatonic mode = accidentals in its correctly spelled scale
function oracleSig(rootL: string, rootA: string, formula: number[]) {
  const rpc = LPC[rootL] + ({ '': 0, '#': 1, b: -1 } as any)[rootA];
  let sh = 0, fl = 0;
  formula.forEach((st, i) => {
    const L = LET[(LET.indexOf(rootL) + i) % 7];
    const d = mod(rpc + st - LPC[L] + 6) - 6;
    if (d > 0) sh += d; if (d < 0) fl -= d;
  });
  return sh && fl ? `mixed(${sh}#,${fl}b)` : sh ? `${sh}♯` : fl ? `${fl}♭` : '';
}
const UI_ROOTS = ['C', 'C#', 'D', 'Eb', 'E', 'F', 'F#', 'G', 'Ab', 'A', 'Bb', 'B'];
const DIATONIC_MODES = ['major', 'natural_minor', 'dorian', 'phrygian', 'lydian', 'mixolydian', 'locrian'];
const sigIssues: string[] = [];
for (const sc of DIATONIC_MODES) for (const r of UI_ROOTS) {
  const key = { natural: r[0], accidental: r.slice(1) };
  const isMinorSel = K.MINOR_SCALES.includes(sc);
  const arr = isMinorSel ? K.CIRCLE_MINOR : K.CIRCLE_MAJOR;
  let idx = arr.findIndex((n: any) => getPitchClass(n) === getPitchClass(key)); if (idx < 0) idx = 0;
  const shown = K.KEY_SIGNATURES[idx] || 'no ♯/♭';
  const exp = oracleSig(r[0], r.slice(1), S.SCALE_FORMULAS[sc]) || 'no ♯/♭';
  const ok = shown === exp || shown.split('/').includes(exp);
  if (!ok) sigIssues.push(`${r} ${sc}: centre shows "${r}${isMinorSel ? 'm' : ''}" with "${shown}", correct signature ${exp}`);
}
// numerals on the major ring: ROMAN_NUMERALS[degree of that note in the selected scale]
const TQ: Record<string, string> = { '4,7': 'M', '3,7': 'm', '3,6': 'd', '4,8': 'A' };
const ROM = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII'];
const numIssues: string[] = [];
for (const sc of ['major', 'natural_minor', 'harmonic_minor', 'melodic_minor', 'dorian', 'phrygian', 'lydian', 'mixolydian', 'locrian']) {
  const f = S.SCALE_FORMULAS[sc];
  const scale = S.buildScale({ natural: 'C', accidental: '' }, sc);
  const bad: string[] = [];
  for (const n of K.CIRCLE_MAJOR) {
    const deg = scale.notes.findIndex((x: any) => getPitchClass(x) === getPitchClass(n)) + 1;
    if (!deg) continue;
    const shown = K.ROMAN_NUMERALS[deg];
    const i = deg - 1;
    const q = TQ[`${mod(f[(i + 2) % 7] - f[i])},${mod(f[(i + 4) % 7] - f[i])}`];
    const exp = (q === 'm' || q === 'd' ? ROM[i].toLowerCase() : ROM[i]) + (q === 'd' ? '°' : q === 'A' ? '+' : '');
    if (shown !== exp) bad.push(`${n.natural}${n.accidental}: "${shown}" (triad on that degree is ${exp})`);
  }
  if (bad.length) numIssues.push(`C ${sc}: ${bad.join('; ')}`);
}
// distance labels: shared notes between major scales n fifths apart
const distIssues: string[] = [];
const C_MAJ = new Set(S.SCALE_FORMULAS.major.map((x: number) => x));
for (let d = 0; d <= 6; d++) {
  const other = new Set(S.SCALE_FORMULAS.major.map((x: number) => mod(x + 7 * d)));
  const shared = [...C_MAJ].filter((x) => other.has(x)).length;
  const lab = PLANT && d === 2 ? 'Related · 4 shared notes' : K.DISTANCE_LABELS[d];
  const m = lab.match(/(\d) shared/);
  if (d > 0 && (!m || +m[1] !== shared)) distIssues.push(`distance ${d}: label "${lab}", actual shared ${shared}`);
}
console.log(`## key signature shown in Circle centre (${DIATONIC_MODES.length} modes x ${UI_ROOTS.length} KeySelector roots): ${sigIssues.length} wrong`);
sigIssues.forEach((x) => console.log('  ' + x));
console.log(`\n## major-ring Roman numerals vs selected scale (C): ${numIssues.length} scales affected`);
numIssues.forEach((x) => console.log('  ' + x));
console.log(`\n## distance labels: ${distIssues.length} wrong`); distIssues.forEach((x) => console.log('  ' + x));
