const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const ids = process.argv.slice(2);
for (let L = 1; L <= 9; L++) { const m = await import(`${R}/core/constants/curriculumL${L}.ts`); for (const u of m[`L${L}_UNITS`]) for (const mod of u.modules) if (ids.includes(mod.id)) { console.log(`\n### ${mod.id} ${mod.title}`); console.log(JSON.stringify({ objectives: mod.objectives, concepts: mod.concepts.map((c: any) => ({ t: c.title, e: c.explanation, q: c.tryThisQuery })), tasks: mod.tasks.map((t: any) => t.instruction) }, null, 1)); } }
