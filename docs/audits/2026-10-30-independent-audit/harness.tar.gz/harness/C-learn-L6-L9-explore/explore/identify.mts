// Chord Builder identification: feed every quality x 12 roots (notes in root-position order, as the
// builder strip produces them) to identifyChordFromNotes and check the top result.
// Oracle: the top result must have the SAME root pitch class and the SAME pitch-class set as the input.
// Usage: cd <repo> && npx tsx <this>
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const C = await import(R + '/core/constants/chords.ts');
const { identifyChordFromNotes } = await import(R + '/core/utils/reverseChordParser.ts');
const { getPitchClass } = await import(R + '/core/constants/notes.ts');
const ROOTS = ['C', 'Db', 'D', 'Eb', 'E', 'F', 'F#', 'G', 'Ab', 'A', 'Bb', 'B'];
const pcs = (ns: any[]) => [...new Set(ns.map((n) => getPitchClass(n)))].sort((a, b) => a - b).join(',');
const byQuality: Record<string, string> = {};
let total = 0, wrongRoot = 0, wrongSet = 0, notExact = 0;
for (const q of Object.keys(C.CHORD_FORMULAS)) for (const r of ROOTS) {
  total++;
  const root = { natural: r[0], accidental: r.slice(1) };
  const notes = C.buildChord(root, q).notes;
  // builder strip sorts by semitone step above the root (ChordBuilderPanel.tsx:128)
  const sorted = [...notes].sort((a: any, b: any) => ((getPitchClass(a) - getPitchClass(root) + 12) % 12) - ((getPitchClass(b) - getPitchClass(root) + 12) % 12));
  const top = identifyChordFromNotes(sorted).results[0];
  if (!top) { byQuality[q] = 'NO RESULT'; continue; }
  const rootOk = getPitchClass(top.chord.root) === getPitchClass(root);
  const setOk = pcs(top.chord.notes) === pcs(notes);
  if (!rootOk) wrongRoot++; if (!setOk) wrongSet++; if (top.confidence !== 'exact') notExact++;
  if ((!rootOk || !setOk || top.confidence !== 'exact') && !byQuality[q]) byQuality[q] = `${r}${C.CHORD_SYMBOLS[q]} -> ${top.chord.root.natural}${top.chord.root.accidental} ${top.chord.quality} (${top.confidence}, score ${top.score.toFixed(0)})${setOk ? '' : ' DIFFERENT NOTES'}`;
}
console.log(`identified ${total} chords: wrong root ${wrongRoot}, different pitch set ${wrongSet}, not 'exact' ${notExact}`);
for (const [q, s] of Object.entries(byQuality)) console.log(`  ${q.padEnd(22)} e.g. ${s}`);
