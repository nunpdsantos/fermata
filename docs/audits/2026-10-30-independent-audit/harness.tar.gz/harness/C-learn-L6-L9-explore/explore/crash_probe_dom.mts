// Mount the REAL ChordGrid component (Explore) in jsdom for every scale the KeySelector offers,
// with the store set to that scale, and record render errors.
// Usage: cd /Users/nunosantos/Documents/Base/Music/new_music_app && npx tsx <this>
const NM = '/Users/nunosantos/Documents/Base/Music/new_music_app/node_modules';
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const { JSDOM } = await import(NM + '/jsdom/lib/api.js');
const dom = new JSDOM('<!doctype html><div id="root"></div>', { url: 'http://localhost/' });
const g: any = globalThis;
for (const k of ['window', 'document', 'navigator', 'localStorage', 'HTMLElement', 'Node', 'getComputedStyle', 'matchMedia', 'requestAnimationFrame']) {
  try { g[k] = (dom.window as any)[k]; } catch {}
}
g.window.matchMedia ??= () => ({ matches: false, addEventListener() {}, removeEventListener() {}, addListener() {}, removeListener() {} });
g.matchMedia = g.window.matchMedia;
g.IS_REACT_ACT_ENVIRONMENT = true;
const React = (await import(NM + '/react/index.js')).default;
g.React = React; // tsx compiles JSX with the classic runtime here
const { createRoot } = await import(NM + '/react-dom/client.js');
// (i18n init skipped: import.meta.env is undefined under tsx; t() returns keys)
const { useAppStore } = await import(R + '/state/store.ts');
const { ChordGrid } = await import(R + '/components/theory/ChordGrid.tsx');
const { SCALE_FORMULAS } = await import(R + '/core/constants/scales.ts');
const errors: string[] = [];
async function mount(sc: string) {
  useAppStore.setState({ selectedScale: sc, selectedKey: { natural: 'C', accidental: '' } });
  const el = g.document.createElement('div');
  g.document.body.appendChild(el);
  let err = '';
  const root = createRoot(el, { onUncaughtError: (e: any) => { err = e.message; }, onCaughtError: (e: any) => { err = e.message; } });
  try { await React.act(async () => { root.render(React.createElement(ChordGrid)); }); } catch (e: any) { err = err || e.message; }
  const text = el.textContent ?? '';
  try { await React.act(async () => root.unmount()); } catch {}
  return { err, text };
}
const ok = await mount('dorian');
console.log('control dorian ChordGrid text:', ok.text.slice(0, 120), ok.err ? 'ERR ' + ok.err : '');
for (const sc of Object.keys(SCALE_FORMULAS)) {
  const r = await mount(sc);
  if (r.err) { errors.push(sc); console.log(`RENDER ERROR ${sc}: ${r.err}`); }
  else if (/undefined/.test(r.text)) console.log(`RENDERS "undefined" ${sc}: ${r.text}`);
}
console.log(`scales mounted: ${Object.keys(SCALE_FORMULAS).length}; render errors: ${errors.length} (${errors.join(', ')})`);
