// Print the Roman numerals + chords Explore's ChordGrid shows for C in each 7-note mode,
// next to an oracle numeral written relative to the parallel MAJOR scale (accidental prefix).
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const S = await import(R + '/core/constants/scales.ts');
const C = await import(R + '/core/constants/chords.ts');
const MAJ = [0, 2, 4, 5, 7, 9, 11];
const ROM = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII'];
const Q: Record<string, [boolean, string]> = { major: [false, ''], minor: [true, ''], diminished: [true, '°'], augmented: [false, '+'] };
let diff = 0;
for (const sc of ['major', 'natural_minor', 'harmonic_minor', 'melodic_minor', 'dorian', 'phrygian', 'lydian', 'mixolydian', 'locrian']) {
  const f = S.SCALE_FORMULAS[sc];
  const dia = C.getDiatonicChordsForScale(S.buildScale({ natural: 'C', accidental: '' }, sc));
  const app = dia.map((d: any) => d.numeral);
  const oracle = dia.map((d: any, i: number) => {
    const delta = f[i] - MAJ[i];
    const pre = delta === -1 ? 'b' : delta === 1 ? '#' : '';
    const [lower, suf] = Q[d.chord.quality];
    return pre + (lower ? ROM[i].toLowerCase() : ROM[i]) + suf;
  });
  const d = app.filter((x: string, i: number) => x !== oracle[i]).length; diff += d;
  console.log(`${sc.padEnd(15)} app: ${app.join(' ').padEnd(30)} relative-to-major: ${oracle.join(' ')}${d ? `  (${d} differ)` : ''}`);
}
console.log('numerals differing from parallel-major convention:', diff);
