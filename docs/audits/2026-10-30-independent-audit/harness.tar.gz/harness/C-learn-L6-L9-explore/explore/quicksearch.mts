// Run the real Cmd+K result builder over a fixed query list and print labels (+ the notes of chord hits).
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const { getResults } = await import(R + '/components/navigation/quickSearchResults.ts');
const { useAppStore } = await import(R + '/state/store.ts');
const Q = ['C', 'Cm7b5', 'Cø7', 'Co7', 'C dim', 'Bb+', 'C6', 'Csus', 'F# dorian', 'Gb major', 'Cb major', 'E# major', 'dominant', 'Dominant 7th', 'Half-Diminished', 'tritone', 'neapolitan', 'augmented sixth', 'C half diminished', 'C hijaz', 'C jewish', 'C gypsy minor', 'C 7#9', 'hendrix', 'C13', 'Cmaj7#11', 'C7alt', 'secondary dominant', 'phrygian dominant', 'D aeolian', 'E ionian', 'C diminished', 'Fb', 'C-7', 'CΔ7', 'C69', 'C6/9', 'Cm(maj7)', 'C7sus4', 'Cadd2', 'C5'];
for (const q of Q) {
  const rs = getResults(q);
  const parts = rs.map((r: any) => {
    let extra = '';
    if (r.type === 'Chord') { r.action(); const ch = useAppStore.getState().selectedChord; if (ch) extra = ` {${ch.notes.map((n: any) => n.natural + n.accidental).join(' ')}}`; }
    if (r.type === 'Scale') { r.action(); const st = useAppStore.getState(); extra = ` {${st.selectedKey.natural}${st.selectedKey.accidental} ${st.selectedScale}}`; }
    return `${r.type}:${r.label}${extra}`;
  });
  console.log(`"${q}" -> ${parts.join(' | ') || '(none)'}`);
}
