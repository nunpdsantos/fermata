// Execute the curriculum Try-This query 'C diminished scale' through the real executor and report the store's scale,
// then whether that scale's diatonic computation (what useKeyContext runs on every render) throws.
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const QE = await import(R + '/utils/queryExecutor.ts');
const { useAppStore } = await import(R + '/state/store.ts');
const S = await import(R + '/core/constants/scales.ts');
const C = await import(R + '/core/constants/chords.ts');
const fn = (QE as any).executeQuery ?? Object.values(QE).find((v: any) => typeof v === 'function');
console.log('executor export used:', Object.keys(QE).join(', '));
const res = fn('C diminished scale');
const st = useAppStore.getState();
console.log('result:', JSON.stringify(res)?.slice(0, 120), '| store scale:', st.selectedKey.natural + st.selectedKey.accidental, st.selectedScale);
try { C.getDiatonicChordsForScale(S.buildScale(st.selectedKey, st.selectedScale)); console.log('diatonic: ok'); } catch (e: any) { console.log('diatonic THROWS:', e.message); }
