// (a) moduleIndex (Cmd+K + Learn-more) vs the real curriculum; (b) qualityToModule targets actually teach the quality.
// Usage: cd <repo> && npx tsx <this> [--plant]
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const PLANT = process.argv.includes('--plant');
const { MODULE_INDEX, findModulesByQuery } = await import(R + '/data/moduleIndex.ts');
const { QUALITY_TO_MODULE } = await import(R + '/data/qualityToModule.ts');
const C = await import(R + '/core/constants/chords.ts');
const mods: any[] = [];
for (let L = 1; L <= 9; L++) {
  const m = await import(`${R}/core/constants/curriculumL${L}.ts`);
  const units = m[`L${L}_UNITS`];
  for (const u of units) u.modules.forEach((mod: any, i: number) => mods.push({ ...mod, unitIdx: i + 1, unitIdRaw: u.id }));
}
const byId = new Map(mods.map((m) => [m.id, m]));
const idx = PLANT ? [...MODULE_INDEX, { id: 'l9u99m1', title: 'Ghost', subtitle: '', level: 'l9', unitId: 'u99', moduleIndex: 1 }] : MODULE_INDEX;
const ixIssues: string[] = [];
for (const e of idx) {
  const m = byId.get(e.id);
  if (!m) { ixIssues.push(`${e.id}: in index but no such curriculum module`); continue; }
  if (m.title !== e.title) ixIssues.push(`${e.id}: title "${e.title}" vs curriculum "${m.title}"`);
  if (m.subtitle !== e.subtitle) ixIssues.push(`${e.id}: subtitle "${e.subtitle}" vs curriculum "${m.subtitle}"`);
  if (m.unitIdx !== e.moduleIndex) ixIssues.push(`${e.id}: moduleIndex ${e.moduleIndex} vs curriculum position ${m.unitIdx}`);
}
for (const m of mods) if (!idx.find((e: any) => e.id === m.id)) ixIssues.push(`${m.id}: curriculum module missing from index`);
console.log(`curriculum modules: ${mods.length}; index entries: ${idx.length}; mismatches: ${ixIssues.length}`);
ixIssues.forEach((x) => console.log('  ' + x));
// (b) does the target module mention the chord quality?
const SYN: Record<string, RegExp> = {
  major: /major triad/i, minor: /minor triad/i, diminished: /diminished triad|dim(inished)? /i, augmented: /augmented triad|augmented/i,
  major6: /\b(6th chord|maj6|C6\b|major 6|added sixth|6 chord)/i, minor6: /\bm6\b|minor 6(th)? chord|minor sixth chord/i,
  six_nine: /6\/9|six-nine/i, minor_six_nine: /m6\/9|minor 6\/9/i, add9: /add9|add 9|added ninth/i, add11: /add11|add 11|added eleventh/i,
  major7: /maj7|major seventh|major 7/i, minor7: /\bm7\b|minor seventh|minor 7/i, diminished7: /dim7|°7|o7|fully diminished|diminished seventh/i,
  half_diminished7: /half.diminished|ø7|m7b5|m7♭5/i, minor_major7: /mMaj7|minor.major|m\(maj7\)|mΔ7|mΔ ?7|imM7|i\(m.?Δ ?7\)/i,
  augmented7: /aug(mented)? ?7|\+7|7#5|7♯5/i, augmented_major7: /maj7#5|maj7♯5|augmented.major|\+maj7|III\+7|III\+M7|\+Δ/i,
  diminished_major7: /dim\(maj7\)|diminished.major/i, major7flat5: /maj7b5|maj7♭5|major 7(th)? flat 5/i, dominant7: /dominant seventh|V7/i,
  sus2: /sus2/i, sus4: /sus4/i, sus2sus4: /sus2\/4|sus2sus4|sus24/i, dominant7sus4: /7sus4|7sus/i, dominant9sus4: /9sus4|9sus/i,
  dominant7alt: /7alt|altered dominant|alt\b/i, dominant7flat9: /7b9|7♭9|flat.?9|♭9|b9/i, dominant7sharp9: /7#9|7♯9|sharp.?9|#9|♯9/i,
  dominant7flat5: /7b5|7♭5/i, dominant7sharp5: /7#5|7♯5|aug/i, dominant7sharp5flat9: /7#5b9|7♯5♭9/i, dominant7flat5flat9: /7b5b9|7♭5♭9/i,
  dominant7sharp5sharp9: /7#5#9|7♯5♯9/i, dominant7flat5sharp9: /7b5#9|7♭5♯9/i,
  major9: /maj9|major ninth|major 9/i, minor9: /\bm9\b|minor ninth|minor 9/i, dominant9: /\b9th|dominant ninth|\b9\b/i,
  major11: /maj11|major eleventh/i, minor11: /\bm11\b|minor eleventh/i, dominant11: /\b11th|\b11\b/i, dominant9sharp11: /9#11|9♯11/i,
  dominant7sharp11: /7#11|7♯11/i, major9sharp11: /maj9#11|maj9♯11/i, major13: /maj13/i, minor13: /\bm13\b/i, dominant13: /\b13th|\b13\b/i,
  dominant13flat9: /13b9|13♭9/i, dominant7flat13: /7b13|7♭13|b13|♭13/i, major7sharp11: /maj7#11|maj7♯11|lydian chord/i, power: /power chord|\b5 chord|\(5\)/i,
};
const linkIssues: string[] = [];
const qmap = PLANT ? { ...QUALITY_TO_MODULE, power: 'l1u1m1' } : QUALITY_TO_MODULE;
for (const [q, mid] of Object.entries(qmap) as [string, string][]) {
  const m = byId.get(mid);
  if (!m) { linkIssues.push(`${q} -> ${mid}: module does not exist`); continue; }
  const text = JSON.stringify(m);
  const re = SYN[q];
  if (!re) { linkIssues.push(`${q}: no oracle regex`); continue; }
  if (!re.test(text)) linkIssues.push(`${q} -> ${mid} "${m.title}": quality not mentioned anywhere in module (title/objectives/concepts/tasks)`);
}
console.log(`\nqualityToModule: ${Object.keys(qmap).length} links; ${linkIssues.length} targets never mention the quality`);
linkIssues.forEach((x) => console.log('  ' + x));
// (c) Learn-more for SCALES: none exists (only chords pass moduleId); what does the fuzzy query give for each scale name?
console.log('\nfindModulesByQuery(CHORD_QUALITY_NAMES[q]) is NOT used when moduleId is set; spot-check of fuzzy hits for mode names:');
for (const name of ['Dorian', 'Phrygian', 'Lydian', 'Mixolydian', 'Locrian', 'Altered', 'Whole Tone', 'Blues', 'Harmonic Minor']) {
  const hit = findModulesByQuery(name, 1)[0];
  console.log(`  "${name}" -> ${hit ? hit.id + ' ' + hit.title : 'none'}`);
}
