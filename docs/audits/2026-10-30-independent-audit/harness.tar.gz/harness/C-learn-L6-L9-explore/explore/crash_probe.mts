// Render a component that calls the real useKeyContext hook with each selectable scale.
// Usage: cd <repo> && npx tsx <this>
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const React = (await import('/Users/nunosantos/Documents/Base/Music/new_music_app/node_modules/react/index.js')).default;
const { renderToString } = await import('/Users/nunosantos/Documents/Base/Music/new_music_app/node_modules/react-dom/server.node.js');
const { useAppStore } = await import(R + '/state/store.ts');
const { useKeyContext } = await import(R + '/hooks/useKeyContext.ts');
const { SCALE_FORMULAS } = await import(R + '/core/constants/scales.ts');
// zustand SSR reads getInitialState(); point it at live state so setState is honoured
(useAppStore as any).getInitialState = () => useAppStore.getState();
function Probe() { const k = useKeyContext(); return React.createElement('div', null, k.diatonicChords.map((d: any) => d.numeral).join(' ')); }
let bad = 0;
for (const sc of Object.keys(SCALE_FORMULAS)) {
  useAppStore.setState({ selectedScale: sc, selectedKey: { natural: 'C', accidental: '' } });
  try { const html = renderToString(React.createElement(Probe)); if (/undefined/.test(html)) console.log(`RENDERS-UNDEFINED ${sc}: ${html}`); }
  catch (e: any) { bad++; console.log(`RENDER THROWS ${sc}: ${e.message}`); }
}
// plant: a component that throws must be reported
try { renderToString(React.createElement(() => { throw new Error('planted'); })); } catch (e: any) { console.log('PLANT caught:', e.message); }
useAppStore.setState({ selectedScale: 'dorian' }); console.log('dorian numerals:', renderToString(React.createElement(Probe)));
console.log(`scales rendered: ${Object.keys(SCALE_FORMULAS).length}, throwing: ${bad}`);
