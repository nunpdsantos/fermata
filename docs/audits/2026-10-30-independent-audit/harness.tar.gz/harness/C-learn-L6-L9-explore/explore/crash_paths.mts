// Which "Compatible Scales" chips in the chord panel (CurrentChordPanel.tsx:265-283, onClick -> setScale) lead to a scale
// whose diatonic-chord computation throws? Crash set is computed live, not hard-coded.
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const S = await import(R + '/core/constants/scales.ts');
const C = await import(R + '/core/constants/chords.ts');
const { CHORD_SCALE_MAP } = await import(R + '/core/constants/chordScaleRelationships.ts');
const crash = new Set<string>();
for (const sc of Object.keys(S.SCALE_FORMULAS)) { try { C.getDiatonicChordsForScale(S.buildScale({ natural: 'C', accidental: '' }, sc)); } catch { crash.add(sc); } }
console.log('crashing scale types:', [...crash].join(', '));
const paths: string[] = [];
for (const [q, sugg] of Object.entries(CHORD_SCALE_MAP) as [string, any[]][]) for (const s of sugg) if (crash.has(s.scale)) paths.push(`${q} -> "${S.SCALE_TYPE_NAMES[s.scale]}" chip`);
console.log(`${paths.length} chord-panel chips lead to a crashing scale:`); paths.forEach((p) => console.log('  ' + p));
