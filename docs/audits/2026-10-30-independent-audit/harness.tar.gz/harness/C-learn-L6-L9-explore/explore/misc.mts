// Misc probes: buildInterval spelling; exportHelpers summary for bebop_dorian; inversion labels for >4-note chords;
// ChordBrowser coverage; generic-name duplicates.
import { readFileSync } from 'node:fs';
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const I = await import(R + '/core/constants/intervals.ts');
const S = await import(R + '/core/constants/scales.ts');
const C = await import(R + '/core/constants/chords.ts');
const n = (s: string) => ({ natural: s[0], accidental: s.slice(1) });
const s = (x: any) => x.natural + x.accidental;
console.log('buildInterval C+3 ->', s(I.buildInterval(n('C'), 3).upperNote), '| E+8 ->', s(I.buildInterval(n('E'), 8).upperNote), '| D+6 ->', s(I.buildInterval(n('D'), 6).upperNote));
// exportHelpers.generateScaleSummary with bebop_dorian (numeral undefined) — import the real function
const { generateScaleSummary } = await import(R + '/utils/exportHelpers.ts');
const sc = S.buildScale(n('C'), 'bebop_dorian');
const dia = C.getDiatonicChordsForScale(sc).map((d: any, i: number) => ({ ...d, degree: i + 1 }));
try { generateScaleSummary(sc, dia, null); console.log('summary bebop_dorian: ok'); } catch (e: any) { console.log('summary bebop_dorian THROWS:', e.message); }
console.log('summary major sample:\n' + generateScaleSummary(S.buildScale(n('C'), 'major'), C.getDiatonicChordsForScale(S.buildScale(n('C'), 'major')).map((d: any, i: number) => ({ ...d, degree: i + 1 })), C.buildChord(n('B'), 'half_diminished7')).split('\n').slice(4, 8).join('\n'));
// inversion button labels (CurrentChordPanel.tsx:38 + 218-233): keys parsed from source
const panel = readFileSync(R + '/components/panels/CurrentChordPanel.tsx', 'utf8');
const KEYS = JSON.parse(panel.match(/const INVERSION_LABEL_KEYS = (\[[^\]]*\])/)![1].replace(/'/g, '"'));
const en = JSON.parse(readFileSync(R + '/i18n/locales/en.json', 'utf8'));
const lab = (k: string) => en.panel[k.split('.')[1]];
let affected = 0; const ex: string[] = [];
for (const [q, f] of Object.entries(C.CHORD_FORMULAS) as [string, number[]][]) {
  const labels = Array.from({ length: f.length }, (_, i) => lab(KEYS[i] ?? 'panel.rootPos'));
  if (f.length > KEYS.length) { affected++; if (ex.length < 4) ex.push(`${q} (${f.length} notes): ${labels.join(' | ')}`); }
}
console.log(`inversion buttons: ${affected} qualities have more notes than labels; e.g.\n  ${ex.join('\n  ')}`);
// ChordBrowser coverage
const cb = readFileSync(R + '/components/theory/ChordBrowser.tsx', 'utf8');
const listed = new Set([...cb.split('export function')[0].matchAll(/'([a-z0-9_]+)'/g)].map((m) => m[1]));
const missing = Object.keys(C.CHORD_FORMULAS).filter((q) => !listed.has(q));
console.log('ChordBrowser omits qualities:', missing.join(', '));
// identical pitch-class content under two names in the browser
const key = (q: string) => (C.CHORD_FORMULAS as any)[q].map((x: number) => x % 12).sort((a: number, b: number) => a - b).join(',');
const groups: Record<string, string[]> = {};
for (const q of listed) if ((C.CHORD_FORMULAS as any)[q]) (groups[key(q)] ??= []).push(q);
console.log('same-pitch-set qualities listed separately:', Object.values(groups).filter((g) => g.length > 1).map((g) => g.join(' = ')).join('; '));
