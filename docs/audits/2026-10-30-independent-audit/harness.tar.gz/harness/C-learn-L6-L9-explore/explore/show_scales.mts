// Print the note row ExploreView shows (ExploreView.tsx:99-100) and ScaleDegreeBar labels for selected scales.
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const S = await import(R + '/core/constants/scales.ts');
for (const sc of ['diminished_half_whole', 'diminished_whole_half', 'whole_tone', 'blues', 'chromatic']) for (const r of ['C', 'Eb', 'F#']) {
  const notes = S.buildScale({ natural: r[0], accidental: r.slice(1) }, sc).notes;
  const f = S.SCALE_FORMULAS[sc];
  const labs = f.map((st: number, i: number) => S.getScaleDegreeIntervalLabel(i, st, notes.length));
  console.log(`${(r + ' ' + sc).padEnd(26)} notes: ${notes.map((n: any) => n.natural + n.accidental).join(' ').padEnd(34)} bar labels: ${labs.join(' ')}`);
}
