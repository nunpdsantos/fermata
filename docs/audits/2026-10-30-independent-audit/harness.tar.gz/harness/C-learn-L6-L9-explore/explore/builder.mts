// ChordBuilderPanel "Notes" row spelling. Replicates noteAtStep (ChordBuilderPanel.tsx:78-85): a step
// is spelled from the selected scale if present, else PC_TO_NOTE_SHARP/FLAT by isFlatKey (line 76).
// The two tables are parsed from the component source (not retyped). Oracle = letter-per-chord-tone spelling.
// Usage: cd <repo> && npx tsx <this>
import { readFileSync } from 'node:fs';
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const S = await import(R + '/core/constants/scales.ts');
const { getPitchClass } = await import(R + '/core/constants/notes.ts');
const src = readFileSync(R + '/components/theory/ChordBuilderPanel.tsx', 'utf8');
const tbl = (name: string) => { const body = src.split(`const ${name}`)[1].split('};')[0]; const m: Record<number, string> = {}; for (const x of body.matchAll(/(\d+):\s*\{ natural: '([A-G])', accidental: '([#b]?)' \}/g)) m[+x[1]] = x[2] + x[3]; return m; };
const SHARP = tbl('PC_TO_NOTE_SHARP'); const FLAT = { ...SHARP, ...tbl('PC_TO_NOTE_FLAT') };
const LET = ['C', 'D', 'E', 'F', 'G', 'A', 'B']; const LPC: Record<string, number> = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };
const ACC: Record<string, number> = { '': 0, '#': 1, b: -1, '##': 2, bb: -2 }; const AOF: Record<number, string> = { 0: '', 1: '#', [-1]: 'b', 2: '##', [-2]: 'bb' };
const mod = (n: number) => ((n % 12) + 12) % 12;
const CH: Record<string, [number, number][]> = { // [letterSteps, semitones]
  major: [[0, 0], [2, 4], [4, 7]], minor: [[0, 0], [2, 3], [4, 7]], diminished: [[0, 0], [2, 3], [4, 6]], augmented: [[0, 0], [2, 4], [4, 8]],
  dominant7: [[0, 0], [2, 4], [4, 7], [6, 10]], minor7: [[0, 0], [2, 3], [4, 7], [6, 10]], major7: [[0, 0], [2, 4], [4, 7], [6, 11]],
  half_diminished7: [[0, 0], [2, 3], [4, 6], [6, 10]], diminished7: [[0, 0], [2, 3], [4, 6], [6, 9]],
};
const UI_KEYS = ['C', 'C#', 'D', 'Eb', 'E', 'F', 'F#', 'G', 'Ab', 'A', 'Bb', 'B'];
const ROOTS = ['C', 'Db', 'D', 'Eb', 'E', 'F', 'F#', 'G', 'Ab', 'A', 'Bb', 'B']; // CHORD_ROOT_OPTIONS (lines 36-49)
let total = 0, bad = 0, strong = 0, rootWrong = 0; const ex: string[] = [];
for (const k of UI_KEYS) {
  const scale = S.buildScale({ natural: k[0], accidental: k.slice(1) }, 'major');
  const isFlatKey = scale.notes.some((n: any) => n.accidental.includes('b'));
  for (const r of ROOTS) for (const [q, tones] of Object.entries(CH)) {
    total++;
    const rpc = LPC[r[0]] + ACC[r.slice(1)];
    const shown = tones.map(([, st]) => { const pc = mod(rpc + st); const inS = scale.notes.find((n: any) => getPitchClass(n) === pc); return inS ? inS.natural + inS.accidental : (isFlatKey ? FLAT : SHARP)[pc]; });
    const exp = tones.map(([ls, st]) => { const L = LET[(LET.indexOf(r[0]) + ls) % 7]; const d = mod(rpc + st - LPC[L] + 6) - 6; return Math.abs(d) <= 2 ? L + AOF[d] : '?'; });
    const simple = (x: string) => x.length <= 2 && !['Fb', 'Cb', 'E#', 'B#'].includes(x) && !x.endsWith('bb') && !x.endsWith('##');
    if (shown.some((s, i) => simple(exp[i]) && s !== exp[i])) strong++;
    if (shown[0] !== r) rootWrong++;
    if (shown.some((s, i) => exp[i] !== '?' && s !== exp[i])) { bad++; if (ex.length < 14 || (k === 'C' && r === 'C')) ex.push(`key ${k} major, ${r} ${q}: shows ${shown.join('–')}  expected ${exp.join('–')}`); }
  }
}
console.log(`chord spellings shown in builder "Notes" row: ${bad}/${total} mis-spelled (12 keys x 12 roots x ${Object.keys(CH).length} qualities)`);
console.log(`  of which ${strong} mis-spell a tone whose correct spelling is a plain note or single sharp/flat (excl. Fb/Cb/E#/B#/doubles); ${rootWrong} show the chosen ROOT under a different name`);
ex.forEach((x) => console.log('  ' + x));
