// Explore reference-content oracle checks.
// Expectations are computed from first-principles spelled formulas written here;
// app functions/constants are only ever the "actual".
// Usage: cd /Users/nunosantos/Documents/Base/Music/new_music_app && npx tsx <this> [--plant]
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const S = await import(R + '/core/constants/scales.ts');
const C = await import(R + '/core/constants/chords.ts');
const CSR = await import(R + '/core/constants/chordScaleRelationships.ts');
const N = await import(R + '/core/constants/notes.ts');
const PLANT = process.argv.includes('--plant');

// ---------------- oracle primitives ----------------
const LETTERS = ['C', 'D', 'E', 'F', 'G', 'A', 'B'];
const LET_PC: Record<string, number> = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };
const ACC: Record<string, number> = { '': 0, '#': 1, b: -1, '##': 2, bb: -2 };
const ACC_OF: Record<number, string> = { 0: '', 1: '#', [-1]: 'b', 2: '##', [-2]: 'bb' };
const MAJ = [0, 2, 4, 5, 7, 9, 11]; // major-scale semitones for degrees 1..7
const mod = (n: number, m = 12) => ((n % m) + m) % m;
// degree token like 'b3', '#11', 'bb7', '1' -> {deg, semis}
function tok(t: string) {
  const m = t.match(/^(bb|b|##|#)?(\d+)$/)!;
  const acc = m[1] ?? '';
  const deg = parseInt(m[2], 10);
  const base = MAJ[(deg - 1) % 7] + 12 * Math.floor((deg - 1) / 7);
  return { deg, semis: base + ACC[acc], acc };
}
const semisOf = (f: string) => f.split(' ').map((t) => tok(t).semis);
// expected spelled note for root + token
function spell(rootL: string, rootA: string, t: string) {
  const { deg, semis } = tok(t);
  const letter = LETTERS[(LETTERS.indexOf(rootL) + deg - 1) % 7];
  const pc = mod(LET_PC[rootL] + ACC[rootA] + semis);
  const diff = mod(pc - LET_PC[letter] + 6) - 6; // -6..5
  return { letter, acc: ACC_OF[diff], pc, ok: Math.abs(diff) <= 2 };
}
const nstr = (n: any) => n.natural + n.accidental;

const issues: Record<string, string[]> = {};
const add = (k: string, s: string) => (issues[k] ??= []).push(s);

// ---------------- 1. scale formulas (textbook spelled formulas) ----------------
// alternatives separated by '|': first is the reference spelling; any listed spelling accepted for letters.
const SCALE_SPELL: Record<string, string> = {
  major: '1 2 3 4 5 6 7', natural_minor: '1 2 b3 4 5 b6 b7', harmonic_minor: '1 2 b3 4 5 b6 7',
  melodic_minor: '1 2 b3 4 5 6 7', dorian: '1 2 b3 4 5 6 b7', phrygian: '1 b2 b3 4 5 b6 b7',
  lydian: '1 2 3 #4 5 6 7', mixolydian: '1 2 3 4 5 6 b7', locrian: '1 b2 b3 4 b5 b6 b7',
  pentatonic_major: '1 2 3 5 6', pentatonic_minor: '1 b3 4 5 b7', blues: '1 b3 4 b5|#4 5 b7',
  whole_tone: '1 2 3 #4 #5 b7|#6', diminished_whole_half: '1 2 b3 4 b5 b6|#5 6|bb7 7',
  diminished_half_whole: '1 b2 b3|#2 3 #4 5 6 b7', chromatic: '1 #1 2 #2 3 4 #4 5 #5 6 #6 7',
  altered: '1 b2 b3 b4 b5 b6 b7', lydian_dominant: '1 2 3 #4 5 6 b7', phrygian_dominant: '1 b2 3 4 5 b6 b7',
  major_blues: '1 2 b3 3 5 6', locrian_natural2: '1 2 b3 4 b5 b6 b7',
  bebop_dominant: '1 2 3 4 5 6 b7 7', bebop_major: '1 2 3 4 5 #5|b6 6 7', bebop_dorian: '1 2 b3 3 4 5 6 b7',
  dorian_b2: '1 b2 b3 4 5 6 b7', lydian_augmented: '1 2 3 #4 #5 6 7', mixolydian_b6: '1 2 3 4 5 b6 b7',
  hungarian_minor: '1 2 b3 #4 5 b6 7', hungarian_major: '1 #2 3 #4 5 6 b7', double_harmonic: '1 b2 3 4 5 b6 7',
  persian: '1 b2 3 4 b5 b6 7', neapolitan_minor: '1 b2 b3 4 5 b6 7', neapolitan_major: '1 b2 b3 4 5 6 7',
  hirajoshi: '1 2 b3 5 b6', in_sen: '1 b2 4 5 b7', iwato: '1 b2 4 b5 b7', egyptian: '1 2 4 5 b7',
};
const scaleRefSemis = (k: string) => SCALE_SPELL[k].split(' ').map((t) => tok(t.split('|')[0]).semis);
let pScale = { ...S.SCALE_FORMULAS };
if (PLANT) pScale = { ...pScale, lydian: [0, 2, 4, 5, 7, 9, 11] }; // planted: lydian with natural 4
for (const [k, f] of Object.entries(pScale) as [string, number[]][]) {
  if (!SCALE_SPELL[k]) { add('scaleFormula', `${k}: no oracle`); continue; }
  const exp = scaleRefSemis(k);
  if (JSON.stringify(exp) !== JSON.stringify(f)) add('scaleFormula', `${k}: app [${f}] vs oracle [${exp}]`);
}
for (const k of Object.keys(SCALE_SPELL)) if (!(k in S.SCALE_FORMULAS)) add('scaleFormula', `oracle scale ${k} missing in app`);

// ---------------- 2. mode-of claims ----------------
const rot = (set: number[], deg: number) => { const r = set[deg - 1]; return set.map((_, i) => mod(set[(i + deg - 1) % 7] - r)); };
const MEL = semisOf('1 2 b3 4 5 6 7'), HARM = semisOf('1 2 b3 4 5 b6 7'), MAJS = semisOf('1 2 3 4 5 6 7');
const claims: [string, string, number[], number][] = [
  // [where, scale, parent, mode#]
  ['scales.ts:28 altered = mode 7 of melodic minor', 'altered', MEL, 7],
  ['scales.ts:29 lydian_dominant = mode 4 of melodic minor', 'lydian_dominant', MEL, 4],
  ['scales.ts:30 phrygian_dominant = mode 5 of harmonic minor', 'phrygian_dominant', HARM, 5],
  ['scales.ts:32 locrian_natural2 = mode 6 of melodic minor', 'locrian_natural2', MEL, 6],
  ['scales.ts:38 dorian_b2 = mode 2 of melodic minor', 'dorian_b2', MEL, 2],
  ['scales.ts:39 lydian_augmented = mode 3 of melodic minor', 'lydian_augmented', MEL, 3],
  ['scales.ts:40 mixolydian_b6 = mode 5 of melodic minor', 'mixolydian_b6', MEL, 5],
  ['dorian = mode 2 of major', 'dorian', MAJS, 2], ['phrygian = mode 3 of major', 'phrygian', MAJS, 3],
  ['lydian = mode 4 of major', 'lydian', MAJS, 4], ['mixolydian = mode 5 of major', 'mixolydian', MAJS, 5],
  ['natural_minor = mode 6 of major', 'natural_minor', MAJS, 6], ['locrian = mode 7 of major', 'locrian', MAJS, 7],
];
if (PLANT) claims.push(['PLANT phrygian_dominant = mode 5 of melodic minor', 'phrygian_dominant', MEL, 5]);
const modeResults: string[] = [];
for (const [where, sc, parent, n] of claims) {
  const ok = JSON.stringify(rot(parent, n)) === JSON.stringify((S.SCALE_FORMULAS as any)[sc]);
  modeResults.push(`${ok ? 'OK ' : 'BAD'} ${where}`);
  if (!ok) add('modeClaims', where);
}
// KeySelector "Mel. Minor Modes" group membership (src/components/navigation/KeySelector.tsx:66-77)
const melGroup = ['altered', 'lydian_dominant', 'phrygian_dominant', 'locrian_natural2', 'dorian_b2', 'lydian_augmented', 'mixolydian_b6'];
for (const sc of melGroup) {
  const f = JSON.stringify((S.SCALE_FORMULAS as any)[sc]);
  const isMelMode = [1, 2, 3, 4, 5, 6, 7].some((n) => JSON.stringify(rot(MEL, n)) === f);
  if (!isMelMode) {
    const harmN = [1, 2, 3, 4, 5, 6, 7].find((n) => JSON.stringify(rot(HARM, n)) === f);
    add('keySelectorGroup', `${sc} listed under "Mel. Minor Modes" but is not a mode of melodic minor${harmN ? ` (it is mode ${harmN} of harmonic minor)` : ''}`);
  }
}

// ---------------- 3. scale spelling across roots ----------------
const UI_ROOTS = ['C', 'C#', 'D', 'Eb', 'E', 'F', 'F#', 'G', 'Ab', 'A', 'Bb', 'B']; // KeySelector.tsx:8-21
const ALL_ROOTS = LETTERS.flatMap((l) => ['', '#', 'b'].map((a) => l + a));
const spellIssues: Record<string, Set<string>> = {};
let spellChecks = 0;
for (const sc of Object.keys(S.SCALE_FORMULAS)) {
  if (!SCALE_SPELL[sc]) continue;
  for (const r of ALL_ROOTS) {
    const rootL = r[0], rootA = r.slice(1);
    const notes = S.buildScale({ natural: rootL, accidental: rootA }, sc).notes;
    const toks = SCALE_SPELL[sc].split(' ');
    notes.forEach((n: any, i: number) => {
      spellChecks++;
      const alts = toks[i].split('|').map((t) => spell(rootL, rootA, t));
      const okAlts = alts.filter((a) => a.ok);
      const pcOK = mod(LET_PC[n.natural] + ACC[n.accidental]) === alts[0].pc;
      if (!pcOK) { add('scaleSpelling', `${r} ${sc} deg${i + 1}: WRONG PITCH ${nstr(n)}`); return; }
      if (okAlts.length === 0) return; // no in-range letter spelling exists; any enharmonic acceptable
      if (!okAlts.some((a) => a.letter === n.natural && a.acc === n.accidental)) {
        (spellIssues[sc] ??= new Set()).add(`${r}${UI_ROOTS.includes(r) ? '*' : ''}: deg${i + 1} ${nstr(n)} (expected ${okAlts.map((a) => a.letter + a.acc).join(' or ')})`);
      }
    });
  }
}

// ---------------- 4. chord formulas + spelling + short labels ----------------
const CHORD_SPELL: Record<string, string> = {
  major: '1 3 5', minor: '1 b3 5', diminished: '1 b3 b5', augmented: '1 3 #5', major6: '1 3 5 6', minor6: '1 b3 5 6',
  major7: '1 3 5 7', minor7: '1 b3 5 b7', dominant7: '1 3 5 b7', diminished7: '1 b3 b5 bb7', half_diminished7: '1 b3 b5 b7',
  augmented7: '1 3 #5 b7', sus2: '1 2 5', sus4: '1 4 5', add9: '1 3 5 9', minor_major7: '1 b3 5 7', power: '1 5',
  dominant7sus4: '1 4 5 b7', major9: '1 3 5 7 9', minor9: '1 b3 5 b7 9', dominant9: '1 3 5 b7 9',
  dominant7flat9: '1 3 5 b7 b9', dominant7sharp9: '1 3 5 b7 #9', dominant7flat5: '1 3 b5 b7', dominant7sharp5: '1 3 #5 b7',
  dominant7alt: '1 3 b7 b9 #9 #11 b13', dominant11: '1 5 b7 9 11', major11: '1 5 7 9 11', minor11: '1 b3 5 b7 9 11',
  dominant9sharp11: '1 3 5 b7 9 #11', dominant7sharp11: '1 3 5 b7 #11', major9sharp11: '1 3 5 7 9 #11',
  dominant13: '1 3 5 b7 9 13', major13: '1 3 5 7 9 13', minor13: '1 b3 5 b7 9 13', dominant13flat9: '1 3 5 b7 b9 13',
  dominant7flat13: '1 3 5 b7 b13', add11: '1 3 5 11', six_nine: '1 3 5 6 9', minor_six_nine: '1 b3 5 6 9',
  dominant9sus4: '1 4 5 b7 9', sus2sus4: '1 2 4 5', augmented_major7: '1 3 #5 7', major7flat5: '1 3 b5 7',
  diminished_major7: '1 b3 b5 7', major7sharp11: '1 3 5 7 #11', dominant7sharp5flat9: '1 3 #5 b7 b9',
  dominant7flat5flat9: '1 3 b5 b7 b9', dominant7sharp5sharp9: '1 3 #5 b7 #9', dominant7flat5sharp9: '1 3 b5 b7 #9',
};
let pChord = { ...C.CHORD_FORMULAS };
if (PLANT) pChord = { ...pChord, minor7: [0, 3, 7, 11] };
for (const [q, f] of Object.entries(pChord) as [string, number[]][]) {
  if (!CHORD_SPELL[q]) { add('chordFormula', `${q}: no oracle`); continue; }
  const exp = semisOf(CHORD_SPELL[q]);
  if (JSON.stringify(exp) !== JSON.stringify(f)) add('chordFormula', `${q}: app [${f}] vs oracle [${exp}]`);
}
const chordSpellIssues: Record<string, Set<string>> = {};
let chordSpellChecks = 0;
for (const q of Object.keys(C.CHORD_FORMULAS)) {
  const toks = CHORD_SPELL[q].split(' ');
  for (const r of ALL_ROOTS) {
    const notes = C.buildChord({ natural: r[0], accidental: r.slice(1) }, q).notes;
    notes.forEach((n: any, i: number) => {
      chordSpellChecks++;
      const e = spell(r[0], r.slice(1), toks[i]);
      if (mod(LET_PC[n.natural] + ACC[n.accidental]) !== e.pc) { add('chordSpelling', `${r}${q} tone ${toks[i]}: WRONG PITCH ${nstr(n)}`); return; }
      if (e.ok && (e.letter !== n.natural || e.acc !== n.accidental)) (chordSpellIssues[q] ??= new Set()).add(`${r}: ${toks[i]}=${nstr(n)} (expected ${e.letter + e.acc})`);
    });
  }
}
// short interval labels shown as "Formula" in CurrentChordPanel (CurrentChordPanel.tsx:89, 246-254)
const labelIssues: string[] = [];
const labelStyle = new Set<string>();
for (const q of Object.keys(C.CHORD_FORMULAS)) {
  const labels: string[] = C.getChordShortIntervalLabels(q);
  const toks = CHORD_SPELL[q].split(' ');
  labels.forEach((lab, i) => {
    const expTok = toks[i];
    const expNum = tok(expTok).deg === 1 ? 'R' : String(tok(expTok).deg);
    const labNum = lab === 'R' ? 'R' : (lab.match(/\d+/)?.[0] ?? '?');
    if (labNum !== expNum) labelIssues.push(`${q}: chord tone ${expTok} shown as "${lab}" (degree number wrong)`);
    else {
      const norm = lab.replace(/^m(\d)/, 'b$1').replace(/^M(\d)/, '$1');
      if (norm !== expTok && !(expTok === '1' && lab === 'R')) labelIssues.push(`${q}: chord tone ${expTok} shown as "${lab}"`);
      if (/^m\d/.test(lab)) labelStyle.add(`${q}:${lab}`);
    }
  });
}

// ---------------- 5. interval label tables ----------------
const SIMPLE = ['Unison', 'Minor 2nd', 'Major 2nd', 'Minor 3rd', 'Major 3rd', 'Perfect 4th', 'Tritone', 'Perfect 5th', 'Minor 6th', 'Major 6th', 'Minor 7th', 'Major 7th', 'Octave'];
// compound: n>12 -> number+7 with same quality (major 3rd + octave = major 10th)
const ord = (n: number) => n + (n === 1 ? 'st' : n === 2 ? 'nd' : n === 3 ? 'rd' : 'th');
function intervalOracleNames(st: number): string[] {
  if (st <= 12) return st === 0 ? ['Root', 'Unison'] : st === 6 ? ['Tritone', 'Augmented 4th', 'Diminished 5th'] : [SIMPLE[st]];
  const s = st - 12;
  const qual = ['Perfect', 'Minor', 'Major', 'Minor', 'Major', 'Perfect', '', 'Perfect', 'Minor', 'Major', 'Minor', 'Major'][s];
  const num = [1, 2, 2, 3, 3, 4, 4, 5, 6, 6, 7, 7][s] + 7;
  const names = [`${qual} ${ord(num)}`];
  if (s === 3) names.push('Augmented 9th'); // #9 == m10 enharmonic
  if (s === 6) names.push('Augmented 11th', 'Diminished 12th');
  if (s === 8) names.push('Augmented 12th');
  if (s === 10) names.push('Augmented 13th');
  return names;
}
const ivIssues: string[] = [];
const IL = PLANT ? { ...C.INTERVAL_LABELS, 9: 'Minor 6th' } : C.INTERVAL_LABELS;
for (const [st, name] of Object.entries(IL) as [string, string][]) {
  const ok = intervalOracleNames(+st);
  if (!ok.includes(name)) ivIssues.push(`INTERVAL_LABELS[${st}] = "${name}" — expected one of ${ok.join(' / ')}`);
}
for (const [st, short] of Object.entries(C.INTERVAL_SHORT_LABELS) as [string, string][]) {
  const s = +st;
  const exp = intervalOracleNames(s)[0];
  const q = exp.startsWith('Minor') ? 'minor' : exp.startsWith('Major') ? 'major' : 'other';
  if (short.startsWith('m') && q !== 'minor') ivIssues.push(`INTERVAL_SHORT_LABELS[${st}] = "${short}" but ${s} semitones = ${exp}`);
}
// PITCH_CLASS_SPELLINGS self-consistency
const pcsIssues: string[] = [];
(N.PITCH_CLASS_SPELLINGS as any[][]).forEach((sp, pc) => sp.forEach((n) => { if (mod(LET_PC[n.natural] + ACC[n.accidental]) !== pc) pcsIssues.push(`pc ${pc}: ${nstr(n)}`); }));

// ---------------- 6. diatonic chords per scale (Explore ChordGrid / ScaleDegreeBar) ----------------
const TRIAD_Q: Record<string, string> = { '4,7': 'major', '3,7': 'minor', '3,6': 'diminished', '4,8': 'augmented' };
const diaIssues: Record<string, string[]> = {};
const diaCrash: string[] = [];
const numeralIssues: string[] = [];
for (const sc of Object.keys(S.SCALE_FORMULAS)) {
  for (const r of UI_ROOTS) {
    const scale = S.buildScale({ natural: r[0], accidental: r.slice(1) }, sc);
    const scalePcs = new Set(scale.notes.map((n: any) => mod(LET_PC[n.natural] + ACC[n.accidental])));
    let dia: any[];
    try { dia = C.getDiatonicChordsForScale(scale); } catch (e: any) { diaCrash.push(`${r} ${sc}: THROWS ${e.constructor.name}: ${e.message}`); continue; }
    const f = (S.SCALE_FORMULAS as any)[sc] as number[];
    dia.forEach((d: any, i: number) => {
      if (d.numeral === undefined || /undefined/.test(String(d.numeral))) numeralIssues.push(`${r} ${sc} degree ${i + 1}: numeral "${d.numeral}"`);
      const tones = d.chord.notes.map((n: any) => mod(LET_PC[n.natural] + ACC[n.accidental]));
      const outside = d.chord.notes.filter((_: any, j: number) => !scalePcs.has(tones[j])).map(nstr);
      let expQ = '';
      if (f.length === 7) {
        const a = f[i], b = f[(i + 2) % 7], c = f[(i + 4) % 7];
        expQ = TRIAD_Q[`${mod(b - a)},${mod(c - a)}`] ?? `non-tertian(${mod(b - a)},${mod(c - a)})`;
      }
      if (r === 'C' && (outside.length || (expQ && expQ !== d.chord.quality))) {
        (diaIssues[sc] ??= []).push(`deg${i + 1} ${d.numeral} = ${nstr(d.chord.root)} ${d.chord.quality} [${d.chord.notes.map(nstr).join(' ')}]${outside.length ? ` — NOT IN SCALE: ${outside.join(',')}` : ''}${expQ && expQ !== d.chord.quality ? ` — stacked-thirds triad is ${expQ}` : ''}`);
      }
    });
  }
}

// ---------------- 7. chord-scale map: chord tones contained in suggested scale? ----------------
const csIssues: string[] = [];
const MAP = PLANT ? { ...CSR.CHORD_SCALE_MAP, minor7: [...CSR.CHORD_SCALE_MAP.minor7, { scale: 'major', fit: 'primary' }] } : CSR.CHORD_SCALE_MAP;
let csCount = 0;
for (const [q, sugg] of Object.entries(MAP) as [string, any[]][]) {
  const cp = semisOf(CHORD_SPELL[q]).map((x) => mod(x));
  for (const s of sugg) {
    csCount++;
    const sp = new Set(scaleRefSemis(s.scale).map((x) => mod(x)));
    const toks = CHORD_SPELL[q].split(' ');
    const missing = toks.filter((_, i) => !sp.has(cp[i]));
    if (missing.length) csIssues.push(`${q} → ${s.scale} [${s.fit}] missing chord tone(s) ${missing.join(',')}  ctx: "${s.context ?? ''}"`);
  }
}
// seventh-chord table (DIATONIC_SEVENTH_CHORD_QUALITIES)
const SEV_Q: Record<string, string> = { '4,7,11': 'major7', '3,7,10': 'minor7', '4,7,10': 'dominant7', '3,6,10': 'half_diminished7', '3,6,9': 'diminished7', '3,7,11': 'minor_major7', '4,8,11': 'augmented_major7' };
const sevIssues: string[] = [];
for (const [sc, qs] of Object.entries(C.DIATONIC_SEVENTH_CHORD_QUALITIES) as [string, string[]][]) {
  const f = (S.SCALE_FORMULAS as any)[sc];
  qs.forEach((q, i) => {
    const k = `${mod(f[(i + 2) % 7] - f[i])},${mod(f[(i + 4) % 7] - f[i])},${mod(f[(i + 6) % 7] - f[i])}`;
    if (SEV_Q[k] !== q) sevIssues.push(`${sc} deg${i + 1}: app ${q}, oracle ${SEV_Q[k] ?? k}`);
  });
}
// relative minor/major
const relIssues: string[] = [];
for (const r of ['C', 'G', 'D', 'A', 'E', 'B', 'F#', 'C#', 'F', 'Bb', 'Eb', 'Ab', 'Db', 'Gb', 'Cb']) {
  const e = spell(r[0], r.slice(1), '6');
  const got = S.getRelativeMinor({ natural: r[0], accidental: r.slice(1) });
  if (got.natural !== e.letter || got.accidental !== e.acc) relIssues.push(`relative minor of ${r}: app ${nstr(got)} expected ${e.letter + e.acc}`);
  const back = S.getRelativeMajor(got);
  if (nstr(back) !== r) relIssues.push(`relative major of ${nstr(got)}: app ${nstr(back)} expected ${r}`);
}

// ---------------- 8. ScaleDegreeBar interval label vs displayed note letter ----------------
const barIssues: Record<string, Set<string>> = {};
for (const sc of Object.keys(S.SCALE_FORMULAS)) {
  const f = (S.SCALE_FORMULAS as any)[sc] as number[];
  for (const r of UI_ROOTS) {
    const notes = S.buildScale({ natural: r[0], accidental: r.slice(1) }, sc).notes;
    notes.forEach((n: any, i: number) => {
      const lab: string = S.getScaleDegreeIntervalLabel(i, f[i], notes.length);
      if (lab === 'R') return;
      const num = parseInt(lab.match(/\d+/)![0], 10);
      const impliedLetter = LETTERS[(LETTERS.indexOf(r[0]) + num - 1) % 7];
      if (impliedLetter !== n.natural) (barIssues[sc] ??= new Set()).add(`${r}: label "${lab}" over note ${nstr(n)}`);
    });
  }
}
// function names for 7-note scales: degree index 4 with 8 semitones (#5) gets "Dominant"?
const funcIssues: string[] = [];
for (const [sc, f] of Object.entries(S.SCALE_FORMULAS) as [string, number[]][]) {
  if (f.length !== 7) continue;
  f.forEach((st, i) => {
    const key = S.getScaleDegreeFunctionKey(i, st);
    if (i === 4 && st === 8 && key === 'degreeShort.dominant') funcIssues.push(`${sc}: #5 (8 semitones) labelled "Dominant"`);
    if (i === 6 && st !== 10 && st !== 11) funcIssues.push(`${sc}: 7th degree ${st} st labelled ${key}`);
  });
}

// ---------------- output ----------------
const out = (title: string, arr: string[] | undefined) => { console.log(`\n## ${title} (${arr?.length ?? 0})`); for (const x of arr ?? []) console.log('  ' + x); };
console.log(`PLANT=${PLANT}`);
out('scale formulas vs oracle', issues.scaleFormula);
console.log('\n## mode-of claims'); modeResults.forEach((x) => console.log('  ' + x));
out('KeySelector Mel. Minor Modes group', issues.keySelectorGroup);
console.log(`\n## scale spelling (${spellChecks} notes checked over ${Object.keys(S.SCALE_FORMULAS).length} scales x ${ALL_ROOTS.length} roots; * = root offered in KeySelector)`);
out('  wrong pitch', issues.scaleSpelling);
for (const [sc, set] of Object.entries(spellIssues)) { console.log(`  ${sc}: ${set.size} mis-spelled notes`); [...set].slice(0, 8).forEach((x) => console.log('     ' + x)); }
out('chord formulas vs oracle', issues.chordFormula);
console.log(`\n## chord spelling (${chordSpellChecks} tones checked over ${Object.keys(C.CHORD_FORMULAS).length} qualities x ${ALL_ROOTS.length} roots)`);
out('  wrong pitch', issues.chordSpelling);
for (const [q, set] of Object.entries(chordSpellIssues)) { console.log(`  ${q}: ${set.size}`); [...set].slice(0, 6).forEach((x) => console.log('     ' + x)); }
out('chord formula short labels (CurrentChordPanel "Formula")', labelIssues);
console.log(`  labels using m-prefix style: ${[...labelStyle].join(', ')}`);
out('interval label tables', ivIssues);
out('PITCH_CLASS_SPELLINGS', pcsIssues);
out('getDiatonicChordsForScale crashes (UI roots)', diaCrash.filter((x) => x.startsWith('C ')));
console.log(`  total crash (root,scale) pairs: ${diaCrash.length}; scales: ${[...new Set(diaCrash.map((x) => x.split(' ')[1].replace(':', '')))].join(', ')}`);
out('numerals undefined', numeralIssues.filter((x) => x.startsWith('C ')));
console.log('\n## diatonic chords wrong (root C shown; same pattern for all roots)');
for (const [sc, arr] of Object.entries(diaIssues)) { console.log(`  ${sc}:`); arr.forEach((x) => console.log('     ' + x)); }
out(`chord-scale map: chord tones missing from suggested scale (${csCount} suggestions checked)`, csIssues);
out('DIATONIC_SEVENTH_CHORD_QUALITIES', sevIssues);
out('relative major/minor', relIssues);
console.log('\n## ScaleDegreeBar label vs note letter (UI roots)');
for (const [sc, set] of Object.entries(barIssues)) { console.log(`  ${sc}: ${set.size}`); [...set].slice(0, 4).forEach((x) => console.log('     ' + x)); }
out('ScaleDegreeBar function names', funcIssues);
