// Structural + oracle checks over every L6-L9 exercise (authored + generated, EN).
// Oracle = first-principles interval sets written here; app functions are only the "actual".
// Usage: cd <repo> && npx tsx <this> [--plant]
import { readFileSync } from 'node:fs';
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const D = '/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/C-learn-L6-L9-explore';
const { buildChord, getDiatonicTriads } = await import(R + '/core/constants/chords.ts');
const { buildScale } = await import(R + '/core/constants/scales.ts');
const { getPitchClass } = await import(R + '/core/constants/notes.ts');

const PLANT = process.argv.includes('--plant');
let all: any[] = JSON.parse(readFileSync(D + '/all_exercises.json', 'utf8'));

// ---------- independent oracle ----------
const LET: Record<string, number> = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };
const ACC: Record<string, number> = { '': 0, '#': 1, b: -1, '##': 2, bb: -2 };
const pc = (l: string, a = '') => (((LET[l] + ACC[a]) % 12) + 12) % 12;
// absolute midi with correct octave semantics (B#4 = C5, Cb4 = B3)
const midiAbs = (l: string, a: string, oct: number) => 12 * (oct + 1) + LET[l] + ACC[a];
const CH: Record<string, number[]> = {
  major: [0, 4, 7], minor: [0, 3, 7], diminished: [0, 3, 6], augmented: [0, 4, 8],
  dominant7: [0, 4, 7, 10], major7: [0, 4, 7, 11], minor7: [0, 3, 7, 10],
  half_diminished7: [0, 3, 6, 10], diminished7: [0, 3, 6, 9],
  major9: [0, 4, 7, 11, 14], minor9: [0, 3, 7, 10, 14], major6: [0, 4, 7, 9], minor6: [0, 3, 7, 9],
  dominant9: [0, 4, 7, 10, 14], sus2: [0, 2, 7], sus4: [0, 5, 7], minor_major7: [0, 3, 7, 11],
  augmented7: [0, 4, 8, 10], dominant7sus4: [0, 5, 7, 10], add9: [0, 4, 7, 14],
};
const SC: Record<string, number[]> = {
  major: [0, 2, 4, 5, 7, 9, 11], natural_minor: [0, 2, 3, 5, 7, 8, 10], harmonic_minor: [0, 2, 3, 5, 7, 8, 11],
  melodic_minor: [0, 2, 3, 5, 7, 9, 11], dorian: [0, 2, 3, 5, 7, 9, 10], phrygian: [0, 1, 3, 5, 7, 8, 10],
  lydian: [0, 2, 4, 6, 7, 9, 11], mixolydian: [0, 2, 4, 5, 7, 9, 10], locrian: [0, 1, 3, 5, 6, 8, 10],
  whole_tone: [0, 2, 4, 6, 8, 10], pentatonic_major: [0, 2, 4, 7, 9], pentatonic_minor: [0, 3, 5, 7, 10],
  blues: [0, 3, 5, 6, 7, 10], chromatic: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11], altered: [0, 1, 3, 4, 6, 8, 10],
  diminished_half_whole: [0, 1, 3, 4, 6, 7, 9, 10], diminished_whole_half: [0, 2, 3, 5, 6, 8, 9, 11],
};
const setOf = (root: number, ivs: number[]) => new Set(ivs.map((i) => (root + i) % 12));
const eq = (a: Set<number>, b: Set<number>) => a.size === b.size && [...a].every((x) => b.has(x));
const fmt = (s: Set<number>) => [...s].sort((x, y) => x - y).join(',');
// major-key diatonic triads (oracle) keyed by exact numeral
const MAJ_TRIADS: Record<string, [number, number[]]> = {
  I: [0, CH.major], ii: [2, CH.minor], iii: [4, CH.minor], IV: [5, CH.major], V: [7, CH.major], vi: [9, CH.minor], 'vii°': [11, CH.diminished],
};

if (PLANT) {
  // known-bad cases to prove each check can fire
  all = all.concat([
    { id: 'PLANT1', type: 'multiple_choice', prompt: 'x', config: { type: 'multiple_choice', choices: [{ label: 'a', correct: true }, { label: 'a', correct: true }] } },
    { id: 'PLANT2', type: 'chord_build', prompt: 'x', config: { type: 'chord_build', root: 'C', rootAccidental: '', quality: 'major7', noteCount: 3 } },
    { id: 'PLANT3', type: 'ear_training', prompt: 'x', config: { type: 'ear_training', mode: 'progression', root: 'C', rootAccidental: '', progression: ['I', 'V7', 'i'], choices: [{ label: 'I - V7 - i', correct: true }, { label: 'I - V', correct: false }] } },
    { id: 'PLANT4', type: 'ear_training', prompt: 'x', config: { type: 'ear_training', mode: 'interval', root: 'C', rootAccidental: 'b', rootOctave: 4, targetSemitones: 12, direction: 'ascending' } },
    { id: 'PLANT5', type: 'multiple_choice', prompt: 'Which is right? Answer: Neapolitan sixth', config: { type: 'multiple_choice', choices: [{ label: 'Neapolitan sixth', correct: true }, { label: 'b', correct: false }] } },
    { id: 'PLANT6', type: 'ear_training', prompt: 'x', config: { type: 'ear_training', mode: 'chord', chordRoot: 'G', chordRootAccidental: '', quality: 'dominant7', choices: [{ label: 'Major 7', correct: true }, { label: 'Dominant 7', correct: false }] } },
  ]);
}

const issues: string[] = [];
const note = (id: string, msg: string) => issues.push(`${id}: ${msg}`);
const qualityLabelOK = (q: string, label: string) => {
  const n = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, '');
  const map: Record<string, string[]> = {
    major: ['major', 'majortriad'], minor: ['minor', 'minortriad'], diminished: ['diminished', 'diminishedtriad'], augmented: ['augmented', 'augmentedtriad'],
    dominant7: ['dominant7', 'dominant7th', 'dominantseventh'], major7: ['major7', 'major7th', 'majorseventh'], minor7: ['minor7', 'minor7th', 'minorseventh'],
    half_diminished7: ['halfdiminished7', 'halfdiminished', 'halfdiminished7th', 'halfdiminishedseventh', 'minor7b5', 'minor7flat5'],
    diminished7: ['diminished7', 'diminished7th', 'fullydiminished7', 'diminishedseventh', 'fullydiminished7th'], major9: ['major9', 'major9th'], minor9: ['minor9', 'minor9th'],
  };
  return (map[q] ?? [n(q)]).some((m) => n(label) === m || n(label).startsWith(m));
};

let counts: Record<string, number> = {};
for (const e of all) {
  const c = e.config;
  counts[e.type + (c.mode ? ':' + c.mode : '')] = (counts[e.type + (c.mode ? ':' + c.mode : '')] ?? 0) + 1;
  // H. choice integrity
  if (c.choices) {
    const nCorrect = c.choices.filter((x: any) => x.correct).length;
    if (nCorrect !== 1) note(e.id, `choices have ${nCorrect} correct`);
    const labels = c.choices.map((x: any) => x.label.trim().toLowerCase());
    if (new Set(labels).size !== labels.length) note(e.id, `duplicate choice labels: ${labels.join(' | ')}`);
    if (labels.some((l: string) => !l)) note(e.id, 'empty choice label');
    if (c.choices.length < 2) note(e.id, 'fewer than 2 choices');
    // I. leak: correct label (>=8 chars) appears verbatim in prompt
    const corr = c.choices.find((x: any) => x.correct);
    if (corr && corr.label.length >= 8 && e.prompt.toLowerCase().includes(corr.label.toLowerCase())) note(e.id, `LEAK? correct label "${corr.label}" appears verbatim in prompt`);
  }
  // A. chord_build
  if (e.type === 'chord_build') {
    const exp = setOf(pc(c.root, c.rootAccidental), CH[c.quality] ?? []);
    if (!CH[c.quality]) note(e.id, `no oracle for quality ${c.quality}`);
    const act = new Set(buildChord({ natural: c.root, accidental: c.rootAccidental }, c.quality).notes.map((n: any) => getPitchClass(n)));
    if (CH[c.quality] && !eq(exp, act)) note(e.id, `chord ${c.root}${c.rootAccidental} ${c.quality}: app {${fmt(act)}} oracle {${fmt(exp)}}`);
    if (CH[c.quality] && c.noteCount !== exp.size) note(e.id, `chord noteCount ${c.noteCount} != oracle ${exp.size}`);
  }
  // B. scale_build
  if (e.type === 'scale_build') {
    const exp = setOf(pc(c.root, c.rootAccidental), SC[c.scaleType] ?? []);
    if (!SC[c.scaleType]) note(e.id, `no oracle for scale ${c.scaleType}`);
    const act = new Set(buildScale({ natural: c.root, accidental: c.rootAccidental }, c.scaleType).notes.map((n: any) => getPitchClass(n)));
    if (SC[c.scaleType] && !eq(exp, act)) note(e.id, `scale ${c.root}${c.rootAccidental} ${c.scaleType}: app {${fmt(act)}} oracle {${fmt(exp)}}`);
    if (SC[c.scaleType] && c.noteCount !== exp.size) note(e.id, `scale noteCount ${c.noteCount} != oracle ${exp.size}`);
  }
  if (e.type === 'ear_training') {
    if (c.mode === 'chord') {
      const exp = setOf(pc(c.chordRoot, c.chordRootAccidental ?? ''), CH[c.quality] ?? []);
      const notes = buildChord({ natural: c.chordRoot, accidental: c.chordRootAccidental ?? '' }, c.quality).notes;
      const act = new Set(notes.map((n: any) => getPitchClass(n)));
      if (!eq(exp, act)) note(e.id, `EAR chord plays {${fmt(act)}} oracle {${fmt(exp)}}`);
      const corr = c.choices.find((x: any) => x.correct);
      if (!qualityLabelOK(c.quality, corr.label)) note(e.id, `EAR chord quality ${c.quality} but correct label "${corr.label}"`);
      // played voicing: playChord(notes, 4) -> every note at octave 4 -> midi 60+pc
      const midis = notes.map((n: any) => 60 + getPitchClass(n));
      const bassPc = Math.min(...midis) % 12;
      const rootPc = pc(c.chordRoot, c.chordRootAccidental ?? '');
      if (bassPc !== rootPc) note(e.id, `VOICING: ${c.chordRoot}${c.chordRootAccidental ?? ''} ${c.quality} sounds inverted (bass pc ${bassPc}, root pc ${rootPc}); midis ${midis.sort((a: number, b: number) => a - b).join(' ')}`);
    }
    if (c.mode === 'scale') {
      const exp = setOf(pc(c.root, c.rootAccidental ?? ''), SC[c.scaleType] ?? []);
      const act = new Set(buildScale({ natural: c.root, accidental: c.rootAccidental ?? '' }, c.scaleType).notes.map((n: any) => getPitchClass(n)));
      if (!eq(exp, act)) note(e.id, `EAR scale plays {${fmt(act)}} oracle {${fmt(exp)}}`);
    }
    if (c.mode === 'interval') {
      // replicate ExerciseRunner.playEarAudio arithmetic exactly (actual)
      const semis = c.direction === 'descending' ? -c.targetSemitones : c.targetSemitones;
      const rootPCs: Record<string, number> = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };
      let rootPC = rootPCs[c.root] ?? 0;
      if (c.rootAccidental === '#') rootPC += 1;
      if (c.rootAccidental === 'b') rootPC -= 1;
      const targetPC = (((rootPC + semis) % 12) + 12) % 12;
      const oct = c.rootOctave ?? 4;
      const targetOct = oct + (rootPC + semis >= 12 ? 1 : rootPC + semis < 0 ? -1 : 0);
      const rootMidiPlayed = 12 + oct * 12 + getPitchClass({ natural: c.root, accidental: c.rootAccidental ?? '' });
      const targetMidiPlayed = 12 + targetOct * 12 + targetPC;
      const played = targetMidiPlayed - rootMidiPlayed;
      if (played !== semis) note(e.id, `EAR interval: asked ${c.direction} ${c.targetSemitones}, played ${played} (root ${c.root}${c.rootAccidental}${oct})`);
      // oracle: correct absolute midi
      const rootAbs = midiAbs(c.root, c.rootAccidental ?? '', oct);
      if (rootAbs !== rootMidiPlayed) note(e.id, `EAR interval root octave: ${c.root}${c.rootAccidental}${oct} should be midi ${rootAbs}, played ${rootMidiPlayed}`);
    }
    if (c.mode === 'progression') {
      for (const num of c.progression) {
        const found = getDiatonicTriads({ natural: c.root ?? 'C', accidental: c.rootAccidental ?? '' }).find((t: any) => t.numeral.replace('°', '') === num.replace('°', ''));
        if (!found) { note(e.id, `PROGRESSION numeral "${num}" not playable (silently skipped)`); continue; }
        const o = MAJ_TRIADS[num];
        if (!o) { note(e.id, `no oracle for numeral ${num}`); continue; }
        const exp = setOf((pc(c.root ?? 'C', c.rootAccidental ?? '') + o[0]) % 12, o[1]);
        const act = new Set(found.chord.notes.map((n: any) => getPitchClass(n)));
        if (!eq(exp, act)) note(e.id, `PROGRESSION ${num} plays {${fmt(act)}} oracle {${fmt(exp)}}`);
      }
      const corr = c.choices.find((x: any) => x.correct);
      if (corr.label !== c.progression.join(' - ')) note(e.id, `PROGRESSION correct label "${corr.label}" != played ${c.progression.join(' - ')}`);
    }
  }
}
console.log('counts', counts);
console.log('issues', issues.length);
for (const i of issues) console.log(' ', i);
