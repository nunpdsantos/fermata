// Dump curriculum text for a level: node curr_dump.mts <levelNumber>
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const L = process.argv[2];
const mod = await import(`${R}/core/constants/curriculumL${L}.ts`);
const units: any[] = (mod as any)[`L${L}_UNITS`];
const lvl: any = { id: `l${L}`, title: "", description: "", units };
let o = `LEVEL ${lvl.id} ${lvl.title}\n${lvl.description}\n`;
for (const u of lvl.units) {
  o += `\n#### UNIT ${u.id} ${u.title} — ${u.description}\n`;
  for (const m of u.modules) {
    o += `\n=== ${m.id} ${m.title} | ${m.subtitle} | prereq ${m.prerequisites.join(',')}\n`;
    m.objectives.forEach((x: string) => (o += `  OBJ: ${x}\n`));
    m.concepts.forEach((c: any, i: number) => { o += `  C${i} ${c.title}: ${c.explanation}\n     TRY[${c.tryThisLabel}] ${c.tryThisQuery}\n`; if (c.childDescription) o += `     CHILD: ${c.childDescription}\n`; });
    m.tasks.forEach((t: any) => (o += `  TASK ${t.id}: ${t.instruction}${t.query ? ' [q: ' + t.query + ']' : ''}\n`));
  }
  if (u.milestone) o += `  MILESTONE: ${JSON.stringify(u.milestone)}\n`;
  if (u.completionContent) o += `  COMPLETION: ${JSON.stringify(u.completionContent)}\n`;
}
console.log(o);
