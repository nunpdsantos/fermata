# Merge partial findings into one severity-sorted, renumbered list (C-1..C-n).
# Usage: python3 -I merge.py  (run from anywhere; paths are absolute)
import re, pathlib
T = pathlib.Path('/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/C-learn-L6-L9-explore')
SOURCES = [('partial_L6L8.md', 'L6/L8'), ('partial_L7.md', 'L7'), ('partial_L9_engine.md', 'L9+engine'), ('partial_explore.md', 'Explore')]
blocks = []
for fname, area in SOURCES:
    p = T / fname
    if not p.exists():
        print('MISSING', fname); continue
    text = p.read_text()
    # findings section only: from first '### ' to the first '## ' heading that follows findings
    m = re.search(r'^### ', text, re.M)
    if not m: print('NO FINDINGS in', fname); continue
    rest = text[m.start():]
    end = re.search(r'^## ', rest, re.M)
    body = rest[: end.start()] if end else rest
    for blk in re.split(r'(?=^### )', body, flags=re.M):
        if not blk.strip(): continue
        h = re.match(r'### ([A-Z0-9]+-\d+):\s*(.*)', blk)
        sev = re.search(r'- Severity:\s*(S[123])', blk)
        if not h or not sev:
            print('UNPARSED block in', fname, blk[:80]); continue
        blocks.append({'orig': h.group(1), 'title': h.group(2).strip(), 'sev': sev.group(1), 'area': area,
                       'body': blk[h.end():].rstrip() + '\n'})
order = {'S1': 0, 'S2': 1, 'S3': 2}
area_order = {a: i for i, (_, a) in enumerate(SOURCES)}
blocks.sort(key=lambda b: (order[b['sev']], area_order[b['area']]))
out = []
for i, b in enumerate(blocks, 1):
    b['id'] = f'C-{i}'
    out.append(f"### C-{i}: {b['title']}  _(area: {b['area']}; working id {b['orig']})_{b['body']}\n")
(T / 'findings_body.md').write_text(''.join(out))
from collections import Counter
print('total', len(blocks), Counter(b['sev'] for b in blocks), Counter((b['area'], b['sev']) for b in blocks))
(T / 'id_map.txt').write_text('\n'.join(f"{b['id']}\t{b['orig']}\t{b['sev']}\t{b['area']}\t{b['title']}" for b in blocks) + '\n')

# ---------------- assemble findings.md (the brief's required deliverable) ----------------
def section(fname, name):
    p = T / fname
    if not p.exists(): return ''
    t = p.read_text()
    m = re.search(rf'^## {name}[^\n]*\n', t, re.M)
    if not m: return ''
    rest = t[m.end():]
    e = re.search(r'^## ', rest, re.M)
    return (rest[: e.start()] if e else rest).strip() + '\n'

HEADER = """# Track C — Learn Levels 6–9 + Explore reference content (English source)

Auditor: track C (Claude Opus 5.5). Work split: the parent did L9, the exercise rendering/grading/audio engine, the structural checks and the merge review. Three forks of the same model did the close reading: L6+L8, L7, and Explore reference content. Every fork finding was read in full by the parent. The S1 items were re-checked against source: L6-1/2/3/4, L8-1, L7-1/2/3, L7-13/14 confirmed. For L6-3 a caveat was added.
Repo state audited: working tree at /Users/nunosantos/Documents/Base/Music/new_music_app on 2026-10-30 (no .git, so no commit hash).

`<T>` = `/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/C-learn-L6-L9-explore` (partials also write it as `<track>`). Run `.mts` scripts as `cd /Users/nunosantos/Documents/Base/Music/new_music_app && npx tsx <path>` and `.py` scripts as `python3 -I <path>`. Per-area scripts live in `<T>/L6L8/`, `<T>/L7/` and `<T>/explore/`; parent scripts are at `<T>/` root. The working id in each title (L6-n, L7-n, L8-n, E-n, EX-n) matches the per-area partial file `<T>/partial_*.md`.

Findings are ordered S1 → S2 → S3, then by area (L6/L8, L7, L9+engine, Explore).

"""
cnt = Counter(b['sev'] for b in blocks)
summary = f"**Counts:** {len(blocks)} findings — S1: {cnt['S1']}, S2: {cnt['S2']}, S3: {cnt['S3']}.\n\n"
doc = HEADER + summary + '## Findings\n\n' + ''.join(out)
tail = (T / 'tail_sections.md').read_text() if (T / 'tail_sections.md').exists() else ''
ex_impr = section('partial_explore.md', 'Improvements')
ex_unc = section('partial_explore.md', 'Unconfirmed')
# splice Explore improvements/unconfirmed into the parent's tail sections
if ex_impr:
    tail = tail.replace('## Unconfirmed suspicions', '**Explore (fork, reviewed by parent):**\n' + ex_impr + '\n## Unconfirmed suspicions')
if ex_unc:
    tail = tail.rstrip() + '\n- **Explore (fork):**\n' + '\n'.join('  ' + l for l in ex_unc.splitlines()) + '\n'
doc += tail + '\n## Coverage\n\n' + (T / 'coverage_parent.txt').read_text()
for fname, label in [('partial_L6L8.md', 'L6 + L8 (fork)'), ('partial_L7.md', 'L7 (fork)'), ('partial_explore.md', 'Explore (fork)')]:
    s = section(fname, 'Coverage')
    if s: doc += f'\n### {label}\n' + s
(T / 'findings.md').write_text(doc)
print('wrote findings.md', len(doc), 'chars')
