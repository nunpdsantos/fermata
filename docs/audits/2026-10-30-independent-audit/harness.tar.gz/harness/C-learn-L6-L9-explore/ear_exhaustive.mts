// Exhaustive L9 ear-training stimulus audit over the FULL template parameter space
// (every root x quality/scale/interval/direction/octave/progression a template can emit)
// plus every authored ear exercise. Replicates ExerciseRunner.playEarAudio + core
// playNote/playChord/playScale octave arithmetic as "actual"; oracle is first-principles.
// Usage: cd <repo> && npx tsx <this> [--plant]
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const { buildChord, getDiatonicTriads } = await import(R + '/core/constants/chords.ts');
const { buildScale } = await import(R + '/core/constants/scales.ts');
const { getPitchClass } = await import(R + '/core/constants/notes.ts');
const { generateNoteChoices, generateIntervalChoices } = await import(R + '/components/learn/exercises/exerciseHelpers.ts');
const tpls = (await import(R + '/data/exercises/templatesL9.ts')).default;
const authored = (await import(R + '/data/exercises/exercisesL9.ts')).default;
const PLANT = process.argv.includes('--plant');

const LET: Record<string, number> = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };
const ACC: Record<string, number> = { '': 0, '#': 1, b: -1, '##': 2, bb: -2 };
const midiAbs = (l: string, a: string, o: number) => 12 * (o + 1) + LET[l] + ACC[a];
const playedMidi = (l: string, a: string, o: number) => 12 + o * 12 + getPitchClass({ natural: l, accidental: a }); // core playNote
const CH: Record<string, number[]> = { major: [0, 4, 7], minor: [0, 3, 7], diminished: [0, 3, 6], augmented: [0, 4, 8], dominant7: [0, 4, 7, 10], major7: [0, 4, 7, 11], minor7: [0, 3, 7, 10], half_diminished7: [0, 3, 6, 10], diminished7: [0, 3, 6, 9] };
// catalogue used to name what a voicing "sounds like" when heard from its bass upward
const CAT: Record<string, number[]> = { ...CH, 'major6 (6)': [0, 4, 7, 9], 'minor6 (m6)': [0, 3, 7, 9] };
const SC: Record<string, number[]> = { major: [0, 2, 4, 5, 7, 9, 11], natural_minor: [0, 2, 3, 5, 7, 8, 10], harmonic_minor: [0, 2, 3, 5, 7, 8, 11], dorian: [0, 2, 3, 5, 7, 9, 10], phrygian: [0, 1, 3, 5, 7, 8, 10], lydian: [0, 2, 4, 6, 7, 9, 11], mixolydian: [0, 2, 4, 5, 7, 9, 10], pentatonic_major: [0, 2, 4, 7, 9], pentatonic_minor: [0, 3, 5, 7, 10], blues: [0, 3, 5, 6, 7, 10], whole_tone: [0, 2, 4, 6, 8, 10] };
const NAMES = ['C', 'C#', 'D', 'Eb', 'E', 'F', 'F#', 'G', 'Ab', 'A', 'Bb', 'B'];
const nm = (m: number) => NAMES[m % 12] + (Math.floor(m / 12) - 1);

type Item = { src: string; cfg: any };
const items: Item[] = [];
for (const [mid, list] of Object.entries(authored) as any) for (const e of list) if (e.type === 'ear_training') items.push({ src: e.id, cfg: e.config });
for (const t of tpls) for (const [ti, tp] of t.templates.entries()) {
  if (tp.type !== 'ear_training') continue;
  const p = tp.params; const roots = p.roots ?? ['C', 'D', 'E', 'F', 'G', 'A', 'B']; const accs = p.accidentals ?? roots.map(() => '');
  const octs = p.octaves ?? [4];
  roots.forEach((r: string, i: number) => {
    const a = accs[i] ?? '';
    const src = `${t.moduleId}/tpl${ti}`;
    if (p.earMode === 'note') for (const o of octs) items.push({ src, cfg: { mode: 'note', note: r, accidental: a, octave: o, _prompt: tp.promptTemplate } });
    if (p.earMode === 'interval') for (const o of octs) for (const s of p.intervals ?? [3, 4, 5, 7]) for (const d of p.directions ?? ['ascending']) items.push({ src, cfg: { mode: 'interval', root: r, rootAccidental: a, rootOctave: o, targetSemitones: s, direction: d, harmonic: p.harmonic } });
    if (p.earMode === 'chord') for (const q of p.chordQualities) items.push({ src, cfg: { mode: 'chord', chordRoot: r, chordRootAccidental: a, quality: q } });
    if (p.earMode === 'scale') for (const o of octs) for (const s of p.scaleTypes) items.push({ src, cfg: { mode: 'scale', root: r, rootAccidental: a, rootOctave: o, scaleType: s } });
    if (p.earMode === 'progression') for (const s of p.progressionSets) items.push({ src, cfg: { mode: 'progression', root: r, rootAccidental: a, progression: s, _sets: p.progressionSets } });
  });
}
if (PLANT) items.push(
  { src: 'PLANT-int', cfg: { mode: 'interval', root: 'C', rootAccidental: 'b', rootOctave: 4, targetSemitones: 12, direction: 'ascending' } },
  { src: 'PLANT-chord', cfg: { mode: 'chord', chordRoot: 'A', chordRootAccidental: '', quality: 'half_diminished7' } },
  { src: 'PLANT-prog', cfg: { mode: 'progression', root: 'C', rootAccidental: '', progression: ['IV', 'I'], _sets: [['IV', 'I'], ['I', 'V']] } },
);

const out: Record<string, string[]> = { interval: [], note: [], chord: [], scale: [], prog: [], progAmb: [] };
let n: Record<string, number> = {};
for (const { src, cfg: c } of items) {
  n[c.mode] = (n[c.mode] ?? 0) + 1;
  if (c.mode === 'note') {
    const p = playedMidi(c.note, c.accidental ?? '', c.octave ?? 4), o = midiAbs(c.note, c.accidental ?? '', c.octave ?? 4);
    if (p !== o) out.note.push(`${src} ${c.note}${c.accidental}${c.octave}: played ${nm(p)} expected ${nm(o)}`);
    if (/accidental/i.test(c._prompt ?? '')) {
      const ch = generateNoteChoices(c.note, c.accidental ?? '');
      const acc = ch.filter((x: any) => /[#b]/.test(x.label.slice(1)));
      out.note.push(`${src} "${c._prompt}" ${c.note}${c.accidental}: choices [${ch.map((x: any) => x.label).sort().join(', ')}] -> ${acc.length} accidental option(s)${acc.length === 1 ? '  <-- prompt gives the answer away' : ''}`);
    }
  }
  if (c.mode === 'interval') {
    const semis = c.direction === 'descending' ? -c.targetSemitones : c.targetSemitones;
    let rootPC = LET[c.root]; if (c.rootAccidental === '#') rootPC += 1; if (c.rootAccidental === 'b') rootPC -= 1;
    const targetPC = (((rootPC + semis) % 12) + 12) % 12; const oct = c.rootOctave ?? 4;
    const targetOct = oct + (rootPC + semis >= 12 ? 1 : rootPC + semis < 0 ? -1 : 0);
    const r = playedMidi(c.root, c.rootAccidental ?? '', oct), t = 12 + targetOct * 12 + targetPC;
    if (t - r !== semis) out.interval.push(`${src} ${c.root}${c.rootAccidental}${oct} ${c.direction} ${c.targetSemitones}: played ${nm(r)}->${nm(t)} = ${t - r}`);
  }
  if (c.mode === 'chord') {
    const notes = buildChord({ natural: c.chordRoot, accidental: c.chordRootAccidental ?? '' }, c.quality).notes;
    const midis = notes.map((x: any) => playedMidi(x.natural, x.accidental, 4)).sort((a: number, b: number) => a - b); // playChord(notes, 4)
    const bass = midis[0]; const rel = [...new Set(midis.map((m: number) => (m - bass) % 12))].sort((a, b) => a - b);
    const heardAsRootPos = Object.entries(CAT).filter(([, iv]) => iv.length === rel.length && iv.every((x, i) => x === rel[i])).map(([k]) => k);
    const rootPc = (LET[c.chordRoot] + ACC[c.chordRootAccidental ?? '']) % 12;
    const inv = bass % 12 !== rootPc;
    if (inv) out.chord.push(`${src} ${c.chordRoot}${c.chordRootAccidental ?? ''} ${c.quality}: plays ${midis.map(nm).join(' ')} (bass ${nm(bass)} = not the root)${heardAsRootPos.length && !heardAsRootPos.includes(c.quality) ? `  => identical to a ROOT-POSITION ${heardAsRootPos.join('/')} on ${NAMES[bass % 12]}` : ''}`);
  }
  if (c.mode === 'scale') {
    const notes = buildScale({ natural: c.root, accidental: c.rootAccidental ?? '' }, c.scaleType).notes;
    // replicate playScale ascending octave logic
    let cur = c.rootOctave ?? 4, last = -1; const seq: number[] = [];
    notes.forEach((x: any, i: number) => { const pcx = getPitchClass(x); if (i > 0 && pcx <= last) cur++; seq.push(12 + cur * 12 + pcx); last = pcx; });
    const rpc = getPitchClass(notes[0]); if (rpc <= last) cur++; seq.push(12 + cur * 12 + rpc);
    const exp = SC[c.scaleType].map((iv) => midiAbs(c.root, c.rootAccidental ?? '', c.rootOctave ?? 4) + iv).concat(midiAbs(c.root, c.rootAccidental ?? '', c.rootOctave ?? 4) + 12);
    if (JSON.stringify(seq) !== JSON.stringify(exp)) out.scale.push(`${src} ${c.root}${c.rootAccidental} ${c.scaleType}: played ${seq.map(nm).join(' ')} expected ${exp.map(nm).join(' ')}`);
  }
  if (c.mode === 'progression') {
    const triads = getDiatonicTriads({ natural: c.root, accidental: c.rootAccidental ?? '' });
    const chords = c.progression.map((num: string) => triads.find((t: any) => t.numeral.replace('°', '') === num.replace('°', '')));
    const voic = chords.map((ch: any) => ch.chord.notes.map((x: any) => playedMidi(x.natural, x.accidental, 4)).sort((a: number, b: number) => a - b));
    const bassLine = voic.map((v: number[]) => nm(v[0])).join(' ');
    const rootLine = chords.map((ch: any) => ch.chord.root.natural + ch.chord.root.accidental).join(' ');
    out.prog.push(`${src} ${c.progression.join('-')}: voicings ${voic.map((v: number[]) => '[' + v.map(nm).join(' ') + ']').join(' ')}  bass line ${bassLine}  (roots ${rootLine})`);
  }
}
// progression ambiguity: two options in the same choice set whose chord successions are
// transpositions of each other (same root-interval + same qualities) cannot be told apart
// without a key reference.
const DEG: Record<string, [number, string]> = { I: [0, 'M'], ii: [2, 'm'], iii: [4, 'm'], IV: [5, 'M'], V: [7, 'M'], vi: [9, 'm'], 'vii°': [11, 'd'] };
const shape = (p: string[]) => p.map((x, i) => (i ? ((DEG[x][0] - DEG[p[i - 1]][0] + 12) % 12) + ':' : '') + DEG[x][1]).join(' ');
const seenSets = new Set<string>();
for (const { src, cfg: c } of items) if (c.mode === 'progression' && c._sets) {
  const key = src + JSON.stringify(c._sets); if (seenSets.has(key)) continue; seenSets.add(key);
  const sets: string[][] = c._sets;
  for (let i = 0; i < sets.length; i++) for (let j = i + 1; j < sets.length; j++) if (shape(sets[i]) === shape(sets[j])) out.progAmb.push(`${src}: "${sets[i].join(' - ')}" and "${sets[j].join(' - ')}" have identical relative shape [${shape(sets[i])}] -> indistinguishable without a tonic reference`);
}
// interval choice sets for "Is the third major or minor?" — pool is correct±3 within 1..12
for (const s of [3, 4]) { const pool = []; for (let o = -3; o <= 3; o++) if (o && s + o >= 1 && s + o <= 12) pool.push(s + o); out.interval.push(`info: correct=${s} distractor pool (3 drawn at random) = ${pool.join(',')}`); }
console.log('items checked by mode', n);
for (const [k, v] of Object.entries(out)) { console.log(`\n## ${k} (${v.length})`); for (const l of v) console.log('  ' + l); }
