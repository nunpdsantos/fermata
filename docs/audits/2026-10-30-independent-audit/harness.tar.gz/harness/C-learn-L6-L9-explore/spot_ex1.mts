// Parent re-check of EX-1: which scale types make getDiatonicChordsForScale throw? (control: dorian)
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const chords: any = await import(R + '/core/constants/chords.ts');
const { SCALE_TYPE_NAMES, buildScale } = await import(R + '/core/constants/scales.ts');
let thr: string[] = [];
for (const st of Object.keys(SCALE_TYPE_NAMES)) {
  try { const r = chords.getDiatonicChordsForScale(buildScale({ natural: 'C', accidental: '' }, st)); if (st === 'dorian') console.log('control dorian ->', r.map((x: any) => x.numeral).join(' ')); }
  catch (e: any) { thr.push(`${st}: ${e.message}`); }
}
console.log('throwing scale types:', thr.length); thr.forEach((t) => console.log('  ' + t));
