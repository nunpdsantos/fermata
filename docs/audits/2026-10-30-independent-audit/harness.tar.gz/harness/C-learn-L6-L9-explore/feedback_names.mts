// What the build-exercise feedback calls each chord/scale in L6-L9 (raw enum names leak into UI text).
import { readFileSync } from 'node:fs';
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const { validateAnswer } = await import(R + '/components/learn/exercises/validateExercise.ts');
const all = JSON.parse(readFileSync('/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/C-learn-L6-L9-explore/all_exercises.json', 'utf8'));
const seen = new Set<string>();
for (const e of all) if (e.type === 'chord_build' || e.type === 'scale_build') {
  const r = validateAnswer(e.config, new Set<number>([99]));
  const k = r.expected; if (seen.has(k)) continue; seen.add(k);
  console.log(`${e.id.padEnd(12)} prompt: ${e.prompt.slice(0, 60).padEnd(60)} | feedback: ${r.explanation}`);
}
