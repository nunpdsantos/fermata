// Dump all L6-L9 exercises (authored + generated, English) in compact text form.
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const { generateAllForLevel, mergeExerciseMaps } = await import(R + '/data/exercises/exerciseGenerator.ts');
import { writeFileSync } from 'node:fs';
const levels = process.argv.slice(2).length ? process.argv.slice(2) : ['6','7','8','9'];
const all: any[] = [];
for (const L of levels) {
  const ex = (await import(`${R}/data/exercises/exercisesL${L}.ts`)).default;
  const tp = (await import(`${R}/data/exercises/templatesL${L}.ts`)).default;
  const gen = generateAllForLevel(tp, 'en');
  const merged = mergeExerciseMaps(ex, gen);
  let out = '';
  for (const [mid, list] of Object.entries(merged) as any) {
    out += `\n===== ${mid} (${list.length}) =====\n`;
    for (const e of list) {
      all.push({ level: L, moduleId: mid, ...e });
      const c = e.config;
      const { type, choices, ...rest } = c;
      out += `[${e.id}] ${e.type} :: ${e.prompt}\n`;
      if (Object.keys(rest).length) out += `   cfg: ${JSON.stringify(rest)}\n`;
      if (choices) for (const ch of choices) out += `   ${ch.correct ? '*' : ' '} ${ch.label}\n`;
      if (e.hint) out += `   hint: ${e.hint}\n`;
    }
  }
  writeFileSync(`/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/C-learn-L6-L9-explore/dump_L${L}.txt`, out);
}
writeFileSync('/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/C-learn-L6-L9-explore/all_exercises.json', JSON.stringify(all, null, 1));
console.log('total', all.length, 'by level', levels.map(L => all.filter(a => a.level === L).length));
