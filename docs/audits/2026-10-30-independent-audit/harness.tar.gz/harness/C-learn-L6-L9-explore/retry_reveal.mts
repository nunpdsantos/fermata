// For every choice-based L6-L9 exercise: submit a WRONG answer on attempt 1 and check whether the
// feedback text shown with the "Try again" button already contains the correct answer.
// (ExerciseFeedback renders result.explanation when canRetry; ChoiceInput also paints opt.correct green when submitted.)
import { readFileSync } from 'node:fs';
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const D = '/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/C-learn-L6-L9-explore';
const { validateAnswer } = await import(R + '/components/learn/exercises/validateExercise.ts');
const { INTERVAL_LABELS } = await import(R + '/core/constants/chords.ts');
let all = JSON.parse(readFileSync(D + '/all_exercises.json', 'utf8'));
if (process.argv.includes('--plant')) all.push({ id: 'PLANT-noreveal', type: 'multiple_choice', config: { type: 'multiple_choice', choices: [{ label: 'zzz-unique', correct: true }, { label: 'b', correct: false }] }, _expectNoReveal: true });
let n = 0, revealed = 0; const notRevealed: string[] = [];
for (const e of all) {
  const c = e.config; let wrong: string | null = null; let correctLabel = '';
  if (c.choices) { wrong = c.choices.find((x: any) => !x.correct).label; correctLabel = c.choices.find((x: any) => x.correct).label; }
  else if (c.type === 'ear_training' && c.mode === 'interval') { wrong = String(c.targetSemitones === 1 ? 2 : c.targetSemitones - 1); correctLabel = INTERVAL_LABELS[c.targetSemitones]; }
  else if (c.type === 'ear_training' && c.mode === 'note') { wrong = c.note === 'C' ? 'D' : 'C'; correctLabel = c.note + (c.accidental ?? ''); }
  else if (c.type === 'scale_degree_id') { wrong = String(c.correctDegree === 1 ? 2 : 1); correctLabel = ''; }
  if (wrong === null) continue;
  n++;
  const res = validateAnswer(c, wrong);
  if (res.correct) { console.log('UNEXPECTED correct for wrong answer', e.id); continue; }
  const shows = correctLabel ? res.explanation.includes(correctLabel) : /Tonic|Supertonic|Mediant|Subdominant|Dominant|Submediant|Leading/.test(res.explanation);
  if (shows) revealed++; else notRevealed.push(`${e.id}: "${res.explanation}"`);
  if (n <= 3) console.log(`sample ${e.id}: wrong="${wrong}" -> feedback "${res.explanation}"`);
}
console.log(`choice-based exercises: ${n}; feedback after 1st wrong attempt names the correct answer: ${revealed}`);
notRevealed.forEach((l) => console.log('  not revealed:', l));
