// Count scale types and chord qualities the engine actually has (L7 claims "46 scales", "42 chord types").
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const { CHORD_FORMULAS, CHORD_QUALITY_NAMES } = await import(R + '/core/constants/chords.ts');
const { SCALE_TYPE_NAMES, SCALE_FORMULAS } = await import(R + '/core/constants/scales.ts') as any;
console.log('CHORD_FORMULAS keys:', Object.keys(CHORD_FORMULAS).length);
console.log('CHORD_QUALITY_NAMES keys:', Object.keys(CHORD_QUALITY_NAMES).length);
console.log('SCALE_TYPE_NAMES keys:', Object.keys(SCALE_TYPE_NAMES).length);
if (SCALE_FORMULAS) console.log('SCALE_FORMULAS keys:', Object.keys(SCALE_FORMULAS).length);
console.log('scales:', Object.keys(SCALE_TYPE_NAMES).join(' '));
