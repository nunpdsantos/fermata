// L7 exercise checks: answer leaks in build prompts, tritone-sub answer key, vague "this X" prompts,
// duplicate configs, generated-template vs module-title alignment. Oracle = own pitch math.
// Usage: cd <repo> && npx tsx <this> [--plant]
import { readFileSync } from 'node:fs';
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const D = '/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/C-learn-L6-L9-explore';
const { L7_UNITS } = await import(R + '/core/constants/curriculumL7.ts');
let ex: any[] = JSON.parse(readFileSync(D + '/all_exercises.json', 'utf8')).filter((e: any) => e.level === '7');
const PLANT = process.argv.includes('--plant');
if (PLANT) ex.push(
  { id: 'PLANT-leak', moduleId: 'x', type: 'chord_build', prompt: 'Build C major: C, E, G.', config: { type: 'chord_build', root: 'C', rootAccidental: '', quality: 'major', noteCount: 3 } },
  { id: 'PLANT-tt', moduleId: 'x', type: 'chord_build', prompt: 'Build the tritone substitution for the dominant 7th on G. Replace it with a dom7 a tritone away.', config: { type: 'chord_build', root: 'G', rootAccidental: '', quality: 'dominant7', noteCount: 4 } },
);
const LET: Record<string, number> = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };
const ACC: Record<string, number> = { '': 0, '#': 1, b: -1, '##': 2, bb: -2 };
const pc = (l: string, a = '') => (((LET[l] + ACC[a]) % 12) + 12) % 12;
const DOM7 = [0, 4, 7, 10];
const set = (r: number, iv: number[]) => iv.map((x) => (r + x) % 12).sort((a, b) => a - b).join(',');

console.log('--- 1. build prompts that spell out the answer notes ---');
for (const e of ex) {
  if (e.type !== 'chord_build' && e.type !== 'scale_build') continue;
  const m = e.prompt.match(/notes?:\s*([A-G][#b]?(?:,\s*[A-G][#b]?)+)/);
  if (m) console.log(`LEAK ${e.id}: prompt lists "${m[1]}" (noteCount ${e.config.noteCount})`);
}
console.log('--- 2. tritone-substitution build: what the prompt asks vs what the grader accepts ---');
for (const e of ex) {
  const m = e.prompt.match(/tritone substitution for the dominant 7th on ([A-G][#b]?)/);
  if (!m || e.type !== 'chord_build') continue;
  const asked = m[1]; const r = pc(asked[0], asked.slice(1));
  const promptAnswer = set((r + 6) % 12, DOM7); // tritone sub of asked
  const graded = set(pc(e.config.root, e.config.rootAccidental), DOM7);
  console.log(`${promptAnswer === graded ? 'OK  ' : 'WRONG-KEY'} ${e.id}: prompt asks sub of ${asked}7 -> pcs {${promptAnswer}}; grader accepts ${e.config.root}${e.config.rootAccidental}7 {${graded}}`);
}
// template-level: every root the template can draw
const tpl = (await import(R + '/data/exercises/templatesL7.ts')).default.find((t: any) => t.moduleId === 'l7u21m4').templates[0];
let bad = 0; tpl.params.roots.forEach((r: string, i: number) => { const a = tpl.params.accidentals[i]; const s = set(pc(r, a), DOM7), sub = set((pc(r, a) + 6) % 12, DOM7); if (s !== sub) bad++; });
console.log(`template l7u21m4[0]: ${bad}/${tpl.params.roots.length} drawable roots produce a wrong answer key`);

console.log('--- 3. prompts referring to "this X" that the prompt never shows ---');
let vague = 0;
for (const e of ex) if (/\bthis (jazz chord symbol|context|mode|pop progression|common pop chord progression|harmonic technique|scale|chord type)\b/i.test(e.prompt)) { vague++; console.log(`VAGUE ${e.id}: ${e.prompt}`); }
console.log(`vague prompts: ${vague}`);

console.log('--- 4. "extended chord" prompt on non-extended qualities ---');
for (const e of ex) if (/extended chord/.test(e.prompt) && ['major7', 'minor7', 'dominant7', 'major', 'minor'].includes(e.config.quality)) console.log(`NOT-EXTENDED ${e.id}: ${e.prompt}`);

console.log('--- 5. duplicate configs within L7 ---');
const seen = new Map<string, string>();
for (const e of ex) { const k = JSON.stringify(e.config); if (seen.has(k)) console.log(`DUP ${e.id} == ${seen.get(k)}`); else seen.set(k, e.id); }

console.log('--- 6. generated exercises vs module title ---');
const titles: Record<string, string> = {}; for (const u of L7_UNITS) for (const m of u.modules) titles[m.id] = m.title;
const tsrc = readFileSync(R + '/data/exercises/templatesL7.ts', 'utf8');
for (const m of tsrc.matchAll(/\/\/ ---- (l7u\d+m\d+): ([^-\n]+?) ----/g)) {
  const n = ex.filter((e) => e.moduleId === m[1] && /g\d+$/.test(e.id)).length;
  console.log(`${m[1]} template-comment="${m[2].trim()}" | module title="${titles[m[1]]}" | generated=${n}`);
}
