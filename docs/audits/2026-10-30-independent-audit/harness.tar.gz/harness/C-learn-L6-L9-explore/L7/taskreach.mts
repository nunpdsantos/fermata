// For each quoted token in L7 task instructions: is it a clickable button (ModuleView QUERY_VERB_PATTERN)
// or plain text the learner must type into Cmd+K? Then resolve via the matching path.
// Usage: cd <repo> && npx tsx <this> [--plant]
(globalThis as any).localStorage = { getItem: () => null, setItem: () => {}, removeItem: () => {} };
(globalThis as any).window = globalThis;
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const { L7_UNITS } = await import(R + '/core/constants/curriculumL7.ts');
const { getResults } = await import(R + '/components/navigation/quickSearchResults.ts');
const { resolve } = await import('./queries.mts');
// copied verbatim from src/components/learn/ModuleView.tsx:19
const QUERY_VERB_PATTERN = /(Type|Open|Search for)\s+['"‘“]([^'"’”]+)['"’”]/gi;
const tasks: any[] = [];
for (const u of L7_UNITS) for (const m of u.modules) for (const t of m.tasks) tasks.push(t);
if (process.argv.includes('--plant')) tasks.push({ id: 'PLANT', instruction: "Type 'C altered scale' then 'C whole tone scale'." });
let dead = 0, total = 0, clickable = 0;
for (const t of tasks) {
  QUERY_VERB_PATTERN.lastIndex = 0;
  const click = new Set([...t.instruction.matchAll(QUERY_VERB_PATTERN)].map((m: any) => m[2]));
  for (const m of t.instruction.matchAll(/'([^']+)'/g)) {
    const q = m[1];
    if (!/^[A-G]/.test(q)) continue; // skip prose quotes like 'wonder'
    total++;
    if (click.has(q)) { clickable++; const r = resolve(q); if (r.startsWith('FALLBACK')) { dead++; console.log(`DEAD-BUTTON ${t.id} '${q}'`); } continue; }
    const r = getResults(q);
    const top = r[0] ? `${r[0].type}:${r[0].label}` : '(no results)';
    const ok = r.length > 0 && r[0].type !== 'Lesson';
    if (!ok) dead++;
    console.log(`${ok ? 'ok  ' : 'DEAD'} typed  ${t.id.padEnd(10)} '${q}' -> ${top}`);
  }
}
console.log(`tokens=${total} clickable=${clickable} dead=${dead}`);
