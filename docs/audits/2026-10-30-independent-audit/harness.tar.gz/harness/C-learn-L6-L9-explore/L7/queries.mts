// Resolve every L7 tryThisQuery + every 'quoted' symbol in L7 text through the same parser
// path as src/utils/queryExecutor.ts (replicated without the store), print what it resolves to.
// Expectations are judged by hand / by oracle in chordscale.mts — this script is the "actual".
// Usage: cd <repo> && npx tsx <this> [--plant]
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const { L7_UNITS } = await import(R + '/core/constants/curriculumL7.ts');
const { parseChordSymbol, chordFromParsed, looksLikeChordSymbol } = await import(R + '/core/utils/chordParser.ts');
const { parseScaleSymbol } = await import(R + '/core/utils/scaleParser.ts');
const { buildScale } = await import(R + '/core/constants/scales.ts');
const { noteToString } = await import(R + '/core/types/music.ts');

const MODE_TO_SCALE: Record<string, string> = { ionian: 'major', aeolian: 'natural_minor' };
const ROOTLESS: Record<string, string> = {
  major: 'major', minor: 'natural_minor', 'natural minor': 'natural_minor', 'harmonic minor': 'harmonic_minor',
  'melodic minor': 'melodic_minor', chromatic: 'chromatic', 'whole tone': 'whole_tone', blues: 'blues',
  'major blues': 'major_blues', pentatonic: 'pentatonic_major', 'major pentatonic': 'pentatonic_major',
  'pentatonic major': 'pentatonic_major', 'minor pentatonic': 'pentatonic_minor', 'pentatonic minor': 'pentatonic_minor',
  altered: 'altered', diminished: 'diminished_whole_half',
};
const SUFFIX: Array<[RegExp, string]> = [
  [/\s+diminished\s+7th$/i, 'dim7'], [/\s+diminished\s+seventh$/i, 'dim7'], [/\s+dominant\s+7th$/i, '7'],
  [/\s+dominant\s+seventh$/i, '7'], [/\s+major\s+7th$/i, 'maj7'], [/\s+major\s+seventh$/i, 'maj7'],
  [/\s+minor\s+7th$/i, 'm7'], [/\s+minor\s+seventh$/i, 'm7'], [/\s+major$/i, ''], [/\s+minor$/i, 'm'],
  [/\s+diminished$/i, 'dim'], [/\s+augmented$/i, 'aug'],
];
function norm(q: string): string | null {
  const s = q.replace(/\s+chord$/i, '');
  if (s === q && !/\s/.test(q)) return null;
  for (const [p, suf] of SUFFIX) if (p.test(s)) { const r = s.replace(p, '').trim(); if (/^[A-Ga-g][#b]?$/.test(r)) return r + suf; }
  return null;
}
export function resolve(query: string): string {
  const q = query.trim();
  if (/^key\s+of/i.test(q)) return 'KEY';
  if (q.toLowerCase() === 'circle of fifths') return 'CIRCLE';
  const rl = ROOTLESS[q.toLowerCase().replace(/\s+scale$/, '').trim()];
  if (rl) return `SCALE(rootless) ${rl}`;
  const ps = parseScaleSymbol(q) ?? parseScaleSymbol(q.replace(/\s+scale$/i, ''));
  if (ps) {
    const st = MODE_TO_SCALE[ps.scaleType] ?? ps.scaleType;
    let notes = '';
    try { notes = buildScale(ps.root, st).notes.map(noteToString).join(' '); } catch (e) { notes = 'BUILD-ERR ' + e; }
    return `SCALE ${noteToString(ps.root)} ${st} [${notes}]`;
  }
  const wf = norm(q);
  const ci = wf ?? (looksLikeChordSymbol(q) ? q : null);
  const pc = ci ? parseChordSymbol(ci) : null;
  if (pc) {
    const ch = chordFromParsed(pc);
    return `CHORD ${ch.quality} [${ch.notes.map(noteToString).join(' ')}]${(ch as any).bass ? ' /' + noteToString((ch as any).bass) : ''}`;
  }
  return 'FALLBACK (dead query)';
}

const items: { where: string; q: string; kind: string }[] = [];
for (const u of L7_UNITS) {
  if (u.milestone) items.push({ where: u.id + ' milestone', q: u.milestone.tryThisQuery, kind: 'tryThis' });
  for (const m of u.modules) {
    m.concepts.forEach((c: any, i: number) => {
      items.push({ where: `${m.id} c${i + 1}`, q: c.tryThisQuery, kind: 'tryThis' });
      if (c.childTryThisQuery) items.push({ where: `${m.id} c${i + 1} child`, q: c.childTryThisQuery, kind: 'tryThis' });
    });
    for (const t of m.tasks) {
      if (t.query) items.push({ where: t.id, q: t.query, kind: 'taskQuery' });
      const quoted = [...t.instruction.matchAll(/'([^']+)'/g)].map((x) => x[1]);
      for (const q of quoted) items.push({ where: t.id, q, kind: 'typed-in-task' });
    }
  }
}
if (process.argv.includes('--plant')) items.push({ where: 'PLANT', q: 'Xyzzy blorp', kind: 'tryThis' });
for (const it of items) console.log(`${it.where.padEnd(18)} ${it.kind.padEnd(14)} ${JSON.stringify(it.q).padEnd(26)} -> ${resolve(it.q)}`);
