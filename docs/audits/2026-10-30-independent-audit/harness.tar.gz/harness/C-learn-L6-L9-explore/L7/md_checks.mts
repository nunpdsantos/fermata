// First-principles checks of claims in curriculum/07-jazz-pop-modal.md (spec doc). No app imports.
import { existsSync } from 'node:fs';
const LET: Record<string, number> = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };
const pc = (n: string) => { let v = LET[n[0]]; for (const a of n.slice(1)) v += a === '#' ? 1 : -1; return ((v % 12) + 12) % 12; };
const up = (a: string, b: string) => (pc(b) - pc(a) + 12) % 12;
const T: Record<number, string> = { 0: 'R', 1: 'b9', 2: '9', 3: '#9', 4: '3', 5: '11', 6: '#11', 7: '5', 8: 'b13', 9: '13', 10: 'b7', 11: 'maj7' };
console.log('md:173 "Eb triad over C7 = C7#9b13":', ['Eb', 'G', 'Bb'].map((n) => T[up('C', n)]).join(','), '(no b13; b13 would be Ab)');
console.log('md:193 "D/C ... creates Cmaj9 sound": D/C tones over C =', ['D', 'F#', 'A'].map((n) => T[up('C', n)]).join(','), '(no 3rd, no maj7 -> not a maj9)');
console.log('md:118 back-door "3rd (D) and 7th (Ab) resolve to the 3rd and root of I": D->E', up('D', 'E'), 'st; Ab->G is to the', T[up('C', 'G')], 'of C, Ab->C would be', up('Ab', 'C'), 'st');
const AEO = [0, 2, 3, 5, 7, 8, 10], ION = [0, 2, 4, 5, 7, 9, 11];
console.log('md:234 "Aeolian: lowered 6th and 7th (compared to major)": degrees differing =', AEO.map((x, i) => (x !== ION[i] ? i + 1 : null)).filter(Boolean).join(','));
const DOR = [0, 2, 3, 5, 7, 9, 10]; const triad = (s: number[], d: number) => [s[d], s[(d + 2) % 7], s[(d + 4) % 7]].map((x) => (x - s[d] + 12) % 12).join(',');
console.log('md:241 Dorian "II" chord on degree 2 of Dorian: intervals', triad(DOR, 1), '(0,3,7 = minor -> ii, not II)');
const MIX = [0, 2, 4, 5, 7, 9, 10];
console.log('md:244 Mixolydian "vii°" — triad on degree 7 of Mixolydian:', triad(MIX, 6), '(0,4,7 = major bVII); the diminished triad sits on degree', [0, 1, 2, 3, 4, 5, 6].find((d) => triad(MIX, d) === '0,3,6')! + 1);
console.log('md:288 "i-bVI-bIII-bVII Andalusian": Andalusian cadence = i-bVII-bVI-V (descending tetrachord A-G-F-E); the md row lists a different progression');
const myst = ['C', 'F#', 'Bb', 'E', 'A', 'D']; console.log('md:426 mystic chord intervals (semitones):', myst.slice(1).map((n, i) => up(myst[i], n)).join(','), '(6=A4, 4=d4, 6=A4, 5=P4, 5=P4)');
console.log('md:390 "Bebop melodic minor: melodic minor + b3": melodic minor already contains b3 (3 st)');
for (const f of ['src/core/constants/progressionPatterns.ts', 'src/core/constants/modes.ts', 'src/core/constants/chordScaleRelationships.ts']) console.log('exists', f, existsSync('/Users/nunosantos/Documents/Base/Music/new_music_app/' + f));
