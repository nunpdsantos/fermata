// First-principles checks of L7 theory claims. Pure oracle: no app imports.
// Usage: cd <repo> && npx tsx <this> [--plant]
const PLANT = process.argv.includes('--plant');
const LET: Record<string, number> = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };
const pc = (n: string) => { let v = LET[n[0]]; for (const a of n.slice(1)) v += a === '#' ? 1 : -1; return ((v % 12) + 12) % 12; };
const NAMES = ['C', 'Db', 'D', 'Eb', 'E', 'F', 'F#', 'G', 'Ab', 'A', 'Bb', 'B'];
const nm = (p: number) => NAMES[((p % 12) + 12) % 12];
const ivl = (a: string, b: string) => (pc(b) - pc(a) + 12) % 12; // ascending semitones a->b
let fails = 0;
const check = (label: string, cond: boolean, detail: string) => { console.log(`${cond ? 'HOLDS ' : 'FAILS '} ${label} :: ${detail}`); if (!cond) fails++; };

// chord formulas (semitones above root, mod 12)
const CH: Record<string, number[]> = {
  maj7: [0, 4, 7, 11], m7: [0, 3, 7, 10], '7': [0, 4, 7, 10], m7b5: [0, 3, 6, 10], dim7: [0, 3, 6, 9], mMaj7: [0, 3, 7, 11],
  '7#11': [0, 4, 7, 10, 6], '7alt': [0, 4, 10, 1, 3, 6, 8], '7b9': [0, 4, 7, 10, 1], '7#5': [0, 4, 8, 10], '7b13': [0, 4, 7, 10, 8],
};
const SC: Record<string, number[]> = {
  ionian: [0, 2, 4, 5, 7, 9, 11], dorian: [0, 2, 3, 5, 7, 9, 10], phrygian: [0, 1, 3, 5, 7, 8, 10], lydian: [0, 2, 4, 6, 7, 9, 11],
  mixolydian: [0, 2, 4, 5, 7, 9, 10], aeolian: [0, 2, 3, 5, 7, 8, 10], locrian: [0, 1, 3, 5, 6, 8, 10],
  melodic_minor: [0, 2, 3, 5, 7, 9, 11], harmonic_minor: [0, 2, 3, 5, 7, 8, 11], lydian_dominant: [0, 2, 4, 6, 7, 9, 10],
  altered: [0, 1, 3, 4, 6, 8, 10], locrian_nat2: [0, 2, 3, 5, 6, 8, 10], whole_tone: [0, 2, 4, 6, 8, 10],
  dim_half_whole: [0, 1, 3, 4, 6, 7, 9, 10], dim_whole_half: [0, 2, 3, 5, 6, 8, 9, 11], phrygian_dominant: [0, 1, 4, 5, 7, 8, 10],
  mixolydian_b6: [0, 2, 4, 5, 7, 8, 10],
};
const fits = (chord: string, scale: string) => { const s = new Set(SC[scale]); const miss = CH[chord].filter((x) => !s.has(x % 12)); return miss; };

console.log('--- A. chord-scale pairings asserted in L7 text/exercises (chord tones must lie in scale) ---');
const pairs: [string, string, string][] = [
  ['maj7', 'ionian', 'l7u22m1 c1'], ['maj7', 'lydian', 'l7u22m1 c1'], ['m7', 'dorian', 'l7u22m1 c1'], ['m7', 'aeolian', 'l7u22m1 c1'],
  ['m7', 'phrygian', 'l7u22m1 c1'], ['7', 'mixolydian', 'l7u22m1 c1'], ['7', 'lydian_dominant', 'l7u22m1 c1'], ['7', 'dim_half_whole', 'l7u22m1 c1'],
  ['m7b5', 'locrian', 'l7u22m1 c1'], ['m7b5', 'locrian_nat2', 'l7u22m1 c1/l7u23m3 c3'], ['dim7', 'dim_whole_half', 'l7u22m1 c1'],
  ['mMaj7', 'melodic_minor', 'l7u22m1 c1'], ['mMaj7', 'harmonic_minor', 'l7u22m1 c1'], ['7#11', 'lydian_dominant', 'l7u22m1 c2/l7u23m3t3'],
  ['7alt', 'altered', 'l7u21m2 c2/u23 milestone'], ['7b9', 'dim_half_whole', 'l7u22m1 c2'], ['7#5', 'whole_tone', 'l7u22m1 c2 (whole-tone dominant)'],
  ['7b9', 'phrygian_dominant', 'l7u22m1 c2 (dominant to minor)'], ['7b13', 'mixolydian_b6', 'l7u23m3 c2'],
  // whole-tone / altered over a plain dominant 7 (natural 5th) — stated in the l7u22m1 c1 map
  ['7', 'whole_tone', 'l7u22m1 c1 (plain 7 -> whole-tone)'], ['7', 'altered', 'l7u22m1 c1 (plain 7 -> altered)'],
];
if (PLANT) pairs.push(['maj7', 'dorian', 'PLANT']);
for (const [c, s, w] of pairs) { const m = fits(c, s); check(`${c} in ${s} [${w}]`, m.length === 0, m.length ? `missing chord tones (semitones above root): ${m.join(',')}` : 'all chord tones in scale'); }

console.log('--- B. mode-of / shortcut claims ---');
const rot = (s: number[], k: number) => s.map((x) => (x - s[k] + 12) % 12).sort((a, b) => a - b);
const eqArr = (a: number[], b: number[]) => a.length === b.length && a.every((x, i) => x === b[i]);
check('altered = mode 7 of melodic minor', eqArr(rot(SC.melodic_minor, 6), SC.altered), '');
check('lydian dominant = mode 4 of melodic minor', eqArr(rot(SC.melodic_minor, 3), SC.lydian_dominant), '');
check('mixolydian b6 = mode 5 of melodic minor', eqArr(rot(SC.melodic_minor, 4), SC.mixolydian_b6), '');
check('locrian nat2 = mode 6 of melodic minor', eqArr(rot(SC.melodic_minor, 5), SC.locrian_nat2), '');
check('phrygian dominant = mode 5 of harmonic minor', eqArr(rot(SC.harmonic_minor, 4), SC.phrygian_dominant), '');
check('C altered pcs = Db melodic minor pcs', eqArr(SC.altered.map((x) => x).sort((a, b) => a - b), SC.melodic_minor.map((x) => (x + 1) % 12).sort((a, b) => a - b)), '');
const steps = (s: number[]) => s.map((x, i) => ((s[(i + 1) % s.length] - x + 12) % 12 === 1 ? 'H' : (s[(i + 1) % s.length] - x + 12) % 12 === 2 ? 'W' : '?')).join('-');
check('altered formula H-W-H-W-W-W-W', steps(SC.altered) === 'H-W-H-W-W-W-W', steps(SC.altered));
check('melodic minor W-H-W-W-W-W-H', steps(SC.melodic_minor) === 'W-H-W-W-W-W-H', steps(SC.melodic_minor));
// ii-V-i minor note pools: D locrian nat2, G altered, C melodic minor -> three different pools?
const pool = (root: string, s: string) => new Set(SC[s].map((x) => (pc(root) + x) % 12));
const key = (s: Set<number>) => [...s].sort((a, b) => a - b).join(',');
const pools = [key(pool('D', 'locrian_nat2')), key(pool('G', 'altered')), key(pool('C', 'melodic_minor'))];
check('minor ii-V-i: three different note pools', new Set(pools).size === 3, pools.join(' | '));
const majPools = [key(pool('D', 'dorian')), key(pool('G', 'mixolydian')), key(pool('C', 'ionian')), key(pool('C', 'lydian'))];
check('major ii-V-I: Dorian/Mixolydian/Ionian/LYDIAN all share one pool (text: "All three scales share the same notes" while offering C Lydian)', new Set(majPools).size === 1, majPools.join(' | '));

console.log('--- C. specific prose claims ---');
// C1 shell voicing: "The 5th is ... perfect in all standard chord types" and "The 3rd and 7th change — that is what makes each quality distinct" (Cmaj7, Cm7, C7, Cm7b5)
for (const q of ['maj7', 'm7', '7', 'm7b5', 'dim7']) console.log(`   ${q}: 5th = ${CH[q][2]} semitones (${CH[q][2] === 7 ? 'perfect' : 'NOT perfect'}), shell(3rd,7th) = (${CH[q][1]},${CH[q][3]})`);
check('5th is perfect in every chord type taught as a shell (incl. m7b5 in task l7u21m2t1)', ['maj7', 'm7', '7', 'm7b5'].every((q) => CH[q][2] === 7), 'm7b5 5th = 6');
check('3rd+7th distinguish Cm7 from Cm7b5 (task l7u21m2t1)', !(CH.m7[1] === CH.m7b5[1] && CH.m7[3] === CH.m7b5[3]), `m7 shell (${CH.m7[1]},${CH.m7[3]}) vs m7b5 shell (${CH.m7b5[1]},${CH.m7b5[3]})`);
// C2 tritone-sub ii-V: "bass line descends chromatically: Ab-Db-C ... entirely chromatic"
const bass = ['Ab', 'Db', 'C']; const moves = bass.slice(1).map((b, i) => Math.min(ivl(bass[i], b), 12 - ivl(bass[i], b)));
check('Abm7-Db7-Cmaj7 bass Ab-Db-C is entirely chromatic (every move 1 semitone)', moves.every((m) => m === 1), `moves (smallest distance) = ${moves.join(', ')} semitones`);
// C3 upper structure "Db major triad over C7 produces C7(b9,#11,b13)"
const ext = (n: string) => ({ 1: 'b9', 2: '9', 3: '#9', 5: '11 (natural)', 6: '#11', 8: 'b13', 9: '13', 0: 'root', 4: '3', 7: '5', 10: 'b7', 11: 'maj7' } as any)[ivl('C', n)];
const ust = (tri: string[]) => tri.map((n) => `${n}=${ext(n)}`).join(', ');
console.log(`   D/C7: ${ust(['D', 'F#', 'A'])} ; Eb/C7: ${ust(['Eb', 'G', 'Bb'])} ; Ab/C7: ${ust(['Ab', 'C', 'Eb'])} ; Db/C7: ${ust(['Db', 'F', 'Ab'])} ; Gb/C7: ${ust(['Gb', 'Bb', 'Db'])}`);
check('Db triad over C7 = C7(b9,#11,b13)', ['Db', 'F', 'Ab'].map(ext).join(',') === 'b9,#11,b13', `actual: ${['Db', 'F', 'Ab'].map(ext).join(',')}`);
check('tritone sub of C7 is Db7 (text calls Db/C7 "the tritone-sub voicing")', nm(pc('C') + 6) === 'Db', `tritone sub root = ${nm(pc('C') + 6)}`);
// C4 C#dim7 -> Dm7 "every voice moves by a half step or stays the same"
const perms = (a: number[]): number[][] => (a.length <= 1 ? [a] : a.flatMap((x, i) => perms([...a.slice(0, i), ...a.slice(i + 1)]).map((p) => [x, ...p])));
const dist = (a: number, b: number) => Math.min((b - a + 12) % 12, (a - b + 12) % 12);
const from = ['C#', 'E', 'G', 'Bb'].map(pc), to = ['D', 'F', 'A', 'C'].map(pc);
let best = 99, bestP: number[] = [];
for (const p of perms(to)) { const mx = Math.max(...from.map((f, i) => dist(f, p[i]))); if (mx < best) { best = mx; bestP = p; } }
check('C#dim7 -> Dm7: some voicing has every voice moving <=1 semitone', best <= 1, `best possible max move = ${best} semitones (${from.map((f, i) => nm(f) + '->' + nm(bestP[i])).join(', ')})`);
// C5 "Between F and Em, insert F#dim7" -> bass F-F#-E
check('F - F#dim7 - Em: bass F-F#-E is a chromatic line in one direction', false, `F->F# = +${ivl('F', 'F#')}, F#->E = -${(pc('F#') - pc('E') + 12) % 12} (direction reverses; second move is a whole step)`);
// C6 "a 9sus chord built a perfect 5th above the root of a minor chord ... e.g. G9sus ... instead of Dm"
check('G is a perfect 5th ABOVE D', ivl('D', 'G') === 7, `D->G ascending = ${ivl('D', 'G')} semitones (P4); P5 above D = ${nm(pc('D') + 7)}`);
check('G9sus4 (G C D F A) = Dm7 (D F A C) over G', key(new Set(['C', 'D', 'F', 'A'].map(pc))) === key(new Set(['D', 'F', 'A', 'C'].map(pc))), 'upper notes of G9sus4 = C D F A = Dm7');
check('Dm11/G = G9sus4 (same pitch set)', key(new Set(['G', 'D', 'F', 'A', 'C', 'E'].map(pc))) === key(new Set(['G', 'C', 'D', 'F', 'A'].map(pc))), 'Dm11 adds E (the 13th of G), absent from G9sus4');
// C7 back-door: "D rises to E and Ab falls to G, both upper leading tones"
check('D->E is an UPPER leading tone (approach from above)', pc('D') > pc('E'), 'D (2) is below E (4): lower approach');
// C8 Loop rotations: "IV-V-vi-IV (starting on IV)" as a rotation of I-V-vi-IV
const loop = ['I', 'V', 'vi', 'IV']; const rots = loop.map((_, i) => [...loop.slice(i), ...loop.slice(0, i)].join('-'));
check('IV-V-vi-IV is a rotation of I-V-vi-IV', rots.includes('IV-V-vi-IV'), `rotations: ${rots.join(' | ')}`);
// C9 avoid notes: Berklee def = scale tone a half step above a chord tone (used by the app's own exercise l7u23m4g3)
const avoid = (chord: string, scale: string) => SC[scale].filter((t) => !CH[chord].map((x) => x % 12).includes(t) && CH[chord].some((c) => (c + 1) % 12 === t));
const char: [string, string, string, number][] = [['dorian', 'm7', 'natural 6', 9], ['phrygian', 'm7', 'b2', 1], ['lydian', 'maj7', '#4', 6], ['mixolydian', '7', 'b7', 10]];
for (const [s, c, label, t] of char) { const av = avoid(c, s); check(`characteristic ${label} of ${s} is an avoid note over ${c}`, av.includes(t), `avoid notes of ${s} over ${c}: [${av.join(',')}]; b7 of mixolydian is ${CH['7'].includes(10) ? 'a CHORD TONE of the dominant 7th' : ''}`); }
// C10 quintal: "D-A-E-B ... is the inversion of a quartal voicing (D-G-C-F inverted gives open fifths)"
check('inverting D-G-C-F gives D-A-E-B', false, `D-G-C-F inverted (each 4th -> 5th, top-down) = F-C-G-D; D-A-E-B inverts B-E-A-D`);
// C11 Eb7 subs A7, Ab7 subs D7, Db7 subs G7; roots C-Eb-Ab-Db: up m3 then two P4s
check('Eb7/Ab7/Db7 are tritone subs of A7/D7/G7', ['A', 'D', 'G'].map((r) => nm(pc(r) + 6)).join(',') === 'Eb,Ab,Db', '');
check('C->Eb up m3, Eb->Ab up P4, Ab->Db up P4', ivl('C', 'Eb') === 3 && ivl('Eb', 'Ab') === 5 && ivl('Ab', 'Db') === 5, '');
// C12 Giant Steps: B-G-Eb major 3rds apart
check('B, G, Eb a M3 apart', ivl('B', 'G') === 8 && ivl('G', 'Eb') === 8 && ivl('Eb', 'B') === 8, 'each descending M3 (8 ascending semitones = 4 descending)');
// C13 back-door Bb7 = V7 of Eb (bIII)
check('Bb7 is V7 of Eb', ivl('Eb', 'Bb') === 7, '');
// C14 Dorian G major (IV) contains raised 6th B; Lydian II (D) contains #4 F#; vii (Bm) contains F#
check('C Lydian vii = B minor contains F#', true, 'B D F# (all in C lydian) ');
// C15 minor ii-V-i: b9 of G7 (Ab) = b6 of C minor
check('b9 of G = b6 of C', nm(pc('G') + 1) === nm(pc('C') + 8), `${nm(pc('G') + 1)} vs ${nm(pc('C') + 8)}`);
if (PLANT) check('PLANT: C->G is a minor 3rd', ivl('C', 'G') === 3, 'should FAIL');
console.log(`\nFAILS=${fails}`);
