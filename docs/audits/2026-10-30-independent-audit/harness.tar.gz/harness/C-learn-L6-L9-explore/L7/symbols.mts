// Do the jazz symbol spellings L7 teaches (maj7/triangle, m7/dash, ø7, o7, °, +, (#9), min7(b5)) parse to the right chord?
// "actual" = core parseChordSymbol + chordFromParsed; expectation written by hand per symbol (interval set from root C).
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const { parseChordSymbol, chordFromParsed } = await import(R + '/core/utils/chordParser.ts');
const { getPitchClass } = await import(R + '/core/constants/notes.ts');
const cases: [string, number[]][] = [
  ['CΔ7', [0, 4, 7, 11]], ['C∆7', [0, 4, 7, 11]], ['CΔ', [0, 4, 7, 11]], ['C-7', [0, 3, 7, 10]], ['C-', [0, 3, 7]], ['Cø7', [0, 3, 6, 10]], ['Cø', [0, 3, 6, 10]],
  ['Co7', [0, 3, 6, 9]], ['C°7', [0, 3, 6, 9]], ['C°', [0, 3, 6]], ['C+', [0, 4, 8]], ['C7(#9)', [0, 4, 7, 10, 3]], ['Cmin7(b5)', [0, 3, 6, 10]],
  ['C13', [0, 4, 7, 10, 2, 9]], ['C7alt', [0, 4, 10, 1, 3, 6, 8]], ['C6/9', [0, 4, 7, 9, 2]], ['C13#11', [0, 4, 7, 10, 2, 6, 9]], ['Cm7b5', [0, 3, 6, 10]],
  ['PLANTCmaj7', [0, 3, 7, 10]],
];
for (const [sym, iv] of cases) {
  const s = sym.replace('PLANT', '');
  const p = parseChordSymbol(s);
  const exp = [...new Set(iv.map((x) => x % 12))].sort((a, b) => a - b).join(',');
  if (!p) { console.log(`NO-PARSE ${sym}`); continue; }
  const ch = chordFromParsed(p);
  const act = [...new Set(ch.notes.map((n: any) => getPitchClass(n)))].sort((a: number, b: number) => a - b).join(',');
  console.log(`${act === exp ? 'ok      ' : 'MISMATCH'} ${sym.padEnd(12)} quality=${p.quality} pcs={${act}} expected={${exp}}`);
}
