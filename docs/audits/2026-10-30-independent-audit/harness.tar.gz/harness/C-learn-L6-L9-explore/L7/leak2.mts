// Broader leak check: does the set of note names written in a build prompt equal the answer's pitch-class set?
// Oracle interval sets are local. Usage: cd <repo> && npx tsx <this>
import { readFileSync } from 'node:fs';
const D = '/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/C-learn-L6-L9-explore';
const ex: any[] = JSON.parse(readFileSync(D + '/all_exercises.json', 'utf8')).filter((e: any) => e.level === '7');
ex.push({ id: 'PLANT-leak', type: 'chord_build', prompt: 'Build C major: C, E, G.', config: { root: 'C', rootAccidental: '', quality: 'major' } });
const LET: Record<string, number> = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 }; const ACC: Record<string, number> = { '': 0, '#': 1, b: -1 };
const pc = (l: string, a = '') => (((LET[l] + ACC[a]) % 12) + 12) % 12;
const IV: Record<string, number[]> = { major: [0,4,7], minor: [0,3,7], major7: [0,4,7,11], minor7: [0,3,7,10], dominant7: [0,4,7,10], major9: [0,4,7,11,2], minor9: [0,3,7,10,2],
  dorian: [0,2,3,5,7,9,10], mixolydian: [0,2,4,5,7,9,10], phrygian: [0,1,3,5,7,8,10], lydian: [0,2,4,6,7,9,11], locrian: [0,1,3,5,6,8,10], blues: [0,3,5,6,7,10],
  pentatonic_minor: [0,3,5,7,10], pentatonic_major: [0,2,4,7,9], whole_tone: [0,2,4,6,8,10], chromatic: [0,1,2,3,4,5,6,7,8,9,10,11], melodic_minor: [0,2,3,5,7,9,11],
  altered: [0,1,3,4,6,8,10], diminished_half_whole: [0,1,3,4,6,7,9,10] };
let n = 0;
for (const e of ex) {
  if (e.type !== 'chord_build' && e.type !== 'scale_build') continue; n++;
  const q = e.config.quality ?? e.config.scaleType; if (!IV[q]) { console.log('NO-ORACLE', e.id, q); continue; }
  const exp = new Set(IV[q].map((x) => (pc(e.config.root, e.config.rootAccidental) + x) % 12));
  const toks = [...e.prompt.matchAll(/\b([A-G])([#b]?)(?![a-z0-9])/g)].map((m) => pc(m[1], m[2]));
  const got = new Set(toks);
  if (exp.size === got.size && [...exp].every((x) => got.has(x))) console.log(`LEAK ${e.id}: ${e.prompt}`);
}
console.log('build exercises checked:', n - 1, '(+1 plant)');
