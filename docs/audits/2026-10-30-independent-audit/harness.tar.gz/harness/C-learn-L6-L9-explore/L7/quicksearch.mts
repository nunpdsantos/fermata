// Feed every L7 typed-in-task string + tryThisQuery to Cmd+K getResults (the place a learner "types")
// and print the top results. Usage: cd <repo> && npx tsx <this>
(globalThis as any).localStorage = { getItem: () => null, setItem: () => {}, removeItem: () => {} };
(globalThis as any).window = globalThis;
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const { getResults } = await import(R + '/components/navigation/quickSearchResults.ts');
const qs = process.argv.slice(2);
for (const q of qs) {
  const r = getResults(q);
  console.log(JSON.stringify(q).padEnd(28), '->', r.slice(0, 3).map((x: any) => `${x.type}:${x.label}`).join(' | ') || '(no results)');
}
