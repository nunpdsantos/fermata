// Can the 7 harmonic-minor modes (l7u23m4 objective "Navigate all seven modes of harmonic minor") be reached?
// Feeds candidate names to the scale parser; also checks the engine's formula list for each mode's interval set.
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const { parseScaleSymbol } = await import(R + '/core/utils/scaleParser.ts');
const { SCALE_FORMULAS } = await import(R + '/core/constants/scales.ts') as any;
const HM = [0, 2, 3, 5, 7, 8, 11];
const names = ['harmonic minor', 'locrian #6', 'ionian #5', 'dorian #4', 'phrygian dominant', 'lydian #2', 'super locrian bb7'];
const alias: Record<number, string[]> = { 3: ['ukrainian dorian', 'romanian minor'], 6: ['ultralocrian', 'altered bb7'] };
for (let k = 0; k < 7; k++) {
  const set = HM.map((x) => (x - HM[k] + 12) % 12).sort((a, b) => a - b).join(',');
  const inEngine = Object.entries(SCALE_FORMULAS).filter(([, f]: any) => [...f].sort((a: number, b: number) => a - b).join(',') === set).map(([n]) => n);
  const tries = [names[k], ...(alias[k] ?? [])].map((n) => `"C ${n}"->${parseScaleSymbol('C ' + n)?.scaleType ?? 'null'}`);
  console.log(`mode ${k + 1} {${set}} engine: [${inEngine.join(',') || 'NONE'}] parser: ${tries.join('; ')}`);
}
