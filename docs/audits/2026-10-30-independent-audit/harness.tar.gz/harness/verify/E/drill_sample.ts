const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
import fs from 'node:fs';
import i18next from '/Users/nunosantos/Documents/Base/Music/new_music_app/node_modules/i18next/dist/esm/i18next.js';
(async () => {
  const loc = (l: string) => JSON.parse(fs.readFileSync(`${R}/i18n/locales/${l}.json`, 'utf8'));
  await i18next.init({ resources: { en: { translation: loc('en') }, pt: { translation: loc('pt') }, es: { translation: loc('es') } }, lng: 'pt', fallbackLng: 'en', interpolation: { escapeValue: false } });
  const { generateDrillBank } = await import(`${R}/core/utils/drillBank/index.ts`);
  const bank = generateDrillBank() as any[];
  const seen: Record<string, number> = {};
  for (const lng of ['pt','es']) {
    console.log('=====', lng);
    const t = i18next.getFixedT(lng);
    seen[lng] = 0;
    for (const fam of ['degree','keysig','roman','function','scale']) {
      const items = bank.filter(b => b.family === fam);
      for (const it of items.filter((_, i) => i % Math.max(1, Math.floor(items.length/2)) === 0).slice(0,2)) {
        console.log(`[${fam}] PROMPT:`, t(it.promptKey, it.promptParams));
        console.log(`        WHY:`, t(it.whyKey, it.whyParams));
        console.log(`        CHOICES:`, JSON.stringify(it.input?.choices ?? it.answer ?? null).slice(0,200));
      }
    }
  }
})();
