import i18next from '/Users/nunosantos/Documents/Base/Music/new_music_app/node_modules/i18next/dist/esm/i18next.js';
import fs from 'node:fs';
const L = '/Users/nunosantos/Documents/Base/Music/new_music_app/src/i18n/locales/';
const res = {};
for (const l of ['en','pt','es']) res[l] = { translation: JSON.parse(fs.readFileSync(L+l+'.json','utf8')) };
// Same options as src/i18n/index.ts (minus react binding)
await i18next.init({ resources: res, lng: 'en', fallbackLng: 'en', interpolation: { escapeValue: false } });
console.log('i18next version', i18next.version);
for (const lng of ['en','pt','es']) {
  const t = i18next.getFixedT(lng);
  for (const c of [1,2,3]) console.log(lng, c, '|', t('exerciseFeedback.scaleMissing',{count:c}), '|', t('exerciseFeedback.chordExtra',{count:c}));
}
// Control: does _one/_other work?
i18next.addResources('pt','translation',{ctlMissing_one:'falta {{count}} nota', ctlMissing_other:'faltam {{count}} notas'});
const tp = i18next.getFixedT('pt');
console.log('control _one/_other pt', tp('ctlMissing',{count:1}), '|', tp('ctlMissing',{count:2}));
// Control: does a compat setting rescue _plural?
const inst2 = i18next.createInstance();
await inst2.init({ resources: res, lng:'pt', fallbackLng:'en', interpolation:{escapeValue:false}, compatibilityJSON:'v3' });
console.log('with compatibilityJSON v3 (option exists in v25?)', inst2.t('exerciseFeedback.scaleMissing',{count:2}));
