import fs from 'node:fs';
const R='/Users/nunosantos/Documents/Base/Music/new_music_app/src/i18n/content';
function walk(o:unknown,acc:string[]){ if(typeof o==='string')acc.push(o); else if(Array.isArray(o))o.forEach(v=>walk(v,acc)); else if(o&&typeof o==='object')Object.values(o).forEach(v=>walk(v,acc)); }
(async()=>{
 for (const lang of ['pt','es']) {
  const strs:string[]=[];
  for (const f of fs.readdirSync(`${R}/${lang}`).filter(f=>f.startsWith('curriculumL')||f.startsWith('exercisesL')||f.startsWith('templatesL'))) walk((await import(`${R}/${lang}/${f}`)).default,strs);
  // a quoted token containing an English music word: scale/chord/major/minor/dominant/etc, i.e. a typed query
  const re=/["'«][^"'»]*\b(scale|chord|major|minor|dominant|diminished|augmented|seventh|7th|triad|mode|interval)\b[^"'»]*["'»]/i;
  const n=strs.filter(s=>re.test(s)).length;
  console.log(lang,'strings',strs.length,'with quoted English-music-word token:',n);
 }
})();
