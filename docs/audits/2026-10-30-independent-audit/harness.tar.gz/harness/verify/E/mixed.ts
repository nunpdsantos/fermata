import fs from 'node:fs';
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const LETTER = [
  /\b[A-G](?:#|b|♯|♭)(?![a-z])/g,
  /\b[A-G](?:#|b)?[0-68]\b/g,
  /\b[A-G](?:#|b)?-[A-G](?:#|b)?\b/g,
  /\b[A-G](?:#|b)? (?:maior|menor|mayor|central|natural)\b/g,
];
const SOLF_PT = [
  /(?:Dó|Ré|Fá|Lá)(?:#|b|♯|♭|\s?sustenido|\s?bemol)?/g,
  /\b(?:Sol|Mi|Si)(?:#|b|♯|♭)?(?= (?:maior|menor|central|sustenido|bemol)|-|#|b\b|♯|♭)/g,
  /\b(?:Sol|Mi|Si)(?:#|b)\b/g,
];
const SOLF_ES = [
  /\b(?:Do|Re|Fa|La|Sol|Mi|Si)(?:#|b|♯|♭)?(?= (?:mayor|menor|central|sostenido|bemol)|-[A-Z]|#|♯|♭)/g,
  /\b(?:Do|Re|Fa|La|Sol|Mi|Si)(?:#|b)\b/g,
  /-(?:Do|Re|Fa|La|Sol|Mi|Si)(?:#|b)?\b/g,
];
function matches(s: string, res: RegExp[]) { const o: string[] = []; for (const r of res) for (const m of s.matchAll(r)) o.push(m[0]); return o; }
// strip quoted app-queries: '...' "..." «...»  (typed English commands) and chord-symbol-ish tokens in quotes
function stripQuoted(s: string) { return s.replace(/'[^']*'/g, ' ').replace(/"[^"]*"/g, ' ').replace(/«[^»]*»/g, ' ').replace(/“[^”]*”/g, ' '); }
function walk(o: unknown, path: string, acc: [string, string][]) {
  if (typeof o === 'string') acc.push([path, o]);
  else if (Array.isArray(o)) o.forEach((v, i) => walk(v, `${path}[${i}]`, acc));
  else if (o && typeof o === 'object') for (const [k, v] of Object.entries(o)) walk(v, path ? `${path}.${k}` : k, acc);
}
async function main() {
  for (const lang of ['pt','es'] as const) {
    const SOLF = lang === 'pt' ? SOLF_PT : SOLF_ES;
    const files = fs.readdirSync(`${R}/i18n/content/${lang}`).filter(f => f.endsWith('.ts'));
    const strings: [string,string][] = [];
    for (const f of files) { const mod = (await import(`${R}/i18n/content/${lang}/${f}`)).default; walk(mod, f.replace('.ts',''), strings); }
    walk(JSON.parse(fs.readFileSync(`${R}/i18n/locales/${lang}.json`,'utf8')), 'locale', strings);
    let L=0,S=0,B=0,Bunq=0; const unq: string[] = [];
    for (const [p,s] of strings) {
      const l = matches(s, LETTER), so = matches(s, SOLF);
      if (l.length) L++; if (so.length) S++;
      if (l.length && so.length) {
        B++;
        const lq = matches(stripQuoted(s), LETTER), sq = matches(stripQuoted(s), SOLF);
        if (lq.length && sq.length) { Bunq++; unq.push(`${p} L=${JSON.stringify([...new Set(lq)])} S=${JSON.stringify([...new Set(sq)])}`); }
      }
    }
    console.log(`${lang}: strings=${strings.length} letter=${L} solf=${S} both=${B} both-after-removing-quoted-queries=${Bunq}`);
    fs.writeFileSync(`/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/verify/E/mixed_unquoted_${lang}.txt`, unq.join('\n'));
  }
}
main().catch(e => { console.error(e); process.exit(1); });
