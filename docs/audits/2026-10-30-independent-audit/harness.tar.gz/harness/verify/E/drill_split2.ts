const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
import fs from 'node:fs';
import i18next from '/Users/nunosantos/Documents/Base/Music/new_music_app/node_modules/i18next/dist/esm/i18next.js';
(async () => {
  const loc = (l: string) => JSON.parse(fs.readFileSync(`${R}/i18n/locales/${l}.json`, 'utf8'));
  await i18next.init({ resources: { en: { translation: loc('en') }, pt: { translation: loc('pt') } }, lng: 'pt', fallbackLng: 'en', interpolation: { escapeValue: false } });
  const { generateDrillBank } = await import(`${R}/core/utils/drillBank/index.ts`);
  const bank = generateDrillBank() as any[];
  const KEY = /\b[A-G][♯♭#b]? (major|minor|natural minor|harmonic minor|melodic minor|dorian|mixolydian|lydian|phrygian|locrian)\b/;
  const DEG = /\b(Tonic|Supertonic|Mediant|Subdominant|Dominant|Submediant|Leading tone|Subtonic)\b/;
  const FUNC = /(pre-dominant|cadence|\(RU:|perfect\)|imperfect\)|plagal\)|interrupted\))/;
  const CLAUSE = /\b(home|away from tonic|builds tension|creates rest|the reference stack|with the 7th lowered|lowered|then)\b/;
  const byFam: Record<string, any> = {};
  let promptOrWhyKey = 0, choicesOnlyKey = 0, anyNonChordNonInterval = 0, total = 0;
  for (const it of bank) {
    const p = i18next.t(it.promptKey, it.promptParams) as string;
    const w = i18next.t(it.whyKey, it.whyParams) as string;
    const c = (it.input?.choices ?? []).join(' || ');
    const f = (byFam[it.family] ??= { n: 0, keyInPromptOrWhy: 0, keyInChoicesOnly: 0, deg: 0, func: 0, clause: 0, any: 0 });
    f.n++;
    const kpw = KEY.test(p) || KEY.test(w);
    const kc = KEY.test(c);
    if (kpw) f.keyInPromptOrWhy++; else if (kc) f.keyInChoicesOnly++;
    const d = DEG.test(p + w + c), fn = FUNC.test(p + w + c), cl = CLAUSE.test(p + w + c);
    if (d) f.deg++; if (fn) f.func++; if (cl) f.clause++;
    // stricter: English that is NOT a chord-quality/interval name: key in prompt/why, degree names, function/cadence/clause
    if (kpw || d || fn || cl) f.any++;
  }
  console.log(JSON.stringify(byFam, null, 1));
  const tot = Object.values(byFam).reduce((a: any, f: any) => a + f.any, 0);
  console.log('strict any (key in prompt/why OR degree OR func OR clause), choices-only chord names excluded:', tot, 'of', bank.length);
})();
