import re,sys
base='/Users/nunosantos/Documents/Base/Music/new_music_app/src/'
en=open(base+'data/songReferences.ts').read()
# count modules & contexts
mods=re.findall(r"^\s*'(l\d+u\d+m\d+)': \[(.*?)^\s*\],",en,re.S|re.M)
print('EN modules',len(mods),'contexts',sum(len(re.findall(r'context:',b)) for _,b in mods))
for lang in ('pt','es'):
    s=open(base+f'i18n/content/{lang}/songs.ts').read()
    m=re.findall(r"^\s*'(l\d+u\d+m\d+)': \[(.*?)^\s*\],",s,re.S|re.M)
    print(lang,'modules',len(m),'strings',sum(len(re.findall(r"^\s{4}'",b,re.M)) for _,b in m))
    d={k:len(re.findall(r"^\s{4}'",b,re.M)) for k,b in m}
    e={k:len(re.findall(r'context:',b)) for k,b in mods}
    print(' mismatch', {k:(e[k],d.get(k,0)) for k in e if e[k]!=d.get(k,0)})
