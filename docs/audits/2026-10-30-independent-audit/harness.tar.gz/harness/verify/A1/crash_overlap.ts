import { buildScale, SCALE_FORMULAS } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/constants/scales.ts';
import { getScaleNotesWithOctaves } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/utils/pianoLayout.ts';
const L='CDEFGAB'; const crash=new Set(['diminished_whole_half','diminished_half_whole','bebop_dominant','bebop_major']);
console.log(Object.keys(SCALE_FORMULAS).length, [...crash].filter(c=>c in SCALE_FORMULAS));
const ROOTS=['C','C#','D','Eb','E','F','F#','G','Ab','A','Bb','B'];
let tot=0, inCrash=0; const types:Record<string,number>={};
for (const t of Object.keys(SCALE_FORMULAS)) for (const r of ROOTS){ const sc=buildScale({natural:r[0],accidental:r.slice(1)} as any,t as any); const p=getScaleNotesWithOctaves(sc.notes,4); const s=p.map(n=>n.octave*7+L.indexOf(n.natural)); let bad=false; for(let i=1;i<s.length;i++) if(s[i]<s[i-1]) bad=true; if(bad){tot++; if(crash.has(t)) inCrash++; else types[t]=(types[t]||0)+1;} }
console.log({tot,inCrash,selectable:tot-inCrash}); console.log(types);
