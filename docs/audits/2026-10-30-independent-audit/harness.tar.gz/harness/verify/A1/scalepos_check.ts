// Independent check for A-1. Pure internal-consistency: does each dot's sounded pitch equal root + its own degree label?
// Plus: is the sounded pitch in the scale per the APP's engine (buildScale) - so no dependence on the auditor's oracle.
import { SCALE_POSITION_LIBRARY, getScalePositions } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/constants/guitarScalePositions.ts';
import { buildScale } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/constants/scales.ts';
import { getPitchClass } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/constants/notes.ts';
const OPEN = [4, 9, 2, 7, 11, 4]; // EADGBE low->high; position.string 6 = low E
const SEMI: Record<string, number> = { '1':0,'b2':1,'2':2,'#2':3,'b3':3,'3':4,'b4':4,'4':5,'b5':6,'#4':6,'5':7,'#5':8,'b6':8,'6':9,'b7':10,'7':11 };
const RN = process.argv[2] ?? 'A'; const ROOT = { natural: RN[0], accidental: RN.slice(1) } as any;
const rootPc = getPitchClass(ROOT);
const seen = new Set<any>(); let uniq = 0, clean = 0, labelBad = 0, outBad = 0, either = 0;
const cleanList: string[] = [];
for (const [sc, list] of Object.entries(SCALE_POSITION_LIBRARY)) {
  const scale = buildScale(ROOT, sc === 'ionian' ? 'major' : sc === 'aeolian' ? 'natural_minor' : sc as any);
  const inScale = new Set(scale.notes.map((n: any) => getPitchClass(n)));
  getScalePositions(ROOT, sc).forEach(({ position: p, baseFret: b }, i) => {
    if (seen.has(p)) return; seen.add(p); uniq++;
    let lb = false, ob = false;
    for (const n of p.notes) {
      const pc = (OPEN[6 - n.string] + b + n.fret) % 12;
      if (pc !== (rootPc + SEMI[n.degree]) % 12) lb = true;
      if (!inScale.has(pc)) ob = true;
    }
    if (lb) labelBad++; if (ob) outBad++; if (lb || ob) either++; else { clean++; cleanList.push(`${sc}#${i+1}`); }
  });
}
console.log({ uniq, clean, labelBad_positions: labelBad, outOfScale_positions: outBad, wrong_either: either });
console.log(cleanList.join(', '));
