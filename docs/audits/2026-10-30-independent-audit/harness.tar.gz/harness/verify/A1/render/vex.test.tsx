import './setup.ts';
import { it, expect } from 'vitest';
import { render, waitFor, cleanup } from '@testing-library/react';
import { writeFileSync } from 'node:fs';
import { StaffNotation } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/components/notation/StaffNotation.tsx';
import { buildScale } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/constants/scales.ts';
import { getScaleNotesWithOctaves } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/utils/pianoLayout.ts';
import { getKeySignatureForScale } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/utils/notationHelpers.ts';
(globalThis as any).ResizeObserver = class { observe() {} disconnect() {} };
const NAME: Record<number, string> = { 0xE260: 'flat', 0xE261: 'natural', 0xE262: 'sharp', 0xE263: 'dsharp', 0xE264: 'dflat' };
it('vex', async () => {
  const out: string[] = [];
  for (const [r, t] of [['C','harmonic_minor'],['G','melodic_minor'],['D','melodic_minor'],['A','harmonic_minor'],['C#','major']] as const) {
    const scale = buildScale({ natural: r[0], accidental: r.slice(1) } as any, t as any);
    const notes = getScaleNotesWithOctaves(scale.notes, 4);
    const sig = getKeySignatureForScale(scale.root, t) ?? undefined;
    const { container } = render(<StaffNotation notes={notes} keySignature={sig} width={700} height={130} />);
    await waitFor(() => expect(container.querySelectorAll('svg g.vf-stavenote').length).toBeGreaterThan(0), { timeout: 15000 });
    await new Promise((x) => setTimeout(x, 200));
    const svg = container.querySelector('svg')!;
    const glyphs: string[] = [];
    // key-signature accidentals vs note accidentals, separated by group class
    const ks = [...svg.querySelectorAll('g.vf-keysignature text, .vf-keysignature text')].map((e) => [...(e.textContent ?? '')].map((c) => NAME[c.codePointAt(0)!]).filter(Boolean).join('')).filter(Boolean);
    const na = [...svg.querySelectorAll('g.vf-stavenote .vf-modifiers text, g.vf-stavenote text')].map((e) => [...(e.textContent ?? '')].map((c) => NAME[c.codePointAt(0)!]).filter(Boolean).join('')).filter(Boolean);
    const ys = [...svg.querySelectorAll('g.vf-stavenote')].map((g) => { const h = g.querySelector('.vf-notehead text, .vf-notehead path, text'); return h ? Number(h.getAttribute('y')) : NaN; });
    out.push(`${r} ${t} sig=${sig}: keysig glyphs=${ks.length}, note accidental glyphs=[${na.join(',')}], note y=[${ys.join(',')}]`);
    cleanup();
  }
  writeFileSync('/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/verify/A1/out_vex.txt', out.join('\n'));
});
