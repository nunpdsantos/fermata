// Independent check of A-3 / A-4. Uses the app's engine only to get the notes the UI would draw.
import { buildScale, SCALE_FORMULAS } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/constants/scales.ts';
import { getScaleNotesWithOctaves } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/utils/pianoLayout.ts';
import { getKeySignatureForScale, pitchedNoteToVexKey, getVexAccidental } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/utils/notationHelpers.ts';

const L = 'CDEFGAB';
const PC: any = { C:0, D:2, E:4, F:5, G:7, A:9, B:11 };
const AC: any = { '':0, '#':1, b:-1, '##':2, bb:-2 };
// KeySelector roots (12 buttons, per auditor's claim; I verify below by reading KeySelector)
const ROOTS = process.argv[2] ? process.argv[2].split(',') : ['C','C#','D','Eb','E','F','F#','G','Ab','A','Bb','B'];
const flatsOrder = 'BEADGCF', sharpsOrder = 'FCGDAEB';
// Key signature letters altered, derived from circle-of-fifths counting (my own, not copied)
const majorFifths: any = { C:0,G:1,D:2,A:3,E:4,B:5,'F#':6,'C#':7,F:-1,Bb:-2,Eb:-3,Ab:-4,Db:-5,Gb:-6,Cb:-7 };
function sigMap(sig: string): Record<string,number> {
  const minor = sig.endsWith('m'); const t = minor ? sig.slice(0,-1) : sig;
  // minor key = relative major's signature: fifths(minor tonic) = fifths(major tonic of same letter/acc) - 3
  let n = majorFifths[t] ?? NaN; if (minor) n -= 3;
  const m: any = {};
  if (n > 0) for (let i=0;i<n;i++) m[sharpsOrder[i]] = 1;
  if (n < 0) for (let i=0;i<-n;i++) m[flatsOrder[i]] = -1;
  return m;
}
const toNote = (s: string) => ({ natural: s[0], accidental: s.slice(1) }) as any;
let wrongRead = 0, octJump = 0; const wr: string[] = [], oj: string[] = []; const wrCombos = new Set<string>(), ojCombos = new Set<string>();
for (const type of Object.keys(SCALE_FORMULAS)) for (const root of ROOTS) {
  let sc; try { sc = buildScale(toNote(root), type as any); } catch (e) { continue; }
  const p = getScaleNotesWithOctaves(sc.notes, 4);
  const sig = getKeySignatureForScale(sc.root, type);
  const sm = sig ? sigMap(sig) : {};
  // A-3: reader pc vs true pc
  p.forEach((n) => {
    const exp = getVexAccidental(n);
    const shown = exp !== null ? AC[exp] : (sm[n.natural] ?? 0);
    const read = (PC[n.natural] + shown + 120) % 12; const tru = (PC[n.natural] + AC[n.accidental] + 120) % 12;
    if (read !== tru) { wrongRead++; wrCombos.add(`${root} ${type}`); }
  });
  // A-4: staff steps (letter*octave) must increase by exactly 1 per scale degree for 7-note scales, never decrease for any
  const steps = p.map((n) => n.octave * 7 + L.indexOf(n.natural));
  for (let i=1;i<steps.length;i++) if (steps[i] < steps[i-1]) { octJump++; ojCombos.add(`${root} ${type}`); break; }
}
console.log('A-3 wrong-read notes:', wrongRead, 'combos:', wrCombos.size, [...wrCombos].join(' | '));
console.log('A-4 non-ascending staff positions combos:', ojCombos.size);
const sel = [...ojCombos];
console.log(sel.length ? sel.slice(0,10).join(' | ') : '');
// hand trace
for (const [r,t] of [['C#','major'],['Ab','natural_minor']]) {
  const sc = buildScale(toNote(r), t as any); const p = getScaleNotesWithOctaves(sc.notes,4);
  console.log(r,t,p.map(pitchedNoteToVexKey).join(' '));
}
