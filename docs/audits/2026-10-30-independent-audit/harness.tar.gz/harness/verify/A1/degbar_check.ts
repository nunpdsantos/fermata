import { buildScale, SCALE_FORMULAS, getScaleDegreeIntervalLabel } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/constants/scales.ts';
const L='CDEFGAB'; const ROOTS=['C','C#','D','Eb','E','F','F#','G','Ab','A','Bb','B'];
const crash=new Set(['diminished_whole_half','diminished_half_whole','bebop_dominant','bebop_major']);
const bad:Record<string,number>={}; let ex:string[]=[];
for(const t of Object.keys(SCALE_FORMULAS)) { if(crash.has(t)) continue; for(const r of ROOTS){
  const sc=buildScale({natural:r[0],accidental:r.slice(1)} as any,t as any); const f=(SCALE_FORMULAS as any)[t] as number[];
  let mism=false;
  sc.notes.forEach((n:any,i:number)=>{ const lab=getScaleDegreeIntervalLabel(i,f[i],f.length); const m=/(\d+)$/.exec(lab); if(!m) return; // 'R','TT' etc skipped
    const num=Number(m[1]); const letterNum=((L.indexOf(n.natural)-L.indexOf(r[0])+7)%7)+1; 
    if(num!==letterNum && !(num===8)) { mism=true; if(ex.length<6 && r==='A') ex.push(`${r} ${t} deg${i}: label ${lab} note ${n.natural}${n.accidental}`);} });
  if(mism) bad[t]=(bad[t]||0)+1; } }
console.log(bad, ex);
