(globalThis as any).localStorage = { getItem: () => null, setItem: () => {}, removeItem: () => {} };
(globalThis as any).window = globalThis;
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const { executeTheoryQuery } = await import(R + '/utils/queryExecutor.ts');
const { parseScaleSymbol } = await import(R + '/core/utils/scaleParser.ts');
for (const q of ['C double harmonic major','C double harmonic','C major chord','C altered scale','G altered scale','F major scale','C locrian #6','C ukrainian dorian','C dorian #4','C lydian #2','C altered dominant']) {
  console.log(JSON.stringify(q), 'executeTheoryQuery ->', executeTheoryQuery(q), '| parseScale ->', JSON.stringify(parseScaleSymbol(q)?.scaleType ?? null));
}
