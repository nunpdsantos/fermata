(globalThis as any).localStorage = { getItem: () => null, setItem: () => {}, removeItem: () => {} };
(globalThis as any).window = globalThis;
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const { getResults } = await import(R + '/components/navigation/quickSearchResults.ts');
const { executeTheoryQuery } = await import(R + '/utils/queryExecutor.ts');
for (const q of ['C major chord','C altered scale','F major scale','D natural minor scale','C double harmonic major','C double harmonic','C major','C altered','C maj','F major','C whole tone scale','C whole tone','G altered scale']) {
  const r = getResults(q);
  console.log(JSON.stringify(q), '->', r.length ? r.slice(0,3).map((x:any)=>x.type+':'+x.label).join(' | ') : '(no results)');
}
