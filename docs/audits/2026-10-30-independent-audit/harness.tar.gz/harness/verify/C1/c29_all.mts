(globalThis as any).localStorage = { getItem: () => null, setItem: () => {}, removeItem: () => {} };
(globalThis as any).window = globalThis;
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const { getResults } = await import(R + '/components/navigation/quickSearchResults.ts');
const { executeTheoryQuery } = await import(R + '/utils/queryExecutor.ts');
const QUERY_VERB_PATTERN = /(Type|Open|Search for)\s+['"‘“]([^'"’”]+)['"’”]/gi;
for (let lv = 1; lv <= 9; lv++) {
  let units: any[] = [];
  try { const mod = await import(`${R}/core/constants/curriculumL${lv}.ts`); units = (Object.values(mod).find((v: any) => Array.isArray(v) && v[0]?.modules) as any) ?? []; } catch (e) { console.log('L'+lv, 'import fail', String(e).slice(0,80)); continue; }
  let total = 0, clickable = 0, clickDead = 0, typedDead = 0; const ex: string[] = [];
  for (const u of units) for (const m of u.modules) for (const t of m.tasks) {
    const click = new Set<string>([...t.instruction.matchAll(QUERY_VERB_PATTERN)].map((x: any) => x[2]));
    for (const mm of t.instruction.matchAll(/'([^']+)'/g)) {
      const q = mm[1]; if (!/^[A-G]/.test(q)) continue; total++;
      if (click.has(q)) { clickable++; if (executeTheoryQuery(q) === 'fallback') { clickDead++; ex.push('BTN '+t.id+' '+q);} continue; }
      if (getResults(q).length === 0) { typedDead++; if (ex.length<6) ex.push('TYPED '+t.id+' '+q); }
    }
  }
  console.log(`L${lv}: tokens=${total} clickable=${clickable} deadButtons=${clickDead} typedNoResults=${typedDead}`, ex.slice(0,4).join(' | '));
}
