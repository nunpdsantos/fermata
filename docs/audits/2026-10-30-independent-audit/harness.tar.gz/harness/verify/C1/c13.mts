const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const { getDiatonicChordsForScale } = await import(R + '/core/constants/chords.ts');
const { buildScale } = await import(R + '/core/constants/scales.ts');
const { getPitchClass } = await import(R + '/core/utils/noteUtils.ts').catch(async()=>await import(R + '/core/constants/notes.ts'));
const types = ['major_blues','bebop_dorian','hungarian_minor','hungarian_major','double_harmonic','persian','neapolitan_minor','neapolitan_major','hirajoshi','in_sen','iwato','egyptian'];
const root = { natural: 'C', accidental: '' };
let total = 0, bad = 0, badScales = 0;
for (const t of types) {
  const sc = buildScale(root, t);
  const pcs = new Set(sc.notes.map((n: any) => getPitchClass(n)));
  const ch = getDiatonicChordsForScale(sc);
  let sbad = 0;
  ch.forEach((c: any, i: number) => {
    total++;
    const cp = c.chord.notes.map((n: any) => getPitchClass(n));
    const out = cp.filter((p: number) => !pcs.has(p));
    if (out.length) { bad++; sbad++; }
    console.log(t, i+1, c.numeral, c.chord.root?.natural ?? '', c.chord.notes.map((n: any)=>n.natural+n.accidental).join(' '), out.length ? 'OUT '+out : 'ok');
  });
  if (sbad) badScales++;
}
console.log({total, bad, badScales});
