const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const { generateExercises } = await import(R + '/data/exercises/exerciseGenerator.ts');
const ids = process.argv.slice(2);
for (const n of [3,4]) {
  const tp = (await import(R + `/data/exercises/templatesL${n}.ts`)).default;
  const ex = (await import(R + `/data/exercises/exercisesL${n}.ts`)).default;
  for (const tc of tp) {
    if (!ids.includes(tc.moduleId)) continue;
    console.log('=== ' + tc.moduleId + ' authored:');
    for (const e of ex[tc.moduleId] ?? []) console.log('  A', e.id, e.type, '|', e.prompt.slice(0, 110));
    for (const e of generateExercises(tc)) {
      const cs = e.config.choices ? e.config.choices.find((c:any)=>c.correct)?.label : '';
      console.log('  G', e.id, e.type, '|', e.prompt.slice(0, 70), '| ✓', (cs||'').slice(0, 90));
    }
  }
}
