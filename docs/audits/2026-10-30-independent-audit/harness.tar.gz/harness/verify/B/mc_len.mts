const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
let aT=0,aL=0,aLge=0, tT=0,tL=0,tLge=0;
const seen = new Set<string>();
for (const n of [1,2,3,4,5]) {
  const ex = (await import(R + `/data/exercises/exercisesL${n}.ts`)).default;
  const tp = (await import(R + `/data/exercises/templatesL${n}.ts`)).default;
  for (const arr of Object.values(ex) as any[]) for (const e of arr) {
    if (e.config.type !== 'multiple_choice') continue;
    const ch = e.config.choices; const lens = ch.map((c:any)=>c.label.length); const max=Math.max(...lens);
    const c = ch.find((x:any)=>x.correct); aT++;
    if (c.label.length===max && lens.filter((l:number)=>l===max).length===1) aL++;
    if (c.label.length===max) aLge++;
  }
  for (const tc of tp) for (const t of tc.templates) if (t.type==='multiple_choice') for (const cs of t.params.choiceSets ?? []) {
    const k = JSON.stringify(cs); if (seen.has(k)) continue; seen.add(k);
    const lens = cs.map((c:any)=>c.label.length); const max=Math.max(...lens);
    const c = cs.find((x:any)=>x.correct); tT++;
    if (c.label.length===max && lens.filter((l:number)=>l===max).length===1) tL++;
    if (c.label.length===max) tLge++;
  }
}
console.log({authored:[aT,aL,aLge], templateSets:[tT,tL,tLge], uniqueTotal: aT+tT, strict: aL+tL, pct: ((aL+tL)/(aT+tT)*100).toFixed(1)});
