const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const { generateExercises } = await import(R + '/data/exercises/exerciseGenerator.ts');
const ex = (await import(R + `/data/exercises/exercisesL1.ts`)).default;
const tp = (await import(R + `/data/exercises/templatesL1.ts`)).default;
const by: Record<string,number> = {}; let tot=0;
for (const [mid, arr] of Object.entries(ex) as any) for (const e of arr) if (e.type==='interval_id'||(e.type==='ear_training'&&e.config.mode==='interval')) { by[mid]=(by[mid]??0)+1; tot++; }
for (const tc of tp) for (const e of generateExercises(tc)) if (e.type==='interval_id'||(e.type==='ear_training'&&e.config.mode==='interval')) { by[tc.moduleId]=(by[tc.moduleId]??0)+1; tot++; }
console.log(tot, by);
