const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const { generateExercises } = await import(R + '/data/exercises/exerciseGenerator.ts');
const want = new Set(process.argv.slice(2));
for (const n of [1,2,3,4,5]) {
  const tp = (await import(R + `/data/exercises/templatesL${n}.ts`)).default;
  for (const tc of tp) for (const e of generateExercises(tc)) if (want.has(e.id)) console.log(e.id, '|', e.prompt, '\n  cfg:', JSON.stringify(e.config).slice(0,600), '\n  hint:', e.hint);
}
