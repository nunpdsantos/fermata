const { applyAnswer } = await import('/Users/nunosantos/Documents/Base/Music/new_music_app/src/services/drillScheduler.ts');
const DAY = 86400000; let t = Date.UTC(2026,9,1,9);
let st: any;
const step = (label: string, correct: boolean, ms: number, sess: string, dt = 3000) => { t += dt; st = applyAnswer(st, correct, ms, t, sess); console.log(label.padEnd(34), 'tier=', st.tier); };
step('s1 intro right', true, 2000, 's1'); step('s1 2nd exposure right', true, 2000, 's1');
step('s2 right fast', true, 2000, 's2', 3*DAY);
step('s3 right fast', true, 2000, 's3', 7*DAY);
step('s4 first try WRONG (lapse)', false, 4000, 's4', 14*DAY);
step('s4 requeue right 1.2s', true, 1200, 's4');
