const { applyAnswer } = await import('/Users/nunosantos/Documents/Base/Music/new_music_app/src/services/drillScheduler.ts');
const DAY = 86400000; let t = Date.UTC(2026,9,1,9);
let st: any;
const step = (label: string, correct: boolean, ms: number, sess: string, dt = 3000) => { t += dt; st = applyAnswer(st, correct, ms, t, sess); console.log(label.padEnd(28), 'tier=', st.tier); };
// Item missed first try in each of 3 sessions (a day+ apart), right on requeue after feedback
step('s1 first try WRONG', false, 5000, 's1');
step('s1 requeue right 1.2s', true, 1200, 's1');
step('s2 first try WRONG', false, 5000, 's2', 3*DAY);
step('s2 requeue right 1.2s', true, 1200, 's2');
step('s3 first try WRONG', false, 5000, 's3', 7*DAY);
step('s3 requeue right 1.2s', true, 1200, 's3');
console.log('final tier (history):', st.tier, JSON.stringify(st.history.map((h:any)=>[h.sessionId,h.correct,h.ms])));
