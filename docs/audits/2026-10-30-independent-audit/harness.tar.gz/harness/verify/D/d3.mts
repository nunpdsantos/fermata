const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src/';
const { generateAllForLevel } = await import(R + 'data/exercises/exerciseGenerator.ts');
const letters = ['C','D','E','F','G','A','B'];
const lpc: Record<string, number> = { C:0,D:2,E:4,F:5,G:7,A:9,B:11 };
// semitones -> expected interval number (letter steps), for the label graded
const numFor: Record<number, number[]> = {1:[2],2:[2],3:[3],4:[3],5:[4],6:[4,5],7:[5],8:[6],9:[6],10:[7],11:[7],12:[8]};
// displayed target: verbatim from ExercisePrompt.tsx:48-62
const NAT = ['C','C','D','D','E','F','F','G','G','A','A','B'];
const ACC = ['','#','','#','','','#','','#','','#',''];
let total=0, bad=0;
const rows:string[]=[];
for (let L=1; L<=9; L++) {
  const tpl = (await import(R+`data/exercises/templatesL${L}.ts`)).default;
  const gen = generateAllForLevel(tpl,'en');
  const auth = (await import(R+`data/exercises/exercisesL${L}.ts`)).default;
  for (const [src,map] of [['gen',gen],['auth',auth]] as const) for (const exs of Object.values(map) as any[]) for (const e of exs) {
    const c = e.config; if (c.type!=='interval_id') continue; total++;
    let rp = lpc[c.root] + (c.rootAccidental==='#'?1:c.rootAccidental==='b'?-1:0);
    const s = c.direction==='descending' ? -c.targetSemitones : c.targetSemitones;
    const tpc = (((rp+s)%12)+12)%12;
    const shown = NAT[tpc];
    const steps = (numFor[c.targetSemitones]||[]).map(n=>n-1);
    const ri = letters.indexOf(c.root);
    const dir = c.direction==='descending' ? -1 : 1;
    const okLetters = steps.map(st => letters[((ri + dir*st)%7+7)%7]);
    const hasAcc = ACC[tpc] === '#';
    const okSet = okLetters.includes(shown);
    if (!okSet) { bad++; rows.push(`${src}:${e.id} root=${c.root}${c.rootAccidental||''} dir=${c.direction||'asc'} st=${c.targetSemitones} shown=${shown}${ACC[tpc]} expectedLetter=${okLetters.join('/')} | ${e.prompt}`);}
  }
}
console.log('total',total,'letter-inconsistent',bad);
rows.forEach(r=>console.log(r));
