import { generateDrillBank } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/utils/drillBank/index.ts';
import { writeFileSync } from 'fs';
const bank = generateDrillBank();
writeFileSync(process.argv[2], JSON.stringify(bank, null, 1));
console.log(bank.length);
