// Independent check of D-4: drive the REAL store from startSession (no hand-built queue) with Triads only,
// answer through the real DrillView UI, miss only the last queue item, then try to answer the repeat.
import { describe, it, expect, afterEach } from 'vitest';
import * as React from '/Users/nunosantos/Documents/Base/Music/new_music_app/node_modules/react/index.js';
import { render, screen, fireEvent, act, cleanup } from '/Users/nunosantos/Documents/Base/Music/new_music_app/node_modules/@testing-library/react/dist/index.js';
import { DrillView } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/views/DrillView.tsx';
import { useDrillStore } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/state/drillStore.ts';
import { generateDrillBank } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/utils/drillBank/index.ts';
import { LazyMotion, domAnimation } from '/Users/nunosantos/Documents/Base/Music/new_music_app/node_modules/framer-motion/dist/es/index.mjs';

const bank = generateDrillBank();
const byId = new Map(bank.map((i: any) => [i.id, i]));
const sleep = (ms: number) => act(async () => { await new Promise((r) => setTimeout(r, ms)); });

describe('D-4 independent', () => {
  afterEach(() => cleanup());
  it('NoteChips item shown twice in a row: second showing ignores taps', async () => {
    // Settings: triads only
    const fam: any = Object.fromEntries(['keysig','circle','scale','degree','interval','triad','seventh','roman','function'].map((f) => [f, f === 'triad']));
    useDrillStore.setState({ items: {}, activeSession: null, settings: { ...useDrillStore.getState().settings, families: fam, sound: false } });
    const now = Date.UTC(2026, 9, 30, 9);
    useDrillStore.getState().startSession(bank, now);
    const q0 = useDrillStore.getState().activeSession!.queue;
    // Put a NoteChips item LAST by building a state equivalent to the store's own: answer q0 items via store API until the last one
    // (answers via store, correct), then render the UI on the last item and miss it through the UI.
    let t = now;
    for (let k = 0; ; k++) {
      const s = useDrillStore.getState().activeSession!;
      if (s.index >= s.queue.length - 1) break;
      t += 3000;
      useDrillStore.getState().recordAnswer(byId.get(s.queue[s.index]) as any, true, 2000, t);
    }
    const s0 = useDrillStore.getState().activeSession!;
    const lastId = s0.queue[s0.index];
    const lastItem: any = byId.get(lastId);
    console.log('queue len', s0.queue.length, 'index', s0.index, 'last id', lastId, 'format', lastItem.input.format);
    render(React.createElement(LazyMotion as any, { features: domAnimation }, React.createElement(DrillView)));
    // The UI may show whichever id it resolves; check what the DOM shows by reading the store's item after a deliberately wrong answer
    expect(lastItem.input.format).toBe('rootQuality');
    const ans = lastItem.answer; // {root:'C', quality:'minor'}
    const wrongRoot = ans.root; // keep root right, make QUALITY wrong
    fireEvent.click(screen.getByRole('button', { name: wrongRoot }));
    fireEvent.click(screen.getByRole('button', { name: 'Major' })); // answer is Minor
    const s1 = useDrillStore.getState().activeSession!;
    const settingsLen = useDrillStore.getState().settings.length;
    console.log('after UI miss: asked', s1.asked, 'index', s1.index, 'queue len', s1.queue.length, 'next id === prev id?', s1.queue[s1.index] === lastId, 'complete?', s1.asked >= settingsLen || s1.index >= s1.queue.length);
    expect(s1.asked).toBe(s0.asked + 1);
    fireEvent.click(screen.getByRole('button', { name: 'Continue' }));
    // same item again; now answer CORRECTLY (root, then Minor)
    fireEvent.click(screen.getByRole('button', { name: wrongRoot }));
    fireEvent.click(screen.getByRole('button', { name: 'Minor' }));
    await sleep(50);
    const s2 = useDrillStore.getState().activeSession!;
    console.log('after correct retry taps: asked', s2.asked, '(was', s1.asked + ')');
    expect(s2.asked).toBe(s1.asked + 1);
  });
});
