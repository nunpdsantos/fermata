import base from '/Users/nunosantos/Documents/Base/Music/new_music_app/vitest.config.ts';
const here = '/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/verify/D/vt';
export default {
  ...base,
  root: '/Users/nunosantos/Documents/Base/Music/new_music_app',
  server: { fs: { strict: false, allow: ['/'] } },
  test: { ...(base as any).test, dir: here, include: ['src/__tests__/**/*.test.{ts,tsx}'] },
};
