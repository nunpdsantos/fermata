import json,re,collections
b=json.load(open('/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/verify/D/bank.json'))
L='CDEFGAB'; PC={'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}
ACC={'':0,'♯':1,'♭':-1,'𝄪':2,'𝄫':-2,'#':1,'b':-1,'##':2,'bb':-2}
def P(s):
    l=s[0]; a=s[1:]
    return (l, ACC[a])
def pc(n): return (PC[n[0]]+n[1])%12
def above(n, steps, semis):
    l=L[(L.index(n[0])+steps)%7]
    target=(pc(n)+semis)%12
    d=(target-PC[l])%12
    if d>6: d-=12
    return (l,d)
def fmt(n): return n[0]+{0:'',1:'♯',-1:'♭',2:'𝄪',-2:'𝄫'}[n[1]]
# interval table name -> (steps, semis)
IV={'minor 2nd':(1,1),'major 2nd':(1,2),'minor 3rd':(2,3),'major 3rd':(2,4),'perfect 4th':(3,5),'perfect 5th':(4,7),'minor 6th':(5,8),'major 6th':(5,9),'minor 7th':(6,10),'major 7th':(6,11),'Minor 2nd':(1,1),'Major 2nd':(1,2),'Minor 3rd':(2,3),'Major 3rd':(2,4),'Perfect 4th':(3,5),'Perfect 5th':(4,7),'Minor 6th':(5,8),'Major 6th':(5,9),'Minor 7th':(6,10),'Major 7th':(6,11)}
bad=[]
n_chk=collections.Counter()
for it in b:
    pk=it['promptKey']; pp=it['promptParams']; a=it['answer']
    if pk=='drill.prompts.noteAbove':
        r=P(pp['root'].replace('♯','♯')); st,sm=IV[pp['interval']]
        exp=fmt(above(r,st,sm)); n_chk['noteAbove']+=1
        if a['correct']!=exp: bad.append((it['id'],a['correct'],exp))
    elif pk=='drill.prompts.pairToName':
        lo=P(pp['lower']); hi=P(pp['upper']); steps=(L.index(hi[0])-L.index(lo[0]))%7; semis=(pc(hi)-pc(lo))%12
        exp=[k for k,v in IV.items() if v==(steps,semis) and k[0].isupper()]
        n_chk['pair']+=1
        if not (a['correct'] in exp or (steps==0 and semis==0)):
            bad.append((it['id'],a['correct'],exp))
    elif pk=='drill.prompts.spellChord' and a['kind']=='notes':
        n_chk['spellChord']+=1
    elif pk=='drill.prompts.circle': pass
print(n_chk, 'bad', len(bad)); print(bad[:10])
# triad / seventh name-to-notes: verify against formulas by letters
TRI={'major':[(2,4),(4,7)],'minor':[(2,3),(4,7)],'diminished':[(2,3),(4,6)],'augmented':[(2,4),(4,8)]}
SEV={'major7':[(2,4),(4,7),(6,11)],'dominant7':[(2,4),(4,7),(6,10)],'minor7':[(2,3),(4,7),(6,10)],'half_diminished7':[(2,3),(4,6),(6,10)],'diminished7':[(2,3),(4,6),(6,9)]}
bad2=[]; cnt=0
for it in b:
    m=re.match(r'(triad|seventh):name-to-notes:([A-G][#b]?):(\w+)$',it['id'])
    if not m: continue
    cnt+=1
    root=P(m.group(2)); q=m.group(3); tbl=TRI.get(q) or SEV.get(q)
    exp=[root]+[above(root,s,m_) for s,m_ in tbl]
    got=[P(n) for n in it['answer']['notes']]
    if got!=exp: bad2.append((it['id'],got,exp))
print('chord spelling checked',cnt,'bad',len(bad2),bad2[:5])
# scales
SC={'major':[2,2,1,2,2,2,1],'natural_minor':[2,1,2,2,1,2,2],'harmonic_minor':[2,1,2,2,1,3,1],'melodic_minor':[2,1,2,2,2,2,1]}
bad3=[];cnt=0
for it in b:
    m=re.match(r'scale:spell:([A-Ga-g][#b]?):(\w+)$',it['id'])
    if not m: continue
    cnt+=1
    g=m.group(1); root=P(g[0].upper()+g[1:]); steps=SC[m.group(2)]
    exp=[root]; cur=pc(root); 
    for i,s in enumerate(steps[:-1]):
        cur=(cur+s)%12
        l=L[(L.index(root[0])+i+1)%7]; d=(cur-PC[l])%12
        if d>6:d-=12
        exp.append((l,d))
    got=[P(n) for n in it['answer']['spelled']]
    if got!=exp: bad3.append((it['id'],got,exp))
print('scale spelling checked',cnt,'bad',len(bad3),bad3[:5])
