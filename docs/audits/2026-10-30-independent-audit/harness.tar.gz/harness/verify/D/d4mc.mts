const mem = new Map<string, string>();
(globalThis as any).localStorage = { getItem: (k: string) => mem.get(k) ?? null, setItem: (k: string, v: string) => mem.set(k, v), removeItem: (k: string) => mem.delete(k) };
const { useDrillStore, isSessionComplete } = await import('/Users/nunosantos/Documents/Base/Music/new_music_app/src/state/drillStore.ts');
const { generateDrillBank } = await import('/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/utils/drillBank/index.ts');
const bank = generateDrillBank();
const byId = new Map(bank.map((i: any) => [i.id, i]));
const S = () => useDrillStore.getState();
const ALL = ['keysig','circle','scale','degree','interval','triad','seventh','roman','function'];
// simple deterministic rng
function rng(seed: number) { let a = seed >>> 0; return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

function runLearner(enabled: string[], p: number, nSessions: number, seed: number, newPer = 4, length: 12|24|40 = 24) {
  S().resetDrillProgress?.(); useDrillStore.setState({ items: {}, activeSession: null, lifetime: {answered:0,correct:0} });
  const fam: any = Object.fromEntries(ALL.map((f) => [f, enabled.includes(f)]));
  S().updateSettings({ families: fam, newPerSession: newPer, length });
  const r = rng(seed);
  let now = Date.UTC(2026, 9, 1, 9, 0, 0);
  const events: { session: number; fmt: string }[] = [];
  for (let sess = 1; sess <= nSessions; sess++) {
    S().startSession(bank, now);
    let guard = 0;
    while (S().activeSession && !isSessionComplete(S().activeSession!, S().settings) && guard++ < 200) {
      const s = S().activeSession!;
      const id = s.queue[s.index];
      const prev = s.index > 0 ? s.queue[s.index - 1] : null;
      const item: any = byId.get(id);
      if (!item) break;
      if (id === prev) events.push({ session: sess, fmt: item.input.format });
      const correct = r() < p;
      now += 4000;
      S().recordAnswer(item, correct, 2500, now);
    }
    S().endSession();
    now += 24 * 3600 * 1000;
  }
  return events;
}
const scen: [string, string[], number, number][] = [
  ['defaults(all families) p=.7 15 sessions', ALL, 0.7, 15],
  ['defaults(all families) p=.7 100 sessions', ALL, 0.7, 100],
  ['triad only p=.7 15 sessions', ['triad'], 0.7, 15],
  ['triad only p=.85 15 sessions', ['triad'], 0.85, 15],
  ['seventh only p=.7 15 sessions', ['seventh'], 0.7, 15],
  ['triad+seventh+scale p=.7 15 sessions', ['triad','seventh','scale'], 0.7, 15],
  ['scale only p=.7 15 sessions', ['scale'], 0.7, 15],
  ['degree only p=.7 15 sessions', ['degree'], 0.7, 15],
];
const N = 200;
for (const [name, en, p, ns] of scen) {
  let learnersWithAny = 0, learnersWithNonChoice = 0, totalNonChoice = 0, firstSessSum = 0;
  for (let k = 0; k < N; k++) {
    const ev = runLearner(en, p, ns, 1000 + k);
    const nc = ev.filter((e) => e.fmt !== 'choice');
    if (ev.length) learnersWithAny++;
    if (nc.length) { learnersWithNonChoice++; firstSessSum += nc[0].session; }
    totalNonChoice += nc.length;
  }
  console.log(`${name}: learners w/ any adjacent dup ${learnersWithAny}/${N}; w/ NON-CHOICE (locking) dup ${learnersWithNonChoice}/${N}; mean first-lock session ${(firstSessSum/Math.max(1,learnersWithNonChoice)).toFixed(1)}; total lock events ${totalNonChoice}`);
}
