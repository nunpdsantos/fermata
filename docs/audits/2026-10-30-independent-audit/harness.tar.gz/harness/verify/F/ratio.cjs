function oklch2srgb(L,C,h){const a=C*Math.cos(h*Math.PI/180),b=C*Math.sin(h*Math.PI/180);
 const l_=L+0.3963377774*a+0.2158037573*b,m_=L-0.1055613458*a-0.0638541728*b,s_=L-0.0894841775*a-1.2914855480*b;
 const l=l_**3,m=m_**3,s=s_**3;
 const r=4.0767416621*l-3.3077115913*m+0.2309699292*s,g=-1.2684380046*l+2.6097574011*m-0.3413193965*s,bl=-0.0041960863*l-0.7034186147*m+1.7076147010*s;
 const enc=x=>{x=Math.max(0,Math.min(1,x));return x<=0.0031308?12.92*x:1.055*x**(1/2.4)-0.055};
 return [r,g,bl].map(enc).map(v=>Math.round(v*255));}
const lin=v=>{v/=255;return v<=0.04045?v/12.92:((v+0.055)/1.055)**2.4};
const lum=([r,g,b])=>0.2126*lin(r)+0.7152*lin(g)+0.0722*lin(b);
const ratio=(a,b)=>{const x=lum(a),y=lum(b);return (Math.max(x,y)+0.05)/(Math.min(x,y)+0.05)};
const hex=h=>[1,3,5].map(i=>parseInt(h.slice(i,i+2),16));
const bg=hex('#f5efe2'), card=hex('#ede4cf'), cardHover=hex('#e4d9bf');
const cols={'emerald-300':[0.845,0.143,164.978],'red-300':[0.808,0.114,19.571],'amber-300':[0.879,0.169,91.605],'emerald-400':[0.765,0.177,163.223],'amber-400':[0.828,0.189,84.429]};
for(const [k,v] of Object.entries(cols)){const rgb=oklch2srgb(...v);console.log(k,'rgb',rgb.join(','),'on bg',ratio(rgb,bg).toFixed(2),'on card',ratio(rgb,card).toFixed(2));}
// amber-400/80 (#fcbb00cc) over bg
const a=0.8, fc=[0xfc,0xbb,0x00]; const comp=fc.map((c,i)=>Math.round(c*a+bg[i]*(1-a))); console.log('amber-400/80 over bg',comp.join(','),ratio(comp,bg).toFixed(2));
// AMBER #FBBF24 on card
console.log('#FBBF24 on card',ratio(hex('#FBBF24'),card).toFixed(2),'on bg',ratio(hex('#FBBF24'),bg).toFixed(2));
// text-dim
console.log('text-dim #8b7551 on bg',ratio(hex('#8b7551'),bg).toFixed(2),'on card',ratio(hex('#8b7551'),card).toFixed(2),'on cardHover',ratio(hex('#8b7551'),cardHover).toFixed(2));
// green tinted container: emerald-500/10 over bg
const e500=oklch2srgb(0.696,0.17,162.48); const cont=e500.map((c,i)=>Math.round(c*0.1+bg[i]*0.9)); const e300=oklch2srgb(...cols['emerald-300']);
console.log('emerald-300 on emerald-500/10 composite',ratio(e300,cont).toFixed(2));
console.log('sanity black/white',ratio([0,0,0],[255,255,255]).toFixed(2));
