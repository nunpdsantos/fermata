const fs=require('fs');
const css=fs.readFileSync('dist/assets/'+fs.readdirSync('dist/assets').find(f=>/^index-.*\.css$/.test(f)),'utf8');
function grab(re){const m=css.match(re);return m?m[0]:null}
for (const c of ['emerald-300','red-300','amber-300','emerald-400','red-400','amber-400']) {
  console.log(c, grab(new RegExp('--color-'+c+':[^;]*')), '|', grab(new RegExp('\\.text-'+c+'\\{[^}]*\\}')));
}
console.log(grab(/\.text-amber-400\\\/80\{[^}]*\}/));
const root=css.match(/:root\{[^}]*\}/g)||[];
root.forEach(r=>{ if(/--bg|--card|--text/.test(r)) console.log(r.slice(0,1200)); });
console.log('theme-specific overrides of colour utilities:', (css.match(/fermata-night[^{]*text-(emerald|red|amber)/g)||[]).length);
