// Independent variant: which ear modes lose auto-play, as a function of when the learner moves on?
import { appendFileSync } from 'node:fs';
import { describe, it, expect, vi, afterEach, beforeEach } from 'vitest';
import { render, screen, fireEvent, cleanup, act } from '@testing-library/react';
const SRC = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
vi.mock('/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/services/audio', async (orig) => {
  const o = await orig<Record<string, unknown>>();
  return { ...o, resumeAudio: vi.fn().mockResolvedValue(undefined), playNote: vi.fn(), playChord: vi.fn(), playScale: vi.fn() };
});
import { ExerciseRunner } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/components/learn/exercises/ExerciseRunner';
import * as audio from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/services/audio';

const mk = (id: string, cfg: Record<string, unknown>) => ({ id, type: 'ear_training', prompt: 'q', points: 1,
  config: { type: 'ear_training', choices: [{ label: 'A1', correct: true }, { label: 'B2', correct: false }], ...cfg } }) as never;
const modes: Record<string, [Record<string, unknown>, 'playChord' | 'playScale' | 'playNote']> = {
  progression: [{ mode: 'progression', root: 'C', rootAccidental: '', progression: ['I', 'IV', 'V', 'I'] }, 'playChord'],
  scale: [{ mode: 'scale', root: 'C', rootAccidental: '', scaleType: 'major', rootOctave: 4 }, 'playScale'],
  chord: [{ mode: 'chord', chordRoot: 'C', chordRootAccidental: '', quality: 'major' }, 'playChord'],
  note: [{ mode: 'note', note: 'C', accidental: '', octave: 4 }, 'playNote'],
};
async function tick(ms: number) { await act(async () => { await vi.advanceTimersByTimeAsync(ms); }); }
beforeEach(() => vi.useFakeTimers());
afterEach(() => { cleanup(); vi.clearAllMocks(); vi.useRealTimers(); });

async function run(mode: string, answerAt: number) {
  const [cfg, fn] = modes[mode];
  render(<ExerciseRunner exercises={[mk('e1', cfg), mk('e2', cfg)]} accentColor="#8b5cf6" onRecordResult={vi.fn()} onComplete={vi.fn()} />);
  await tick(answerAt);
  fireEvent.click(screen.getByText(mode === 'note' ? 'C' : 'A1', { selector: 'button *, button' }));
  fireEvent.click(screen.getByText('Submit'));
  fireEvent.click(screen.getByText('Continue'));
  await tick(10_000);
  const calls = (audio as never as Record<string, { mock: { calls: unknown[] } }>)[fn].mock.calls.length;
  return calls;
}
describe('ear autoplay on 2nd exercise, per mode', () => {
  for (const [mode, perExercise] of [['progression', 4], ['scale', 1], ['chord', 1], ['note', 1]] as const) {
    for (const t of [500, 1500, 3000, 4600]) {
      it(`${mode} answered at ${t}ms`, async () => {
        const n = await run(mode, t);
        appendFileSync('../ear-results.txt', `RESULT ${mode} answerAt=${t}ms calls=${n} expected=${2 * perExercise} ${n === 2 * perExercise ? 'OK' : 'SILENT-2ND'}\n`);
        expect(n).toBeGreaterThan(0);
      });
    }
  }
});
