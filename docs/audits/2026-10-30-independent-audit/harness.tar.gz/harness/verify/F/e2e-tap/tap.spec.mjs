import { test, chromium, devices } from '/Users/nunosantos/Documents/Base/Music/new_music_app/node_modules/@playwright/test/index.mjs';
const BASE = 'http://localhost:4299';
for (const holdMs of [40, 120]) {
test(`quick touch tap hold=${holdMs}ms on real build, default Chrome autoplay policy`, async () => {
  const browser = await chromium.launch({ args: ['--autoplay-policy=document-user-activation-required'] });
  const ctx = await browser.newContext({ ...devices['Pixel 7'], hasTouch: true });
  const page = await ctx.newPage();
  await page.addInitScript(() => {
    window.__log = [];
    const t0 = () => Math.round(performance.now());
    const L = (m) => window.__log.push(t0() + ' ' + m);
    const origResume = AudioContext.prototype.resume;
    AudioContext.prototype.resume = function () { L('ctx.resume() called state=' + this.state); return origResume.call(this).then((v) => { L('ctx.resume() resolved state=' + this.state); return v; }); };
    for (const P of [AudioBufferSourceNode.prototype, OscillatorNode.prototype]) {
      const n = P === AudioBufferSourceNode.prototype ? 'bufsrc' : 'osc';
      const s = P.start, p = P.stop;
      P.start = function (...a) { L(n + '.start'); return s.apply(this, a); };
      P.stop = function (...a) { L(n + '.stop'); return p.apply(this, a); };
    }
    for (const ev of ['pointerdown', 'pointerup', 'touchstart', 'touchend']) window.addEventListener(ev, () => L('EVENT ' + ev), true);
  });
  await page.goto(BASE + '/');
  await page.waitForTimeout(3500); // idle preload + sample decode
  await page.evaluate(() => { window.__log.push('---- before tap ----'); });
  const key = page.getByRole('button', { name: /^C4$/ }).first();
  const box = await key.boundingBox();
  const x = box.x + box.width / 2, y = box.y + box.height * 0.8;
  const cdp = await ctx.newCDPSession(page);
  await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x, y }] });
  await page.waitForTimeout(holdMs);
  await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
  await page.waitForTimeout(1500);
  const log = await page.evaluate(() => window.__log);
  console.log(`=== hold ${holdMs}ms\n` + log.join('\n'));
  await browser.close();
});
}
