import { defineConfig } from '/Users/nunosantos/Documents/Base/Music/new_music_app/node_modules/@playwright/test/index.mjs';
export default defineConfig({
  testDir: '/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/verify/F/e2e-tap',
  testMatch: /.*\.spec\.mjs/, timeout: 60000, workers: 1, retries: 0, reporter: 'list',
  outputDir: '/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/verify/F/pw-results',
  webServer: { command: 'npx vite preview --port 4299 --strictPort', cwd: '/Users/nunosantos/Documents/Base/Music/new_music_app', url: 'http://localhost:4299', reuseExistingServer: false, timeout: 60000 },
});
