import { getScalePositions } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/constants/guitarScalePositions.ts';
const N = (s: string) => ({ natural: s[0], accidental: s.slice(1) }) as any;
for (const [r, t] of [['A','pentatonic_minor'], ['C','major'], ['A','natural_minor']] as const) {
  const ps = getScalePositions(N(r), t);
  console.log(r, t);
  ps.forEach((p, i) => {
    const frets = p.position.notes.map(n => p.baseFret + n.fret);
    console.log('  chip', i + 1, p.position.name, 'base', p.baseFret, 'span', p.position.fretSpan, 'notes at abs frets', Math.min(...frets), '-', Math.max(...frets));
  });
}
