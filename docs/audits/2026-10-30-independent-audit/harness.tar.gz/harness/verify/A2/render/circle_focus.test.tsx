import './setup.ts';
import { it, vi } from 'vitest';
import { render, cleanup } from '@testing-library/react';
import { writeFileSync } from 'node:fs';
vi.mock('/Users/nunosantos/Documents/Base/Music/new_music_app/src/hooks/useAudio.ts', () => ({ useAudio: () => ({ noteOn: vi.fn().mockResolvedValue(60), noteOff: vi.fn() }) }));
import { CircleOfFifths } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/components/theory/CircleOfFifths.tsx';
import { useAppStore } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/state/store.ts';
const L: string[] = [];
it('circle focus', () => {
  for (const [nat, acc, scale] of [['A','', 'natural_minor'], ['E','', 'major'], ['D','b','major'], ['C','','major']] as const) {
    useAppStore.setState({ selectedKey: { natural: nat, accidental: acc } as any, selectedScale: scale as any, selectedChord: null, activeNotes: new Set(), exerciseInputActive: false });
    const { container } = render(<CircleOfFifths />);
    const ae = document.activeElement as Element | null;
    const texts = [...container.querySelectorAll('svg text')].map((t) => t.textContent).filter((t) => t && t.length > 0 && t.length < 40);
    L.push(`${nat}${acc} ${scale}: activeElement aria-label=${ae?.getAttribute('aria-label')}; centre texts (last 4)= ${JSON.stringify(texts.slice(-4))}`);
    cleanup();
  }
  writeFileSync('/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/verify/A2/out_circle_focus.txt', L.join('\n'));
});
