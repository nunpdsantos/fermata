import { buildChord } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/constants/chords.ts';
import { getChordShapesWithFallback } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/constants/guitarChordShapes.ts';
const N = (s: string) => ({ natural: s[0], accidental: s.slice(1) }) as any;
for (const [r, q] of [['D','major6'],['Db','major6'],['G','augmented7'],['F','add11'],['G','major7'],['A','major6']] as const) {
  const shapes = getChordShapesWithFallback(buildChord(N(r), q as any));
  const pos = ({ shape, baseFret }: any) => { let m = Infinity; for (const p of shape.strings) if (p.fret !== null) { const a = baseFret + p.fret; if (a > 0) m = Math.min(m, a); } return m === Infinity ? 0 : m; };
  const sorted = [...shapes].sort((a: any, b: any) => pos(a) - pos(b));
  console.log(r, q, 'count', sorted.length);
  sorted.slice(0, 3).forEach((s: any, i: number) => console.log('  ', i, s.shape.name, '@', s.baseFret, s.shape.strings.map((p: any) => p.fret === null ? 'x' : s.baseFret + p.fret).join(','), 'fingers', s.shape.strings.map((p: any) => p.finger ?? '-').join(','), JSON.stringify(s.shape.barreInfo)));
}
