import { getScalePositions } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/constants/guitarScalePositions.ts';
import { buildScale } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/constants/scales.ts';
const N = (s: string) => ({ natural: s[0], accidental: s.slice(1) }) as any;
for (const r of ['F##', 'G', 'C']) console.log(r, 'locrian base frets', getScalePositions(N(r), 'locrian').map(p => p.baseFret));
// Which double-accidental roots can the chord-grid yield (diatonic chords for selectable key x scale)?
const KS = ['C','C#','D','Eb','E','F','F#','G','Ab','A','Bb','B'];
const set = new Set<string>();
import { getDiatonicChordsForScale, buildChord } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/constants/chords.ts';
import { SCALE_FORMULAS } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/constants/scales.ts';
for (const t of Object.keys(SCALE_FORMULAS)) for (const r of KS) { try { for (const dc of getDiatonicChordsForScale(buildScale(N(r), t as any))) if (dc.chord.root.accidental.length === 2) set.add(dc.chord.root.natural + dc.chord.root.accidental); } catch {} }
console.log('double-accidental chord roots reachable from diatonic grid:', set.size, [...set].join(' '));
