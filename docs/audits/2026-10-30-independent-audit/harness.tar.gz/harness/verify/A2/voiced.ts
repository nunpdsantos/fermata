import { buildChord } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/constants/chords.ts';
import { getVoicedChordNotes } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/utils/pianoLayout.ts';
const N = (s: string) => ({ natural: s[0], accidental: s.slice(1) }) as any;
for (const [r, q, o] of [['F','major',1],['F','major',3],['C','major',3],['G','major',3],['A','minor',3]] as const)
  console.log(r, q, 'oct', o, getVoicedChordNotes(buildChord(N(r), q as any).notes, o).map(n => n.natural + n.accidental + n.octave).join(' '));
