import { buildScale } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/constants/scales.ts';
const N = (s: string) => ({ natural: s[0], accidental: s.slice(1) }) as any;
for (const [r, t] of [['C','diminished_half_whole'],['Eb','diminished_half_whole'],['C#','whole_tone'],['C#','blues'],['A','blues'],['C','pentatonic_major'],['C','chromatic']] as const)
  console.log(r, t, buildScale(N(r), t as any).notes.map(n => n.natural + n.accidental).join(' '));
