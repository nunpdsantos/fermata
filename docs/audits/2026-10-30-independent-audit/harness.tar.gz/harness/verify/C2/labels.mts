const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const ch = await import(R + '/core/constants/chords.ts');
for (const q of Object.keys(ch.CHORD_FORMULAS)) {
  const f = ch.CHORD_FORMULAS[q];
  console.log(q.padEnd(24), JSON.stringify(f).padEnd(34), ch.getChordShortIntervalLabels(q).join(' '), ' | ', ch.getChordIntervalLabels(q).join(', '));
}
