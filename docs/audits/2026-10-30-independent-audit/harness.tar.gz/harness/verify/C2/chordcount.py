# Independent count: chord stimuli from templatesL9 params; MIDI = 12 + 4*12 + pc(note)
pc={'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}
F={'major':[0,4,7],'minor':[0,3,7],'diminished':[0,3,6],'augmented':[0,4,8],
 'major7':[0,4,7,11],'minor7':[0,3,7,10],'dominant7':[0,4,7,10],'half_diminished7':[0,3,6,10],'diminished7':[0,3,6,9]}
sets=[('l9u30m2',['C','D','E','F','G','A'],['major','minor']),
('l9u31m4',list('CDEFGAB'),['major','minor','diminished','augmented']),
('l9u31m5',list('CDEFGAB'),['major7','minor7','dominant7','half_diminished7','diminished7'])]
tot=0;inv=0
for m,roots,qs in sets:
    mt=mi=0
    for r in roots:
        for q in qs:
            tones=[(pc[r]+s)%12 for s in F[q]]
            # played pitches: 60+pc each (all octave 4)
            midi=[60+t for t in tones]
            low=min(midi)
            mt+=1
            if low!=60+pc[r]: mi+=1
    print(m,mt,mi); tot+=mt; inv+=mi
print('template total',tot,'non-root bass',inv)
