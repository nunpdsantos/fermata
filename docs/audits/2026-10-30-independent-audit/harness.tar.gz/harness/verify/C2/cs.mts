const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const { CHORD_SCALE_MAP } = await import(R + '/core/constants/chordScaleRelationships.ts');
const { CHORD_FORMULAS } = await import(R + '/core/constants/chords.ts');
const { SCALE_FORMULAS } = await import(R + '/core/constants/scales.ts');
const mod = (n: number) => ((n % 12) + 12) % 12;
const cases: [string, string][] = [['sus4','pentatonic_major'],['sus2sus4','pentatonic_major'],['major7sharp11','lydian_dominant'],['major9sharp11','lydian_dominant'],['dominant13flat9','phrygian_dominant'],['dominant7sharp9','altered'],['dominant7sharp5','whole_tone'],['major7flat5','whole_tone'],['dominant7sharp11','whole_tone'],['dominant7sharp9','blues'],['dominant7sharp9','diminished_half_whole']];
for (const [q, sc] of cases) {
  const ct = CHORD_FORMULAS[q].map(mod); const S = new Set<number>(SCALE_FORMULAS[sc].map(mod));
  const missing = ct.filter((x: number) => !S.has(x));
  const clashes: string[] = [];
  for (const s of S) if (!ct.includes(s)) for (const c of ct) if (Math.abs(((s - c + 18) % 12) - 6) === 5 ) clashes.push(`${s}~${c}`);
  const entry = CHORD_SCALE_MAP[q].find((e: any) => e.scale === sc);
  console.log(q.padEnd(18), sc.padEnd(22), 'chord', JSON.stringify(ct), 'scale', JSON.stringify([...S]), 'missing', JSON.stringify(missing), 'semitone-clashes', JSON.stringify(clashes), '|', entry?.fit, '|', entry?.context);
}
console.log(JSON.stringify(CHORD_SCALE_MAP['dominant7sharp9'].map((e:any)=>e.scale+':'+e.fit)));
