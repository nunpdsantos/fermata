// Audit repro: the replay lock (playingRef) is shared across exercises, so answering an ear
// item before its playback window ends silently suppresses the NEXT ear item's autoplay.
import { describe, it, expect, vi, afterEach, beforeEach } from 'vitest';
import { render, screen, fireEvent, cleanup, act } from '@testing-library/react';
vi.mock('/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/services/audio.ts', async (importOriginal) => {
  const original = await importOriginal<any>();
  return { ...original, resumeAudio: vi.fn().mockResolvedValue(undefined), playNote: vi.fn(), playChord: vi.fn(), playScale: vi.fn() };
});
import { ExerciseRunner } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/components/learn/exercises/ExerciseRunner.tsx';
import { playScale } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/services/audio.ts';
const scaleEx = (id: string) => ({ id, type: 'ear_training' as const, prompt: 'Listen to this scale and identify its type.',
  config: { type: 'ear_training' as const, mode: 'scale' as const, root: 'C', rootAccidental: '', rootOctave: 4, scaleType: 'major',
    choices: [{ label: 'Major', correct: true }, { label: 'Natural minor', correct: false }] }, points: 1 });
async function tick(ms: number) { await act(async () => { vi.advanceTimersByTime(ms); await Promise.resolve(); }); }
describe('ear autoplay across exercises', () => {
  beforeEach(() => vi.useFakeTimers());
  afterEach(() => { vi.useRealTimers(); cleanup(); vi.clearAllMocks(); });
  it('CONTROL: waiting out the first scale (3.4 s) lets the second autoplay', async () => {
    render(<ExerciseRunner exercises={[scaleEx('a'), scaleEx('b')]} accentColor="#888" onRecordResult={vi.fn()} onComplete={vi.fn()} />);
    await tick(300); expect(playScale).toHaveBeenCalledTimes(1);
    await tick(3200);
    fireEvent.click(screen.getByText('Major')); fireEvent.click(screen.getByText('Submit')); fireEvent.click(screen.getByText('Continue'));
    await tick(300);
    expect(playScale).toHaveBeenCalledTimes(2);
  });
  it('BUG: answering after 1.5 s (scale still sounding) => next exercise never autoplays', async () => {
    render(<ExerciseRunner exercises={[scaleEx('a'), scaleEx('b')]} accentColor="#888" onRecordResult={vi.fn()} onComplete={vi.fn()} />);
    await tick(300); expect(playScale).toHaveBeenCalledTimes(1);
    await tick(1500);
    fireEvent.click(screen.getByText('Major')); fireEvent.click(screen.getByText('Submit')); fireEvent.click(screen.getByText('Continue'));
    await tick(300);
    // correct behaviour would be 2 (new exercise autoplays); record what actually happens
    console.log('playScale calls after next exercise autoplay window:', (playScale as any).mock.calls.length);
    await tick(5000);
    console.log('playScale calls 5 s later (no further autoplay attempt is scheduled):', (playScale as any).mock.calls.length);
    expect((playScale as any).mock.calls.length).toBe(1);
  });

  it('HUMAN-LATENCY: reaction 2.2 s after audio start + 0.5 s submit + 0.5 s continue', async () => {
    render(<ExerciseRunner exercises={[scaleEx('a'), scaleEx('b')]} accentColor="#888" onRecordResult={vi.fn()} onComplete={vi.fn()} />);
    await tick(300); expect(playScale).toHaveBeenCalledTimes(1);
    await tick(2200);
    fireEvent.click(screen.getByText('Major')); await tick(500);
    fireEvent.click(screen.getByText('Submit')); await tick(500);
    fireEvent.click(screen.getByText('Continue'));
    await tick(300);
    await tick(5000);
    console.log('HUMAN-LATENCY playScale calls total:', (playScale as any).mock.calls.length);
  });
  it('HUMAN-LATENCY-SLOW: reaction 3.5 s', async () => {
    render(<ExerciseRunner exercises={[scaleEx('a'), scaleEx('b')]} accentColor="#888" onRecordResult={vi.fn()} onComplete={vi.fn()} />);
    await tick(300); expect(playScale).toHaveBeenCalledTimes(1);
    await tick(3500);
    fireEvent.click(screen.getByText('Major')); await tick(500);
    fireEvent.click(screen.getByText('Submit')); await tick(500);
    fireEvent.click(screen.getByText('Continue'));
    await tick(300);
    await tick(5000);
    console.log('SLOW playScale calls total:', (playScale as any).mock.calls.length);
  });

  it('FAST-HUMAN: 1.0 s reaction + 0.4 + 0.4', async () => {
    render(<ExerciseRunner exercises={[scaleEx('a'), scaleEx('b')]} accentColor="#888" onRecordResult={vi.fn()} onComplete={vi.fn()} />);
    await tick(300); expect(playScale).toHaveBeenCalledTimes(1);
    await tick(1000);
    fireEvent.click(screen.getByText('Major')); await tick(400);
    fireEvent.click(screen.getByText('Submit')); await tick(400);
    fireEvent.click(screen.getByText('Continue'));
    await tick(300); await tick(5000);
    console.log('FAST-HUMAN playScale calls total:', (playScale as any).mock.calls.length);
  });
  it('MID-HUMAN: 2.0 s reaction + 0.4 + 0.4 (continue at 2.8s after audio start)', async () => {
    render(<ExerciseRunner exercises={[scaleEx('a'), scaleEx('b')]} accentColor="#888" onRecordResult={vi.fn()} onComplete={vi.fn()} />);
    await tick(300); expect(playScale).toHaveBeenCalledTimes(1);
    await tick(2000);
    fireEvent.click(screen.getByText('Major')); await tick(400);
    fireEvent.click(screen.getByText('Submit')); await tick(400);
    fireEvent.click(screen.getByText('Continue'));
    await tick(300); await tick(5000);
    console.log('MID-HUMAN playScale calls total:', (playScale as any).mock.calls.length);
  });
});
