import { defineConfig } from '/Users/nunosantos/Documents/Base/Music/new_music_app/node_modules/vitest/dist/config.js';
export default defineConfig({ cacheDir: '/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/verify/C2/vite-cache',
  root: '/Users/nunosantos/Documents/Base/Music/new_music_app',
  resolve: { alias: [
    { find: 'virtual:pwa-register', replacement: '/Users/nunosantos/Documents/Base/Music/new_music_app/src/test/stubs/pwa-register.ts' },
    { find: /^@testing-library\/react$/, replacement: '/Users/nunosantos/Documents/Base/Music/new_music_app/node_modules/@testing-library/react/dist/index.js' },
    { find: /^react\/jsx-dev-runtime$/, replacement: '/Users/nunosantos/Documents/Base/Music/new_music_app/node_modules/react/jsx-dev-runtime.js' },
    { find: /^react\/jsx-runtime$/, replacement: '/Users/nunosantos/Documents/Base/Music/new_music_app/node_modules/react/jsx-runtime.js' },
  ] },
  esbuild: { jsx: 'automatic' },
  server: { fs: { allow: ['/Users/nunosantos/Documents/Base/Music/new_music_app', '/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/C-learn-L6-L9-explore', '/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/verify/C2'] } },
  test: { include: ['/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/verify/C2/vt/*.test.tsx'], environment: 'jsdom', setupFiles: ['/Users/nunosantos/Documents/Base/Music/new_music_app/src/i18n/index.ts'] },
});
