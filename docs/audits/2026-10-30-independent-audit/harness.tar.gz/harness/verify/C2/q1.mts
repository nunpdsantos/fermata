const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const { parseScaleSymbol } = await import(R + '/core/utils/scaleParser.ts');
for (const q of ['C pentatonic scale','C pentatonic','C blues scale','C minor pentatonic','C whole tone scale','whole tone scale']) {
  const s = parseScaleSymbol(q);
  console.log(JSON.stringify(q), '->', s ? JSON.stringify(s) : null);
}
