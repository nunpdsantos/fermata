// CHECK: interval_id exercises — does the staff the app draws match the answer key?
// App display logic replicated verbatim from src/components/learn/exercises/ExercisePrompt.tsx:42-63
// App answer label = INTERVAL_LABELS[targetSemitones] (validateExercise.ts:108-113, exerciseHelpers.ts:19-21)
import { collect } from './collect.mts';
import { parseNote, fmt, intervalName, intervalNumber } from './oracle.mts';
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const { INTERVAL_LABELS } = await import(R + '/core/constants/chords.ts');

function appDisplay(cfg: any) { // === ExercisePrompt.tsx:43-63 ===
  const NATURALS = ['C', 'C', 'D', 'D', 'E', 'F', 'F', 'G', 'G', 'A', 'A', 'B'];
  const ACCIDENTALS = ['', '#', '', '#', '', '', '#', '', '#', '', '#', ''];
  const rootPCs: Record<string, number> = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };
  let rootPC = rootPCs[cfg.root] ?? 0;
  if (cfg.rootAccidental === '#') rootPC += 1;
  if (cfg.rootAccidental === 'b') rootPC -= 1;
  const semitones = cfg.direction === 'descending' ? -cfg.targetSemitones : cfg.targetSemitones;
  const targetPC = ((rootPC + semitones) % 12 + 12) % 12;
  const targetOct = cfg.rootOctave + (rootPC + semitones >= 12 ? 1 : rootPC + semitones < 0 ? -1 : 0);
  return { root: { n: cfg.root + (cfg.rootAccidental || ''), o: cfg.rootOctave }, target: { n: NATURALS[targetPC] + ACCIDENTALS[targetPC], o: targetOct } };
}

function judge(cfg: any) {
  const d = appDisplay(cfg);
  const r = parseNote(d.root.n)!, t = parseNote(d.target.n)!;
  const [lo, hi] = cfg.direction === 'descending' ? [t, r] : [r, t];
  const shown = intervalName(lo, hi, cfg.targetSemitones);
  const label = INTERVAL_LABELS[cfg.targetSemitones];
  // label consistent with shown notes?  Tritone accepted for Aug 4th / Dim 5th.
  const norm = (s: string) => s.replace(/^Perfect Octave$/, 'Octave');
  const ok = cfg.targetSemitones === 6 ? /Augmented 4th|Diminished 5th/.test(shown) : norm(shown) === label;
  return { d, shown, label, ok };
}

// ---- self-test: prove the check can fail and can pass ----
const pass = judge({ root: 'C', rootAccidental: '', rootOctave: 4, targetSemitones: 4, direction: 'ascending' });
const fail = judge({ root: 'C', rootAccidental: '', rootOctave: 4, targetSemitones: 3, direction: 'ascending' });
console.log('SELFTEST known-good C+4:', pass.ok ? 'PASS' : 'FAIL', '| known-bad C+3 (drawn D#):', fail.ok ? 'NOT CAUGHT' : 'CAUGHT');
if (!pass.ok || fail.ok) process.exit(2);

const { items } = await collect();
const iv = items.filter((i) => i.type === 'interval_id');
const rows: string[] = [];
const counts: Record<string, [number, number]> = {};
for (const it of iv) {
  const j = judge(it.config);
  const key = it.source;
  counts[key] ??= [0, 0];
  counts[key][0]++;
  if (!j.ok) {
    counts[key][1]++;
    rows.push(`${it.source.padEnd(9)} ${it.id.padEnd(16)} staff: ${j.d.root.n}${j.d.root.o} → ${j.d.target.n}${j.d.target.o} (${it.config.direction}) = ${j.shown.padEnd(18)} | app answer key: "${j.label}" | prompt: ${it.prompt.slice(0, 70)}`);
  }
}
// Prompt-named second note vs drawn note (e.g. "C up to Eb")
const named: string[] = [];
for (const it of iv.filter((i) => i.source !== 'space')) {
  const m = it.prompt.match(/\b([A-G][#b]?)\d?\s+(?:up\s+)?(?:by\s+)?to\s+([A-G][#b]?)(?![A-Za-z#])/);
  if (!m) continue;
  const j = judge(it.config);
  const a = parseNote(m[1])!, b = parseNote(m[2])!;
  const nm = intervalName(a, b, it.config.targetSemitones);
  const lbl = j.label;
  const okLbl = it.config.targetSemitones === 6 ? /Augmented 4th|Diminished 5th/.test(nm) : nm === lbl;
  named.push(`${it.id.padEnd(14)} prompt names ${m[1]}→${m[2]} = ${nm.padEnd(18)} | staff draws ${j.d.target.n} ${j.d.target.n === fmt(b) ? '(matches prompt)' : '(DIFFERS from prompt)'} | app key "${lbl}" ${okLbl ? 'OK' : 'WRONG for named notes'}`);
}
console.log('\n=== interval_id items whose drawn notes contradict the answer key ===');
for (const [k, [n, bad]] of Object.entries(counts)) console.log(`${k}: ${bad}/${n} inconsistent`);
console.log(rows.filter((r) => !r.startsWith('space')).join('\n'));
console.log('\n--- template space (every config the generator can emit), inconsistent ones:');
console.log(rows.filter((r) => r.startsWith('space')).length + ' rows; first 25:');
console.log(rows.filter((r) => r.startsWith('space')).slice(0, 25).join('\n'));
console.log('\n=== prompts that name both notes ===\n' + named.join('\n'));
