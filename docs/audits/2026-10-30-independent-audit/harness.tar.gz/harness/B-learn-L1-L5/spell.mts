const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const { PITCH_CLASS_SPELLINGS } = await import(R + '/core/constants/notes.ts');
console.log(PITCH_CLASS_SPELLINGS.map((s:any,i:number)=> i+':'+s.map((n:any)=>n.natural+n.accidental).join('/')).join('  '));
