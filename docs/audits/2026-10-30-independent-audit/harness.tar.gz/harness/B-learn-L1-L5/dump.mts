import { writeFileSync } from 'fs';
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const OUT = '/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/B-learn-L1-L5';
const { CURRICULUM_LEVELS } = await import(R + '/core/constants/levels.ts');
const { generateExercises } = await import(R + '/data/exercises/exerciseGenerator.ts');
for (const n of [1,2,3,4,5]) {
  const lvl = CURRICULUM_LEVELS.find((l:any)=>l.id==='l'+n);
  const ex = (await import(R + `/data/exercises/exercisesL${n}.ts`)).default;
  const tp = (await import(R + `/data/exercises/templatesL${n}.ts`)).default;
  let s = `# LEVEL ${n}: ${lvl.title}\n${lvl.description}\n`;
  for (const u of lvl.units) {
    s += `\n## UNIT ${u.id}: ${u.title} — ${u.description}\n`;
    if (u.milestone) s += `MILESTONE: ${JSON.stringify(u.milestone)}\n`;
    if (u.completionContent) s += `COMPLETION: ${JSON.stringify(u.completionContent)}\n`;
    for (const m of u.modules) {
      s += `\n### ${m.id} ${m.title} | ${m.subtitle} | prereq=${m.prerequisites.join(',')}\n`;
      m.objectives.forEach((o:string)=> s += `OBJ: ${o}\n`);
      m.concepts.forEach((c:any,i:number)=> s += `C${i}: [${c.title}] ${c.explanation} {try:${c.tryThisQuery}|${c.tryThisLabel}}${c.childDescription?' CHILD:'+c.childDescription:''}\n`);
      m.tasks.forEach((t:any)=> s += `T: ${t.instruction}${t.query?' {q:'+t.query+'}':''}\n`);
      const exs = ex[m.id] ?? [];
      exs.forEach((e:any)=> { const c={...e.config}; delete c.type; s += `EX ${e.id} <${e.type}> ${e.prompt} || ${JSON.stringify(c)} || H: ${e.hint??''}${e.points&&e.points!==1?' pts='+e.points:''}\n`; });
      const tc = tp.find((t:any)=>t.moduleId===m.id);
      if (tc) {
        s += `TEMPLATES target=${tc.targetCount}\n`;
        tc.templates.forEach((t:any,i:number)=> s += `  TPL${i} <${t.type}> P: ${t.promptTemplate} | H: ${t.hintTemplate} | ${JSON.stringify(t.params)}\n`);
        const g = generateExercises(tc);
        g.forEach((e:any)=> { const c={...e.config}; delete c.type; s += `  GEN ${e.id} <${e.type}> ${e.prompt} || ${JSON.stringify(c)} || H: ${e.hint}\n`; });
      } else s += `NO TEMPLATES\n`;
    }
  }
  // exercises keyed to modules not in level
  const ids = new Set(lvl.units.flatMap((u:any)=>u.modules.map((m:any)=>m.id)));
  for (const k of Object.keys(ex)) if (!ids.has(k)) s += `ORPHAN EXERCISE KEY ${k}\n`;
  for (const t of tp) if (!ids.has(t.moduleId)) s += `ORPHAN TEMPLATE ${t.moduleId}\n`;
  writeFileSync(`${OUT}/dump_L${n}.txt`, s);
  console.log(n, s.length);
}
