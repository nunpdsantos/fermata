// Independent music-theory oracle — written from first principles for this audit.
// Does NOT import any app module.
export const LETTERS = ['C', 'D', 'E', 'F', 'G', 'A', 'B'] as const;
export const LETTER_PC: Record<string, number> = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };
export type SN = { L: string; acc: number }; // spelled note: letter + accidental offset (-2..2)

export function parseNote(s: string): SN | null {
  const m = s.trim().replace('♯', '#').replace('♭', 'b').match(/^([A-G])(##|#|bb|b|x)?$/);
  if (!m) return null;
  const a = m[2] ?? '';
  const acc = a === '#' ? 1 : a === '##' || a === 'x' ? 2 : a === 'b' ? -1 : a === 'bb' ? -2 : 0;
  return { L: m[1], acc };
}
export function fmt(n: SN): string {
  return n.L + (n.acc === 1 ? '#' : n.acc === 2 ? '##' : n.acc === -1 ? 'b' : n.acc === -2 ? 'bb' : '');
}
export const pc = (n: SN) => (((LETTER_PC[n.L] + n.acc) % 12) + 12) % 12;
const li = (L: string) => LETTERS.indexOf(L as any);

/** Spell the note `steps` letters above `root` whose pitch is `semis` above root. */
export function above(root: SN, steps: number, semis: number): SN {
  const L = LETTERS[(li(root.L) + steps) % 7];
  const target = (pc(root) + semis) % 12;
  let acc = target - LETTER_PC[L];
  while (acc > 6) acc -= 12;
  while (acc < -6) acc += 12;
  return { L, acc };
}

// Scales as (step-pattern semitones from root), heptatonic, one letter per degree
export const SCALE_SEMIS: Record<string, number[]> = {
  major: [0, 2, 4, 5, 7, 9, 11],
  natural_minor: [0, 2, 3, 5, 7, 8, 10],
  harmonic_minor: [0, 2, 3, 5, 7, 8, 11],
  melodic_minor: [0, 2, 3, 5, 7, 9, 11], // ascending form
};
export function scale(root: SN, type: string): SN[] {
  const s = SCALE_SEMIS[type];
  if (!s) throw new Error('oracle: unknown scale ' + type);
  return s.map((semi, i) => above(root, i, semi));
}

// Chords as [letterSteps, semitones] per member
export const CHORD: Record<string, [number, number][]> = {
  major: [[0, 0], [2, 4], [4, 7]],
  minor: [[0, 0], [2, 3], [4, 7]],
  diminished: [[0, 0], [2, 3], [4, 6]],
  augmented: [[0, 0], [2, 4], [4, 8]],
  major7: [[0, 0], [2, 4], [4, 7], [6, 11]],
  dominant7: [[0, 0], [2, 4], [4, 7], [6, 10]],
  minor7: [[0, 0], [2, 3], [4, 7], [6, 10]],
  half_diminished7: [[0, 0], [2, 3], [4, 6], [6, 10]],
  diminished7: [[0, 0], [2, 3], [4, 6], [6, 9]],
  minor_major7: [[0, 0], [2, 3], [4, 7], [6, 11]],
  augmented_major7: [[0, 0], [2, 4], [4, 8], [6, 11]],
};
export function chord(root: SN, q: string): SN[] {
  const f = CHORD[q];
  if (!f) throw new Error('oracle: unknown chord ' + q);
  return f.map(([st, se]) => above(root, st, se));
}

/** Interval name between two spelled notes (lower → upper, simple interval). */
export function intervalName(lower: SN, upper: SN, semis: number): string {
  const num = ((li(upper.L) - li(lower.L)) % 7 + 7) % 7 + 1; // 1..7 (8 handled via semis)
  const n = semis >= 6 && num === 1 ? 8 : num;
  const perfect = [1, 4, 5, 8].includes(n);
  const ref: Record<number, number> = { 1: 0, 2: 2, 3: 4, 4: 5, 5: 7, 6: 9, 7: 11, 8: 12 };
  const diff = semis - ref[n];
  let q: string;
  if (perfect) q = diff === 0 ? 'Perfect' : diff === 1 ? 'Augmented' : diff === -1 ? 'Diminished' : diff > 1 ? 'Doubly-augmented' : 'Doubly-diminished';
  else q = diff === 0 ? 'Major' : diff === -1 ? 'Minor' : diff === 1 ? 'Augmented' : diff === -2 ? 'Diminished' : `?(${diff})`;
  const ord: Record<number, string> = { 1: 'Unison', 2: '2nd', 3: '3rd', 4: '4th', 5: '5th', 6: '6th', 7: '7th', 8: 'Octave' };
  return `${q} ${ord[n]}`;
}
export function intervalNumber(lower: SN, upper: SN, semis: number): number {
  const num = ((li(upper.L) - li(lower.L)) % 7 + 7) % 7 + 1;
  return semis >= 6 && num === 1 ? 8 : num;
}

/** Major key signature: count of sharps(+)/flats(−) from first principles (circle of fifths walk). */
export function majorKeySig(tonic: SN): { n: number; accs: string[] } {
  const s = scale(tonic, 'major');
  const sharps = s.filter((x) => x.acc > 0), flats = s.filter((x) => x.acc < 0);
  return sharps.length ? { n: sharps.reduce((a, x) => a + x.acc, 0), accs: sharps.map(fmt) } : { n: -flats.reduce((a, x) => a - x.acc, 0), accs: flats.map(fmt) };
}

/** Diatonic staff index: C4 = 0, D4 = 1 ... (letter steps from C4). */
export function staffIndex(L: string, octave: number): number {
  return (octave - 4) * 7 + li(L);
}
/** Clef staff geometry: bottom line index and top line index (staffIndex). */
export const CLEF = {
  treble: { bottom: staffIndex('E', 4), top: staffIndex('F', 5) },
  bass: { bottom: staffIndex('G', 2), top: staffIndex('A', 3) },
};
/** Number of ledger lines a note needs, and a description of its position. */
export function staffPos(L: string, octave: number, clef: 'treble' | 'bass') {
  const idx = staffIndex(L, octave);
  const { bottom, top } = CLEF[clef];
  if (idx >= bottom && idx <= top) {
    const off = idx - bottom; // 0 = line1, 1 = space1, ...
    return { ledger: 0, where: off % 2 === 0 ? `line ${off / 2 + 1}` : `space ${(off + 1) / 2}` };
  }
  if (idx < bottom) {
    const below = bottom - idx; // 1 = space below line1 (D4 in treble), 2 = 1st ledger line...
    return { ledger: Math.floor(below / 2), where: `below staff (${below} steps)` };
  }
  const aboveN = idx - top;
  return { ledger: Math.floor(aboveN / 2), where: `above staff (${aboveN} steps)` };
}
