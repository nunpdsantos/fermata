import { collect } from './collect.mts';
const { items } = await collect();
const accs = new Set(items.filter(i => ['interval_id','ear_training'].includes(i.type)).map(i => JSON.stringify(i.config.rootAccidental ?? i.config.accidental ?? '')));
console.log('root accidentals used by interval/ear items L1-L5:', [...accs].join(' '), '| planted check "##" in set?', accs.has('"##"'));
