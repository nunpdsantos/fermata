// First-principles derivations for prose claims (oracle only), plus what the app's
// Try-This chord parser actually builds for the slash symbols cited in L4 lessons.
import { parseNote as P, intervalName, chord, scale, fmt, pc, staffIndex, above } from './oracle.mts';
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const { parseChordSymbol, chordFromParsed } = await import(R + '/core/utils/chordParser.ts');
const say = (k: string, v: any) => console.log(k.padEnd(62), '→', v);

// 1. Tritone resolution direction (l3u9m3 C1 + task; l5u15m1 C1, C2, task 2)
say('G7: B up to F (B below F, as in G-B-D-F)', intervalName(P('B')!, P('F')!, 6));
say('…resolves B→C, F→E: C up to E', intervalName(P('C')!, P('E')!, 4) + '  ⇒ 5th→3rd = INWARD contraction');
say('D7: F# up to C (as in D-F#-A-C)', intervalName(P('F#')!, P('C')!, 6));
say('…resolves F#→G, C→B: G up to B', intervalName(P('G')!, P('B')!, 4) + '  ⇒ INWARD');
say('(outward only if inverted) F up to B', intervalName(P('F')!, P('B')!, 6) + ' → E up to C = ' + intervalName(P('E')!, P('C')!, 8));

// 2. l4u12m1e3: F held over a V chord (G bass) resolving to E
say('l4u12m1e3: interval G(bass) up to F', intervalName(P('G')!, P('F')!, 10));
say('l4u12m1e3: interval G(bass) up to E', intervalName(P('G')!, P('E')!, 9));
say('l4u12m1e3: is E a member of V = G major triad?', chord(P('G')!, 'major').map(fmt).join('-') + ' → ' + chord(P('G')!, 'major').some((n) => fmt(n) === 'E'));
say('real 4-3 over V: G up to C, then B', intervalName(P('G')!, P('C')!, 5) + ' → ' + intervalName(P('G')!, P('B')!, 4));

// 3. l3u11m1 C1: minor-key deceptive cadence, VI vs i common tones in A minor
const VI = chord(P('F')!, 'major').map(fmt), i = chord(P('A')!, 'minor').map(fmt);
say('A minor: VI = ' + VI.join('-') + ', i = ' + i.join('-') + '; common tones', VI.filter((n) => i.includes(n)).join(', ') + ' (count ' + VI.filter((n) => i.includes(n)).length + ')');

// 4. l3u10m1 task: Bass on C2 vs stated bass range E2–C4
say('C2 vs E2 (diatonic steps; negative = below)', staffIndex('C', 2) - staffIndex('E', 2) + ' steps ⇒ C2 is BELOW the stated E2 floor');

// 5. l4u13m2 task: "the major 7th interval (B to C)"
say('B up to C', intervalName(P('B')!, P('C')!, 1));
say('C up to B', intervalName(P('C')!, P('B')!, 11));

// 6. l5u17m4e2 hint: "G7: the C holds as common tone becoming the 7th … F drops to B (3rd)"
say('G7 members', chord(P('G')!, 'dominant7').map(fmt).join('-') + ' — contains C? ' + chord(P('G')!, 'dominant7').some((n) => fmt(n) === 'C'));
say('F to B (claimed "drops")', 'F down to B = ' + intervalName(P('B')!, P('F')!, 6) + ' (6 semitones; not a step)');
say('actual: Dm7 3rd F → G7 7th F; Dm7 7th C → G7 3rd B', 'C down to B = ' + intervalName(P('B')!, P('C')!, 1));

// 7. l3u9m4 task: "Compare the pattern to A major — notice how the raised G# changes…"
const Amaj = scale(P('A')!, 'major').map(fmt), Ahm = scale(P('A')!, 'harmonic_minor').map(fmt), Anm = scale(P('A')!, 'natural_minor').map(fmt);
say('A major vs A harmonic minor differ in', Amaj.filter((n) => !Ahm.includes(n)).join(',') + ' vs ' + Ahm.filter((n) => !Amaj.includes(n)).join(',') + ' (G# is in BOTH)');
say('A natural minor vs A harmonic minor differ in', Anm.filter((n) => !Ahm.includes(n)).join(',') + ' vs ' + Ahm.filter((n) => !Anm.includes(n)).join(','));

// 8. l5u16m5e3 vs l4u14m5 C0: major IV in A minor
const Amm = scale(P('A')!, 'melodic_minor').map(fmt);
say('A melodic minor ascending', Amm.join(' ') + ' — contains D, F#, A (major IV)? ' + ['D', 'F#', 'A'].every((n) => Amm.includes(n)));

// 9. l2u4m2 C0 submediant: where is degree 6 relative to tonic / mediant?
const C = scale(P('C')!, 'major').map(fmt);
say('C major: mediant (3) / submediant (6)', `${C[2]} is a 3rd ABOVE tonic; ${C[5]} is a 3rd BELOW tonic (A up to C = ${intervalName(P('A')!, P('C')!, 3)})`);

// 10. App's chord parser on the slash symbols used as V7-inversion demos (l4u12m5)
for (const s of ['G/D', 'G/B', 'G7/D', 'G7/B', 'G7/F']) {
  const p = parseChordSymbol(s);
  const c = p ? chordFromParsed(p) : null;
  say(`app parses "${s}"`, c ? `${c.notes.map((n: any) => n.natural + n.accidental).join('-')} bass=${c.bassNote ? c.bassNote.natural + c.bassNote.accidental : '-'} (has 7th F? ${c.notes.some((n: any) => n.natural === 'F' && n.accidental === '')})` : 'unparsed');
}

// 11. l1u3m4e3 distractor "minor 5th (6 semitones)" — what is 6 semitones over a 5th-letter span?
say('C up to Gb (5 letters, 6 semitones)', intervalName(P('C')!, P('Gb')!, 6) + ' — "minor 5th" is not an interval quality for 5ths');

// 12. l2u7m3e4: tritone content of dim vs aug triads (both triads have an altered 5th)
say('C dim: C→Gb', intervalName(P('C')!, P('Gb')!, 6) + ' | C aug: C→G# ' + intervalName(P('C')!, P('G#')!, 8));

// 13. l5u17m4 C0 "the 3rd and 7th ARE the chord's identity … Everything else is color"
const gt = (q: string) => { const c = chord(P('C')!, q).map(fmt); return `${q}: ${c.join('-')} → 3rd ${c[1]}, 7th ${c[3]}`; };
say('guide tones minor7 vs half_diminished7', gt('minor7') + ' | ' + gt('half_diminished7') + '  ⇒ identical guide tones; only the 5th differs');

// 14. l4u14m5 C1 "VII … Mixolydian-flavored cadence": VII–i in A natural minor vs A Mixolydian
const mix = [0, 2, 4, 5, 7, 9, 10].map((s, k) => fmt(above(P('A')!, k, s)));
say('A Mixolydian = ' + mix.join(' '), 'contains C (3rd of A minor i)? ' + mix.includes('C') + ' ⇒ VII–i (G–Am) is Aeolian, not Mixolydian');
