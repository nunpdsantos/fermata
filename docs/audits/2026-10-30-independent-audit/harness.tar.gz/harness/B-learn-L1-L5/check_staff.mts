// CHECK: note_id exercises — does the drawn staff match what the prompt says?
// App clef rule replicated from ExercisePrompt.tsx:68: clef = any note octave < 4 ? 'bass' : 'treble'.
import { collect } from './collect.mts';
import { staffPos } from './oracle.mts';

function judge(cfg: any, prompt: string) {
  const clef = cfg.octave < 4 ? 'bass' : 'treble';
  const pos = staffPos(cfg.note, cfg.octave, clef);
  const issues: string[] = [];
  const p = prompt.toLowerCase();
  if (/treble/.test(p) && clef !== 'treble') issues.push(`prompt says treble, app draws BASS clef`);
  if (/ledger/.test(p) && pos.ledger === 0) issues.push(`prompt says ledger line(s), note needs 0 ledger lines (${pos.where})`);
  if (/second ledger line|two ledger lines/.test(p) && pos.ledger !== 2) issues.push(`prompt says 2 ledger lines, note needs ${pos.ledger}`);
  if (/ledger line below|below the treble/.test(p) && !/below/.test(pos.where)) issues.push(`prompt says below the staff, note is ${pos.where}`);
  if (/first line/.test(p) && pos.where !== 'line 1') issues.push(`prompt says first line, note is ${pos.where}`);
  if (/second line/.test(p) && pos.where !== 'line 2') issues.push(`prompt says second line, note is ${pos.where}`);
  return { clef, pos, issues };
}
// self-test
const good = judge({ note: 'C', octave: 4 }, 'Identify this note on a ledger line below the treble staff.');
const bad = judge({ note: 'B', octave: 4 }, 'Identify this note on a ledger line below the treble staff.');
console.log('SELFTEST C4 (1 ledger below treble):', good.issues.length === 0 ? 'PASS' : 'FAIL ' + good.issues, '| B4 planted bad:', bad.issues.length ? 'CAUGHT' : 'NOT CAUGHT');
if (good.issues.length || !bad.issues.length) process.exit(2);

const { items } = await collect();
const nid = items.filter((i) => i.type === 'note_id');
const tally: Record<string, [number, number]> = {};
for (const it of nid) {
  const j = judge(it.config, it.prompt);
  tally[it.source] ??= [0, 0];
  tally[it.source][0]++;
  if (j.issues.length) tally[it.source][1]++;
  if (it.source !== 'space' || j.issues.length)
    console.log(`${it.source.padEnd(9)} ${it.id.padEnd(15)} ${it.config.note}${it.config.accidental}${it.config.octave} clef=${j.clef.padEnd(6)} ${j.pos.where.padEnd(22)} ledger=${j.pos.ledger} ${j.issues.length ? '<< ' + j.issues.join('; ') : 'ok'} | "${it.prompt.slice(0, 60)}"`);
}
console.log('\nTALLY (inconsistent / total):', JSON.stringify(tally));
