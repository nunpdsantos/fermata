// Misc checks: answer leaks in prompts, retry reveal, chip spelling, generated-prompt grammar,
// absolute-pitch ear items. Each section has a planted self-test.
import { collect } from './collect.mts';
import { scale, chord, parseNote, pc, fmt } from './oracle.mts';
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const { validateAnswer } = await import(R + '/components/learn/exercises/validateExercise.ts');
const { generateNoteChoices } = await import(R + '/components/learn/exercises/exerciseHelpers.ts');
const { PITCH_CLASS_SPELLINGS } = await import(R + '/core/constants/notes.ts');
const { INTERVAL_LABELS } = await import(R + '/core/constants/chords.ts');
const { items } = await collect();
const playable = items.filter((i) => i.source !== 'space');

// ---------- A. build prompts that list the full answer ----------
const oracle = (c: any) => (c.type === 'scale_build' ? scale(parseNote(c.root + c.rootAccidental)!, c.scaleType) : chord(parseNote(c.root + c.rootAccidental)!, c.quality));
function leaksBuild(it: any) {
  const want = new Set(oracle(it.config).map(fmt));
  const found = new Set([...it.prompt.matchAll(/(?<![A-Za-z])([A-G](?:#|b)?)(?![a-z#])/g)].map((m) => m[1]));
  return [...want].every((n) => found.has(n));
}
console.log('A-SELFTEST leak planted:', leaksBuild({ prompt: 'Build C: C-E-G', config: { type: 'chord_build', root: 'C', rootAccidental: '', quality: 'major' } }) ? 'CAUGHT' : 'MISSED',
  '| clean:', !leaksBuild({ prompt: 'Build a C major triad.', config: { type: 'chord_build', root: 'C', rootAccidental: '', quality: 'major' } }) ? 'PASS' : 'FAIL');
const bl = playable.filter((i) => i.type === 'chord_build' || i.type === 'scale_build');
const leaky = bl.filter(leaksBuild);
console.log(`A. build exercises whose PROMPT already lists every answer note: ${leaky.length}/${bl.length}`);
for (const i of leaky) console.log(`   ${i.id}: "${i.prompt}"`);

// interval prompts that state the answer's semitone count + quality
const ivLeak = playable.filter((i) => i.type === 'interval_id' && new RegExp(INTERVAL_LABELS[i.config.targetSemitones], 'i').test(i.prompt));
console.log(`A2. interval_id prompts that contain the answer label itself: ${ivLeak.length}`);
for (const i of ivLeak) console.log(`   ${i.id}: "${i.prompt}" → answer "${INTERVAL_LABELS[i.config.targetSemitones]}"`);

// ---------- B. retry reveal: first wrong attempt shows the correct answer ----------
let revealed = 0, tested = 0;
for (const it of playable) {
  const c = it.config;
  let wrong: string | null = null, right = '';
  if (c.type === 'multiple_choice') { wrong = c.choices.find((x: any) => !x.correct).label; right = c.choices.find((x: any) => x.correct).label; }
  else if (c.type === 'interval_id') { wrong = String(c.targetSemitones === 1 ? 2 : c.targetSemitones - 1); right = INTERVAL_LABELS[c.targetSemitones]; }
  else if (c.type === 'note_id') { wrong = 'F' === c.note ? 'G' : 'F'; right = c.note + c.accidental; }
  else if (c.type === 'scale_degree_id') { wrong = String(c.correctDegree === 1 ? 2 : 1); right = ''; }
  else continue;
  tested++;
  const v = validateAnswer(c, wrong);
  if (!v.correct && (right === '' ? /That note is the/.test(v.explanation) : v.explanation.includes(right))) revealed++;
}
console.log(`B. choice-type items whose FIRST wrong answer feedback states the correct answer: ${revealed}/${tested}`);
console.log('   sample:', validateAnswer({ type: 'multiple_choice', choices: [{ label: 'A minor', correct: true }, { label: 'C minor', correct: false }] }, 'C minor').explanation);

// ---------- C. instrument chips show sharp spellings for flat notes ----------
let chipBad = 0;
const chipEx: string[] = [];
for (const it of bl) {
  const notes = oracle(it.config);
  const shown = notes.map((n) => { const s = PITCH_CLASS_SPELLINGS[pc(n)][0]; return s.natural + s.accidental; });
  const diff = notes.map(fmt).map((n, k) => (n !== shown[k] ? `${n}→"${shown[k]}"` : '')).filter(Boolean);
  if (diff.length) { chipBad++; if (chipEx.length < 12) chipEx.push(`${it.id} (${it.prompt.slice(0, 40)}…): ${diff.join(' ')}`); }
}
console.log(`C. build exercises where the selected-note chips (InstrumentInput.tsx:94-95) would name a correct note with a different spelling: ${chipBad}/${bl.length}`);
console.log('   ' + chipEx.join('\n   '));

// ---------- D. generated prompt grammar / raw identifiers ----------
const gen = items.filter((i) => i.source === 'generated');
const article = gen.filter((i) => /\ba [AEF](?:b|#)?\b/.test(i.prompt));
const raw = gen.filter((i) => /\b(minor7|major7|dominant7|diminished7|half diminished7)\b/.test(i.prompt));
const going = gen.filter((i) => /going (ascending|descending)/.test(i.prompt));
console.log(`D. generated prompts: "a A/a E/a F" article errors ${article.length}/${gen.length}; raw quality ids (minor7…) ${raw.length}; "going ascending/descending" ${going.length}`);
console.log('   e.g. ' + [...article.slice(0, 3), ...raw.slice(0, 2), ...going.slice(0, 1)].map((i) => `"${i.prompt}"`).join(' | '));

// ---------- E. ear note-ID items: what the learner hears vs is asked ----------
for (const it of playable.filter((i) => i.type === 'ear_training' && i.config.mode === 'note')) {
  const ch = generateNoteChoices(it.config.note, it.config.accidental).map((c: any) => c.label).sort();
  console.log(`E. ${it.id}: plays ONE note ${it.config.note}${it.config.accidental}${it.config.octave} with no reference tone; choices ${JSON.stringify(ch)}`);
}
