const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const { CURRICULUM_LEVELS } = await import(R + '/core/constants/levels.ts');
const order: any[] = [];
for (const l of CURRICULUM_LEVELS) for (const u of l.units) for (const m of u.modules) order.push({ ...m, lvl: l.id, u: u.id });
const pos = new Map(order.map((m, i) => [m.id, i]));
const ids = order.map((m) => m.id);
console.log('modules total', ids.length, 'unique', new Set(ids).size);
let issues = 0;
for (const [i, m] of order.entries()) {
  if (!['l1','l2','l3','l4','l5'].includes(m.lvl)) continue;
  if (m.levelId !== m.lvl || m.unitId !== m.u) { issues++; console.log('ID MISMATCH', m.id, m.levelId, m.unitId, 'actual', m.lvl, m.u); }
  for (const p of m.prerequisites) { if (!pos.has(p)) { issues++; console.log('MISSING PREREQ', m.id, p); } else if (pos.get(p)! >= i) { issues++; console.log('FORWARD PREREQ', m.id, p); } }
  if (i > 0 && !m.prerequisites.includes(order[i - 1].id)) console.log('note: prereq is not the immediately previous module', m.id, m.prerequisites, 'prev', order[i - 1].id);
  const tids = m.tasks.map((t: any) => t.id); if (new Set(tids).size !== tids.length) { issues++; console.log('DUP TASK ID', m.id); }
}
const L15 = order.filter((m) => ['l1','l2','l3','l4','l5'].includes(m.lvl));
console.log('L1-L5 modules', L15.length, 'per level', ['l1','l2','l3','l4','l5'].map((l) => L15.filter((m) => m.lvl === l).length).join('/'), 'structural issues', issues);
