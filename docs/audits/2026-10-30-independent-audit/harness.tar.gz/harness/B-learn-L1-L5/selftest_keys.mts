import { majorKeySig, parseNote, above, fmt } from './oracle.mts';
// planted: "E major has 3 sharps" must disagree; "Ab major has 4 flats" must agree; relative minor of Eb = C
const e = majorKeySig(parseNote('E')!), ab = majorKeySig(parseNote('Ab')!), cb = majorKeySig(parseNote('Cb')!), cs = majorKeySig(parseNote('C#')!);
console.log('E:', e, '→ planted "3 sharps"', e.n !== 3 ? 'CAUGHT' : 'MISSED');
console.log('Ab:', ab, ab.n === -4 ? 'PASS' : 'FAIL', '| Cb:', cb.n, '| C#:', cs.n);
console.log('relative minor of Eb:', fmt(above(parseNote('Eb')!, 5, 9)), '| relative major of F#:', fmt(above(parseNote('F#')!, 2, 3)));
