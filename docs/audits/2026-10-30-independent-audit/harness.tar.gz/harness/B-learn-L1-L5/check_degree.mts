// CHECK: scale_degree_id — (a) answer key vs independent oracle, (b) does the learner
// actually see which note is asked about? ExercisePrompt.tsx draws staff only for note_id /
// interval_id (lines 33-66), so for scale_degree_id the PROMPT TEXT is the only carrier.
import { collect } from './collect.mts';
import { scale, parseNote, pc } from './oracle.mts';

function judge(it: any) {
  const c = it.config;
  const sc = scale(parseNote(c.root + c.rootAccidental)!, c.scaleType);
  const note = parseNote(c.note + c.noteAccidental)!;
  const deg = sc.findIndex((n) => n.L === note.L && n.acc === note.acc) + 1;
  const degPc = sc.findIndex((n) => pc(n) === pc(note)) + 1;
  const keyOk = deg === c.correctDegree;
  const named = new RegExp(`\\b${c.note}${c.noteAccidental.replace('#', '\\#')}(?![A-Za-z#])`).test(it.prompt.replace(/^In the \S+/, ''));
  return { deg, degPc, keyOk, named };
}
// self-tests
const g = judge({ config: { root: 'C', rootAccidental: '', scaleType: 'major', note: 'E', noteAccidental: '', correctDegree: 3 }, prompt: 'In the C major scale, what degree is the note E?' });
const b = judge({ config: { root: 'C', rootAccidental: '', scaleType: 'major', note: 'E', noteAccidental: '', correctDegree: 4 }, prompt: 'In the C major scale, what degree number is the given note?' });
console.log('SELFTEST good:', g.keyOk && g.named ? 'PASS' : 'FAIL', '| planted wrong key + unnamed note:', !b.keyOk && !b.named ? 'CAUGHT' : 'NOT CAUGHT');
if (!(g.keyOk && g.named) || b.keyOk || b.named) process.exit(2);

const { items } = await collect();
const sd = items.filter((i) => i.type === 'scale_degree_id');
const t: Record<string, { n: number; badKey: number; unnamed: number }> = {};
for (const it of sd) {
  const j = judge(it);
  t[it.source] ??= { n: 0, badKey: 0, unnamed: 0 };
  t[it.source].n++;
  if (!j.keyOk) t[it.source].badKey++;
  if (!j.named) t[it.source].unnamed++;
  if (it.source !== 'space' && (!j.keyOk || !j.named)) console.log(`${it.source} ${it.id}: note=${it.config.note}${it.config.noteAccidental} key=${it.config.correctDegree} oracle=${j.deg} ${j.keyOk ? '' : 'WRONG KEY '}${j.named ? '' : 'NOTE NOT SHOWN TO LEARNER'} | "${it.prompt}"`);
}
console.log('TALLY:', JSON.stringify(t));
// which templates produce unnamed prompts
const unnamedTpl = new Set(sd.filter((i) => i.source === 'space' && !judge(i).named).map((i) => i.id.split('#')[0]));
console.log('templates whose prompt never names the note:', [...unnamedTpl].join(', '));
