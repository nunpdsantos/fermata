import { collect } from './collect.mts';
const { items, modules } = await collect();
const by = (s: string) => items.filter((i) => i.source === s);
const types = (arr: any[]) => Object.entries(arr.reduce((a: any, i: any) => (a[i.type] = (a[i.type] ?? 0) + 1, a), {})).map(([k, v]) => `${k}:${v}`).join(' ');
console.log('modules', modules.length, 'concepts', modules.reduce((a, m) => a + m.concepts.length, 0), 'tasks', modules.reduce((a, m) => a + m.tasks.length, 0));
for (const s of ['authored', 'generated', 'space']) console.log(s, by(s).length, '|', types(by(s)));
console.log('modules without templates:', modules.filter((m) => !items.some((i) => i.moduleId === m.id && i.source === 'generated')).map((m) => m.id).join(','));
