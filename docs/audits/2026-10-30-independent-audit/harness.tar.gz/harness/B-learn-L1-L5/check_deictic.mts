// CHECK: multiple-choice prompts that point at a stimulus ("this chord", "the indicated line",
// "described", "illustrated here") — MC exercises render NO staff/audio/visual
// (ExercisePrompt.tsx draws staff only for note_id/interval_id), so the referent does not exist.
import { collect } from './collect.mts';
const RE = /\b(this|these)\s+(note|interval|chord|cadence|time signature|major key|seventh chord|diatonic seventh chord|suspension figure|non-chord tone|V7 chord|borrowed chord|type of harmonic sequence|chain|musical form|modulation technique|keys|diatonic triad|harmonic progression pattern|tonic key|pivot chord modulation|secondary dominant|secondary leading-tone chord)\b|\bindicated\b|\bdescribed\b|illustrated here|\bthe given\b/i;
console.log('SELFTEST', RE.test('Classify this cadence type') && !RE.test('What is a plagal cadence?') ? 'PASS (planted caught, clean passes)' : 'FAIL');
const { items } = await collect();
const mc = items.filter((i) => i.type === 'multiple_choice' && i.source !== 'space');
const hit = mc.filter((i) => RE.test(i.prompt));
const byPrompt = new Map<string, string[]>();
for (const i of hit) byPrompt.set(i.prompt, [...(byPrompt.get(i.prompt) ?? []), i.id]);
console.log(`playable MC items (authored+generated): ${mc.length}; prompts referring to a non-existent stimulus: ${hit.length} (authored ${hit.filter(i=>i.source==='authored').length}, generated ${hit.filter(i=>i.source==='generated').length})`);
for (const [p, ids] of byPrompt) console.log(`  "${p}" — ${ids.length}: ${ids.join(', ')}`);
