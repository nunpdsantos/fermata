// CHECK: multiple-choice integrity across L1–L5 (authored + generated + all template choice sets)
//  (1) exactly one correct option; (2) unique labels (ChoiceInput keys by label/value);
//  (3) "longest option is the correct one" test-wiseness leak;
//  (4) modules whose exercise set contains the same question twice (authored vs generated duplicates).
import { collect } from './collect.mts';
const { items } = await collect();

function choicesOf(it: any) {
  const c = it.config;
  if (c.type === 'multiple_choice') return c.choices;
  if (c.type === 'ear_training' && c.choices) return c.choices;
  return null;
}
// self-test
const planted = [{ label: 'a', correct: true }, { label: 'a', correct: true }];
const nCorrect = planted.filter((x) => x.correct).length, uniq = new Set(planted.map((x) => x.label)).size;
console.log('SELFTEST planted 2-correct + dup label:', nCorrect !== 1 && uniq !== planted.length ? 'CAUGHT' : 'NOT CAUGHT');

const seen = new Set<string>();
let total = 0, longest = 0, strictlyLongest = 0, multi = 0, dup = 0;
const perSource: Record<string, [number, number]> = {};
const longestExamples: string[] = [];
for (const it of items) {
  const ch = choicesOf(it);
  if (!ch) continue;
  // de-duplicate identical choice sets (space duplicates generated)
  const key = it.source + JSON.stringify(ch);
  if (it.source === 'space') { if (seen.has(key)) continue; seen.add(key); }
  total++;
  const corr = ch.filter((x: any) => x.correct);
  if (corr.length !== 1) { multi++; console.log('NOT EXACTLY ONE CORRECT:', it.id, JSON.stringify(ch)); }
  if (new Set(ch.map((x: any) => x.label)).size !== ch.length) { dup++; console.log('DUP LABEL:', it.id); }
  const lens = ch.map((x: any) => x.label.length);
  const max = Math.max(...lens);
  const c = corr[0];
  perSource[it.source] ??= [0, 0];
  if (it.source !== 'generated') perSource[it.source][0]++;
  if (c && c.label.length === max) {
    longest++;
    if (lens.filter((l: number) => l === max).length === 1) {
      strictlyLongest++;
      if (it.source !== 'generated') perSource[it.source][1]++;
      if (longestExamples.length < 6) longestExamples.push(`${it.id}: "${c.label}" vs ${ch.filter((x: any) => !x.correct).map((x: any) => `"${x.label}"`).join(', ')}`);
    }
  }
}
console.log(`MC/choice items checked (authored + generated + unique template sets): ${total}`);
console.log(`not-exactly-one-correct: ${multi}; duplicate labels: ${dup}`);
console.log(`correct option is the strictly-longest option: ${strictlyLongest}/${total} (${(100 * strictlyLongest / total).toFixed(0)}%) — chance level with 4 options ≈ 25%`);
console.log('by source (unique sets, authored + template sets):', JSON.stringify(perSource));
console.log('examples:\n  ' + longestExamples.join('\n  '));

// duplicates within a module's playable set (authored+generated)
const byMod: Record<string, Map<string, string[]>> = {};
for (const it of items.filter((i) => i.source !== 'space')) {
  const k = it.type === 'multiple_choice' ? 'MC:' + it.prompt + JSON.stringify(it.config.choices.map((c: any) => c.label).sort()) : it.type + ':' + JSON.stringify(Object.entries(it.config).filter(([k]) => !['noteCount'].includes(k)).sort());
  (byMod[it.moduleId] ??= new Map()).set(k, [...(byMod[it.moduleId].get(k) ?? []), it.id]);
}
const dups: string[] = [];
for (const [m, mp] of Object.entries(byMod)) for (const ids of mp.values()) if (ids.length > 1) dups.push(`${m}: ${ids.join(' = ')}`);
console.log(`\nidentical exercises inside one module's run (authored vs generated): ${dups.length}\n  ` + dups.join('\n  '));
