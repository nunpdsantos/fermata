// Side-by-side: module title vs the subject of its generated-exercise templates, with the share
// of the module's pass-gate (authored + generated) that the templates make up.
import { collect } from './collect.mts';
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const { items, modules } = await collect();
const tps: any = {};
for (const n of [1,2,3,4,5]) for (const tc of (await import(R + `/data/exercises/templatesL${n}.ts`)).default) tps[tc.moduleId] = tc;
const ids = (process.argv[2] ?? '').split(',').filter(Boolean);
for (const m of modules) {
  if (ids.length && !ids.includes(m.id)) continue;
  const a = items.filter((i) => i.moduleId === m.id && i.source === 'authored').length;
  const g = items.filter((i) => i.moduleId === m.id && i.source === 'generated').length;
  const tc = tps[m.id];
  const prompts = tc ? tc.templates.map((t: any) => t.promptTemplate.slice(0, 75)).join(' ¦ ') : '(no templates)';
  console.log(`${m.id.padEnd(9)} "${m.title}" — authored ${a}, generated ${g} (${a + g ? Math.round(100 * g / (a + g)) : 0}% of pass gate; need ${(0.8 * (a + g)).toFixed(1)} pts)\n          templates: ${prompts}`);
}
