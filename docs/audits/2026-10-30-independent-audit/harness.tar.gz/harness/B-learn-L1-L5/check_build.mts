// CHECK: scale_build / chord_build — grading vs independent oracle, noteCount, and every
// note list written in the prompt/hint vs oracle spelling.
import { collect } from './collect.mts';
import { scale, chord, parseNote, pc, fmt } from './oracle.mts';
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const { validateAnswer } = await import(R + '/components/learn/exercises/validateExercise.ts');

function oracleNotes(c: any) {
  const root = parseNote(c.root + c.rootAccidental)!;
  return c.type === 'scale_build' ? scale(root, c.scaleType) : chord(root, c.quality);
}
function judge(it: any) {
  const c = it.config;
  const notes = oracleNotes(c);
  const pcs = new Set(notes.map(pc));
  const res: string[] = [];
  if (!validateAnswer(c, pcs).correct) res.push('APP REJECTS ORACLE ANSWER');
  const minus = new Set([...pcs].slice(1));
  if (validateAnswer(c, minus).correct) res.push('APP ACCEPTS INCOMPLETE ANSWER');
  if (c.noteCount !== pcs.size) res.push(`noteCount=${c.noteCount} but chord/scale has ${pcs.size}`);
  // note lists in prompt + hint: sequences of >=3 note names joined by , or - or –
  const text = `${it.prompt} || ${it.hint}`;
  const re = /\b([A-G](?:##|#|bb|b)?)(?:\s*(?:,|-|–|—)\s*([A-G](?:##|#|bb|b)?)(?![a-z#])){2,}/g;
  const want = new Set(notes.map(fmt));
  for (const m of text.matchAll(re)) {
    const list = m[0].split(/\s*(?:,|-|–|—)\s*/).map((s) => s.trim());
    const bad = list.filter((n) => !want.has(n));
    if (bad.length) res.push(`text lists [${list.join(' ')}] — not in oracle {${[...want].join(' ')}}: ${bad.join(',')}`);
  }
  return res;
}
// self-test: correct C major passes; planted wrong text and wrong noteCount caught
const ok = judge({ config: { type: 'chord_build', root: 'C', rootAccidental: '', quality: 'major', noteCount: 3 }, prompt: 'Build C', hint: 'C, E, G' });
const bad = judge({ config: { type: 'chord_build', root: 'C', rootAccidental: '', quality: 'major', noteCount: 4 }, prompt: 'Build C', hint: 'C, Eb, G' });
console.log('SELFTEST good:', ok.length === 0 ? 'PASS' : 'FAIL ' + ok, '| planted bad:', bad.length === 2 ? 'CAUGHT (2 issues)' : 'NOT CAUGHT ' + bad);
if (ok.length || bad.length !== 2) process.exit(2);

const { items } = await collect();
const b = items.filter((i) => i.type === 'scale_build' || i.type === 'chord_build');
const tally: Record<string, [number, number]> = {};
for (const it of b) {
  const r = judge(it);
  tally[it.source] ??= [0, 0];
  tally[it.source][0]++;
  if (r.length) { tally[it.source][1]++; console.log(`${it.source} ${it.id}: ${r.join(' | ')}`); }
}
console.log('TALLY (items with issues / total):', JSON.stringify(tally));
