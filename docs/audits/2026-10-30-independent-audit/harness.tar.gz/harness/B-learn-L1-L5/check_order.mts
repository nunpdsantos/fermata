// CHECK: concept-before-taught. For every exercise (authored + generated + full template
// space) find topic terms that appear in the exercise text but in NO lesson text
// (title/subtitle/objectives/concepts/tasks) of this module or any earlier module, and
// report the first module that does teach the term.
import { collect } from './collect.mts';
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const { CURRICULUM_LEVELS } = await import(R + '/core/constants/levels.ts');

const TERMS: [string, RegExp][] = [
  ['compound meter / 6/8', /compound|6\/8/i], ['common time', /common time/i], ['cut time / alla breve', /cut time|alla breve|2\/2/i],
  ['hemiola', /hemiola/i], ['cadential 6/4', /cadential 6\/4/i], ['cadence (PAC/HC/IAC/deceptive/plagal)', /\b(PAC|IAC|half cadence|deceptive|plagal|authentic cadence)\b/i],
  ['period / antecedent / consequent', /\bperiod\b|antecedent|consequent/i], ['sentence (Satz)', /sentence structure|\bsentence\b.*presentation|presentation phase/i],
  ['passing tone', /passing tone/i], ['neighbor tone', /neighbou?r/i], ['suspension', /suspension/i], ['appoggiatura', /appoggiatura/i],
  ['escape tone', /escape tone/i], ['retardation', /retardation/i], ['anticipation', /anticipation/i], ['pedal point', /pedal/i],
  ['harmonic rhythm', /harmonic rhythm/i], ['harmonic sequence', /sequence/i], ['harmonic function T/PD/D', /pre-?dominant|tonic function|\bT -> PD|T-PD-D/i],
  ['quality names (major/minor/perfect intervals)', /\b(Perfect|Major|Minor) (2nd|3rd|4th|5th|6th|7th)\b/],
  ['parallel fifths', /parallel (5ths|fifths)/i], ['figured bass', /figured bass/i], ['key signature beyond C/G/D/F', /\b(E|Bb|Ab|Eb|Db|B) major has\b/],
];
// Build cumulative lesson text in curriculum order
const order: { id: string; title: string; text: string }[] = [];
for (const lvl of CURRICULUM_LEVELS) for (const u of lvl.units) for (const m of u.modules) {
  const text = [m.title, m.subtitle, ...m.objectives, ...m.concepts.flatMap((c: any) => [c.title, c.explanation]), ...m.tasks.map((t: any) => t.instruction)].join(' \n ');
  order.push({ id: m.id, title: m.title, text });
}
const idx = new Map(order.map((m, i) => [m.id, i]));
const firstTaught = (re: RegExp) => order.find((m) => re.test(m.text));
// self-test: a planted exercise in l1u1m1 mentioning "hemiola" must be flagged; one mentioning "staff" must not
const taughtBy = (mid: string, re: RegExp) => order.slice(0, idx.get(mid)! + 1).some((m) => re.test(m.text));
console.log('SELFTEST hemiola@l1u1m1:', !taughtBy('l1u1m1', /hemiola/i) ? 'CAUGHT' : 'NOT CAUGHT', '| staff@l1u1m1:', taughtBy('l1u1m1', /staff/i) ? 'PASS' : 'FAIL');

const { items } = await collect();
const agg = new Map<string, { term: string; ids: string[]; first: string }>();
for (const it of items) {
  if (it.source === 'space') continue; // playable items only for the tally
  const text = it.prompt + ' ' + JSON.stringify(it.config.choices ?? '') + ' ' + it.hint;
  for (const [name, re] of TERMS) {
    if (!re.test(text)) continue;
    if (taughtBy(it.moduleId, re)) continue;
    const f = firstTaught(re);
    const k = it.moduleId + '|' + name;
    const e = agg.get(k) ?? { term: name, ids: [], first: f ? `${f.id} "${f.title}"` : 'NEVER TAUGHT in L1–L9 lesson text' };
    e.ids.push(it.id);
    agg.set(k, e);
  }
}
const rows = [...agg.entries()].sort((a, b) => idx.get(a[0].split('|')[0])! - idx.get(b[0].split('|')[0])!);
let n = 0;
for (const [k, e] of rows) { n += e.ids.length; console.log(`${k.split('|')[0].padEnd(9)} "${order[idx.get(k.split('|')[0])!].title}" uses [${e.term}] — first taught in ${e.first} — ${e.ids.length} item(s): ${e.ids.join(', ')}`); }
console.log(`\n${rows.length} (module, term) pairs; ${n} item-term hits among playable (authored + generated) L1–L5 exercises`);
