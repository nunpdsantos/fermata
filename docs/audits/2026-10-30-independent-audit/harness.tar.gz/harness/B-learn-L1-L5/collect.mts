// Collects every L1–L5 exercise the app can show: authored, generated (as the app
// generates them, seeded by module id), and the FULL template space (every config
// buildConfig could produce from each template), for exhaustive checks.
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const { generateExercises } = await import(R + '/data/exercises/exerciseGenerator.ts');
const { CURRICULUM_LEVELS } = await import(R + '/core/constants/levels.ts');

export type Item = { id: string; moduleId: string; level: number; type: string; prompt: string; hint: string; config: any; source: 'authored' | 'generated' | 'space'; tpl?: number };

const en = (s: string) => s.replace(/_/g, ' ');
function fill(t: string, cfg: any): string {
  const r: Record<string, string> = {};
  switch (cfg.type) {
    case 'note_id': r.root = r.note = cfg.note + cfg.accidental; r.octave = String(cfg.octave); break;
    case 'interval_id': r.root = cfg.root + cfg.rootAccidental; r.semitones = String(cfg.targetSemitones); r.direction = en(cfg.direction); break;
    case 'scale_build': r.root = cfg.root + cfg.rootAccidental; r.scaleType = en(cfg.scaleType); break;
    case 'chord_build': r.root = cfg.root + cfg.rootAccidental; r.quality = en(cfg.quality); break;
    case 'scale_degree_id': r.root = cfg.root + cfg.rootAccidental; r.scaleType = en(cfg.scaleType); r.note = cfg.note + cfg.noteAccidental; r.degree = String(cfg.correctDegree); break;
    case 'ear_training': if (cfg.note) r.note = cfg.note + (cfg.accidental ?? ''); if (cfg.root) r.root = cfg.root + (cfg.rootAccidental ?? ''); if (cfg.targetSemitones !== undefined) r.semitones = String(cfg.targetSemitones); if (cfg.direction) r.direction = en(cfg.direction); break;
  }
  let out = t;
  for (const [k, v] of Object.entries(r)) out = out.replace(new RegExp(`\\{${k}\\}`, 'g'), v);
  return out.replace(/\{accidental\}/g, '');
}

// Own scale-degree resolver for the template space (independent of app buildScale)
import { scale, parseNote, fmt } from './oracle.mts';

function space(tpl: any): any[] {
  const p = tpl.params, out: any[] = [];
  const roots = p.roots ?? [], accs = p.accidentals ?? roots.map(() => '');
  switch (tpl.type) {
    case 'note_id': for (let i = 0; i < roots.length; i++) for (const o of p.octaves ?? [4]) out.push({ type: 'note_id', note: roots[i], accidental: accs[i] ?? '', octave: o }); break;
    case 'interval_id': for (let i = 0; i < roots.length; i++) for (const s of p.intervals ?? [3, 4, 5, 7]) for (const d of p.directions ?? ['ascending']) for (const o of p.octaves ?? [4]) out.push({ type: 'interval_id', root: roots[i], rootAccidental: accs[i] ?? '', rootOctave: o, targetSemitones: s, direction: d }); break;
    case 'scale_build': { const st = p.scaleTypes ?? ['major'], nc = p.noteCounts ?? [7]; for (let i = 0; i < roots.length; i++) for (let j = 0; j < st.length; j++) { const counts = st.length === nc.length ? [nc[j]] : nc; for (const c of counts) out.push({ type: 'scale_build', root: roots[i], rootAccidental: accs[i] ?? '', scaleType: st[j], noteCount: c }); } break; }
    case 'chord_build': { const q = p.chordQualities ?? ['major'], nc = p.noteCounts ?? [3]; for (let i = 0; i < roots.length; i++) { const qs = roots.length === q.length ? [q[i]] : q; for (const qq of qs) for (const c of nc) out.push({ type: 'chord_build', root: roots[i], rootAccidental: accs[i] ?? '', quality: qq, noteCount: c }); } break; }
    case 'multiple_choice': for (const cs of p.choiceSets ?? []) out.push({ type: 'multiple_choice', choices: cs }); break;
    case 'scale_degree_id': for (let i = 0; i < roots.length; i++) for (const st of p.scaleTypes ?? ['major']) for (const d of p.degrees ?? [1, 2, 3, 4, 5, 6, 7]) { const n = scale(parseNote(roots[i] + (accs[i] ?? ''))!, st)[d - 1]; const f = fmt(n); out.push({ type: 'scale_degree_id', root: roots[i], rootAccidental: accs[i] ?? '', scaleType: st, note: f[0], noteAccidental: f.slice(1), correctDegree: d }); } break;
    case 'ear_training': out.push({ type: 'ear_training', mode: p.earMode, _params: p }); break;
  }
  return out;
}

export async function collect(levels = [1, 2, 3, 4, 5]) {
  const items: Item[] = [];
  const modules: { id: string; title: string; level: number; concepts: any[]; tasks: any[] }[] = [];
  for (const n of levels) {
    const lvl = CURRICULUM_LEVELS.find((l: any) => l.id === 'l' + n);
    for (const u of lvl.units) for (const m of u.modules) modules.push({ id: m.id, title: m.title, level: n, concepts: m.concepts, tasks: m.tasks });
    const ex = (await import(R + `/data/exercises/exercisesL${n}.ts`)).default;
    const tp = (await import(R + `/data/exercises/templatesL${n}.ts`)).default;
    for (const [mid, arr] of Object.entries(ex) as any) for (const e of arr) items.push({ id: e.id, moduleId: mid, level: n, type: e.type, prompt: e.prompt, hint: e.hint ?? '', config: e.config, source: 'authored' });
    for (const tc of tp) {
      for (const e of generateExercises(tc)) items.push({ id: e.id, moduleId: tc.moduleId, level: n, type: e.type, prompt: e.prompt, hint: e.hint ?? '', config: e.config, source: 'generated' });
      tc.templates.forEach((t: any, ti: number) => space(t).forEach((cfg, k) => items.push({ id: `${tc.moduleId}T${ti}#${k}`, moduleId: tc.moduleId, level: n, type: t.type, prompt: fill(t.promptTemplate, cfg), hint: fill(t.hintTemplate, cfg), config: cfg, source: 'space', tpl: ti })));
    }
  }
  return { items, modules };
}
