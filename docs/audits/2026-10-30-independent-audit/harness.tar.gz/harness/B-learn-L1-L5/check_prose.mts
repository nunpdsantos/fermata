// CHECK: every spelled note list and key-signature / relative-key claim in L1–L5 lesson prose,
// tasks, milestones, exercise prompts/options/hints, verified against the independent oracle.
import { collect } from './collect.mts';
import { scale, chord, parseNote, fmt, majorKeySig, above } from './oracle.mts';
const R = '/Users/nunosantos/Documents/Base/Music/new_music_app/src';
const { CURRICULUM_LEVELS } = await import(R + '/core/constants/levels.ts');

// ---- gather texts with a location tag ----
const texts: { where: string; s: string }[] = [];
for (const lvl of CURRICULUM_LEVELS.filter((l: any) => ['l1', 'l2', 'l3', 'l4', 'l5'].includes(l.id))) for (const u of lvl.units) {
  if (u.milestone) texts.push({ where: `${u.id}.milestone`, s: JSON.stringify(u.milestone) });
  for (const m of u.modules) {
    m.concepts.forEach((c: any, i: number) => texts.push({ where: `${m.id}.C${i}`, s: c.explanation + ' ' + c.tryThisLabel }));
    m.tasks.forEach((t: any) => texts.push({ where: t.id, s: t.instruction }));
  }
}
const { items } = await collect();
for (const it of items.filter((i) => i.source !== 'space' || i.type === 'multiple_choice')) texts.push({ where: it.id, s: `${it.prompt} || ${it.hint} || ${JSON.stringify(it.config.choices?.filter((c: any) => c.correct).map((c: any) => c.label) ?? '')}` });

// ---- designation parser: chord symbols and "X major/minor/diminished..." ----
const QMAP: [RegExp, string][] = [
  [/^maj7$|^Δ7$|^M7$/, 'major7'], [/^m7b5$|^ø7?$|^half-diminished(?: 7th)?$/, 'half_diminished7'], [/^dim7$|^o7$|^°7$|^fully diminished(?: 7th)?$/, 'diminished7'],
  [/^m7$|^minor 7th$/, 'minor7'], [/^7$|^dominant 7th$/, 'dominant7'], [/^m$|^minor$/, 'minor'], [/^dim$|^°$|^diminished$/, 'diminished'], [/^aug$|^\+$|^augmented$/, 'augmented'], [/^$|^major$/, 'major'],
  [/^mMaj7$|^m\(maj7\)$/, 'minor_major7'],
];
const SCALES: [RegExp, string][] = [[/^natural minor$/, 'natural_minor'], [/^harmonic minor$/, 'harmonic_minor'], [/^melodic minor(?: ascending)?$/, 'melodic_minor'], [/^major(?: scale)?$/, 'major']];
function designate(before: string): { kind: string; notes: string[]; name: string } | null {
  // scale designation: "A harmonic minor: " / "D major: " / "C major (C D E…)" — prefer explicit scale words
  let m = before.match(/([A-G][#b♯♭]?)\s+(natural minor|harmonic minor|melodic minor(?: ascending)?|major)\s*(?:scale)?\s*(?:[:=(]|ascending:)?\s*$/);
  if (m) {
    const root = parseNote(m[1])!;
    for (const [re, t] of SCALES) if (re.test(m[2])) {
      // "X major" may be a chord or a scale; caller decides by list length
      return { kind: t === 'major' ? 'major?' : t, notes: [], name: `${m[1]} ${m[2]}` };
    }
  }
  m = before.match(/([A-G][#b]?)(maj7|m7b5|dim7|mMaj7|m7|7|m|dim|aug|\+|°|ø7|ø)?\s*(?:\(|=|:|contains|is|=\s*)\s*$/) ??
      before.match(/([A-G][#b]?)\s+(dominant 7th|minor 7th|half-diminished 7th|half-diminished|fully diminished 7th|diminished|augmented|minor|major)\s*(?:triad|chord)?\s*(?:\(|=|:)?\s*$/);
  if (m) {
    const q = m[2] ?? '';
    for (const [re, t] of QMAP) if (re.test(q)) return { kind: 'chord:' + t, notes: [], name: m[1] + (q ? ' ' + q : '') };
  }
  return null;
}
const LIST = /(?<![A-Za-z])([A-G](?:##|#|bb|b|♯|♭)?)(?:\s*(?:,|-|–|—)\s*(?:and\s+)?([A-G](?:##|#|bb|b|♯|♭)?)(?![a-z#♯])){2,}/g;
let checked = 0, bad = 0, unparsed = 0;
const out: string[] = [], un: string[] = [];
function check(where: string, before: string, list: string[]) {
  const d = designate(before);
  if (!d) { unparsed++; un.push(`${where}: …${before.slice(-45)}[${list.join(' ')}]`); return; }
  const rootStr = d.name.split(/\s+/)[0].replace(/(maj7|m7b5|dim7|mMaj7|m7|7|m|dim|aug|\+|°|ø7|ø)$/, '');
  const root = parseNote(rootStr)!;
  let want: string[];
  if (d.kind === 'major?') want = list.length >= 6 ? scale(root, 'major').map(fmt) : chord(root, 'major').map(fmt);
  else if (d.kind.startsWith('chord:')) want = chord(root, d.kind.slice(6)).map(fmt);
  else want = scale(root, d.kind).map(fmt);
  checked++;
  const L = list.map((s) => s.replace('♯', '#').replace('♭', 'b'));
  const listOk = L.every((n) => want.includes(n)) && (L.length === want.length || L.length === want.length + 1 && L[0] === L[L.length - 1]);
  if (!listOk) { bad++; out.push(`${where}: "${d.name}" listed [${L.join(' ')}] ≠ oracle [${want.join(' ')}]  …${before.slice(-50)}`); }
}
// self-test
const before0 = unparsed, bad0 = bad, ch0 = checked;
check('SELF-good', 'G7 = ', ['G', 'B', 'D', 'F']);
check('SELF-bad', 'A harmonic minor: ', ['A', 'B', 'C', 'D', 'E', 'F', 'G']);
console.log('SELFTEST good G7 passes & planted wrong A harmonic minor caught:', checked - ch0 === 2 && bad - bad0 === 1 ? 'YES' : 'NO', out.splice(0));
bad = 0; checked = 0; unparsed = before0; un.length = 0;

for (const t of texts) for (const m of t.s.matchAll(LIST)) {
  const list = m[0].split(/\s*(?:,|-|–|—)\s*(?:and\s+)?/);
  check(t.where, t.s.slice(Math.max(0, m.index! - 60), m.index!), list);
}

// ---- key-signature claims "X major has N sharps/flats" ----
const ksOut: string[] = []; let ksN = 0;
for (const t of texts) for (const m of t.s.matchAll(/\b([A-G][#b]?) major has (\d|no) (sharps?|flats?)/g)) {
  ksN++;
  const ks = majorKeySig(parseNote(m[1])!);
  const n = m[2] === 'no' ? 0 : +m[2];
  const claimed = /sharp/.test(m[3]) ? n : -n;
  if (claimed !== ks.n && !(n === 0 && ks.n === 0)) {
    const isCorrectOpt = /"correct":true|\|\| \[/.test(t.s) ? '' : '';
    ksOut.push(`${t.where}: "${m[0]}" — oracle ${ks.n >= 0 ? ks.n + ' sharps' : -ks.n + ' flats'}`);
  }
}
// relative keys
const relOut: string[] = []; let relN = 0;
for (const t of texts) for (const m of t.s.matchAll(/relative (minor|major) of ([A-G][#b]?) (major|minor) is ([A-G][#b]?) (minor|major)/g)) {
  relN++;
  const k = parseNote(m[2])!;
  const want = m[1] === 'minor' ? fmt(above(k, 5, 9)) : fmt(above(k, 2, 3));
  if (want !== m[4]) relOut.push(`${t.where}: "${m[0]}" — oracle ${want}`);
}
console.log(`NOTE LISTS: ${checked} parsed & checked, ${bad} mismatches, ${unparsed} lists without a parseable chord/scale name (printed for manual review)`);
console.log(out.join('\n'));
console.log(`\nKEY-SIGNATURE claims "X major has N …": ${ksN} checked (note: includes deliberately-false distractor options only if marked correct) — mismatches in CORRECT-labelled text:\n` + ksOut.join('\n'));
console.log(`RELATIVE-KEY claims: ${relN} checked, mismatches:\n` + relOut.join('\n'));
console.log('\n--- unparsed lists (manual review) ---\n' + un.join('\n'));
