import { defineConfig, devices } from '/Users/nunosantos/Documents/Base/Music/new_music_app/node_modules/@playwright/test/index.mjs';
export default defineConfig({
  testDir: '/Users/nunosantos/Documents/Base/Music/new_music_app/e2e',
  timeout: 60_000,
  expect: { timeout: 10_000 },
  fullyParallel: false,
  workers: 1,
  retries: 0,
  reporter: 'list',
  outputDir: '/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/F-engineering/pw-preview-results',
  use: { baseURL: 'http://localhost:4199', screenshot: 'only-on-failure' },
  projects: [{ name: 'chromium', use: { ...devices['Desktop Chrome'] } }],
  webServer: { command: 'npx vite preview --port 4199 --strictPort', cwd: '/Users/nunosantos/Documents/Base/Music/new_music_app', url: 'http://localhost:4199', reuseExistingServer: false, timeout: 60_000 },
});
