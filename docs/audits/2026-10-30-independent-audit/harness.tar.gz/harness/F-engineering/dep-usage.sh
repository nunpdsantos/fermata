for d in sharp @vitest/ui vexflow; do
  echo "== $d"
  grep -rnE "(from|require\(|import\()[[:space:]]*['\"]$d['\"]" src scripts e2e vite.config.ts vitest.config.ts eslint.config.js playwright.config.ts | head -3
  echo "  grep exit=${PIPESTATUS[0]}"
done
grep -n -- "--ui" package.json; echo "ui-script grep exit=$?"
git log --oneline -S'"sharp"' -- package.json | head -3
