import fs from 'node:fs'; import path from 'node:path';
const dist = process.argv[2];
const sw = fs.readFileSync(path.join(dist,'sw.js'),'utf8');
const pre = [...sw.matchAll(/url:"([^"]+)"/g)].map(m=>m[1]);
console.log('precache entries:', pre.length);
for (const p of pre) { const st = fs.existsSync(path.join(dist,p)) ? fs.statSync(path.join(dist,p)).size : -1; console.log('  PRE', p, st); }
// runtime caching regexes as emitted in sw.js
const rt = [...sw.matchAll(/registerRoute\((\/.*?\/[a-z]*),/g)].map(m=>m[1]);
console.log('runtime routes:', rt);
const regs = rt.map(r=>{const m=r.match(/^\/(.*)\/([a-z]*)$/); return new RegExp(m[1],m[2]);});
const assets = fs.readdirSync(path.join(dist,'assets')).filter(f=>f.endsWith('.js'));
let uncovered=[];
for (const f of assets) { const u='assets/'+f; if (pre.includes(u)) continue; const url='https://x/'+u; if (regs.some(r=>r.test(url))) continue; uncovered.push(u+' '+fs.statSync(path.join(dist,u)).size); }
console.log('JS assets:', assets.length, 'uncovered by precache or runtime cache:', uncovered.length); uncovered.forEach(u=>console.log('  UNCOVERED', u));
