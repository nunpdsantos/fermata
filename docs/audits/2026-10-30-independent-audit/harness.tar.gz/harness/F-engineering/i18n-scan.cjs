// Find user-visible hardcoded strings in TSX: JsxText with letters, and string-literal
// values of aria-label/title/placeholder/alt/aria-description attributes.
const ts = require('/Users/nunosantos/Documents/Base/Music/new_music_app/node_modules/typescript');
const fs = require('fs'); const path = require('path');
const root = process.argv[2];
const files = [];
(function walk(d) { for (const f of fs.readdirSync(d)) { const p = path.join(d, f); const s = fs.statSync(p); if (s.isDirectory()) { if (f === '__tests__' || f === 'core' && d.endsWith('/src')) continue; walk(p); } else if (/\.tsx$/.test(f)) files.push(p); } })(root);
const ATTRS = new Set(['aria-label', 'title', 'placeholder', 'alt', 'aria-description', 'aria-roledescription', 'aria-valuetext']);
let hits = 0;
for (const f of files) {
  const src = fs.readFileSync(f, 'utf8');
  const sf = ts.createSourceFile(f, src, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
  const out = [];
  (function visit(n) {
    if (ts.isJsxText(n)) { const t = n.getText().replace(/\s+/g, ' ').trim(); if (/[A-Za-z]{2,}/.test(t)) out.push(['text', t, n]); }
    if (ts.isJsxAttribute(n) && n.initializer) { const name = n.name.getText(); if (ATTRS.has(name)) { const init = n.initializer; let lit = null; if (ts.isStringLiteral(init)) lit = init.text; else if (ts.isJsxExpression(init) && init.expression && (ts.isStringLiteral(init.expression) || ts.isNoSubstitutionTemplateLiteral(init.expression) || ts.isTemplateExpression(init.expression))) lit = init.expression.getText(); if (lit && /[A-Za-z]{3,}/.test(lit)) out.push(['attr:' + name, lit, n]); } }
    ts.forEachChild(n, visit);
  })(sf);
  for (const [k, t, n] of out) { const { line } = sf.getLineAndCharacterOfPosition(n.getStart()); console.log(path.relative(root, f) + ':' + (line + 1) + '\t' + k + '\t' + t.slice(0, 90)); hits++; }
}
console.error('files scanned:', files.length, 'hits:', hits);
