// WCAG 2.x contrast ratios for Fermata theme tokens (values copied from src/index.css
// :root and :root.fermata-night, src/design/tokens/palette.ts, colors.ts, and Tailwind v4 defaults).
const hex = (h) => { h = h.replace('#', ''); return [0, 2, 4].map((i) => parseInt(h.slice(i, i + 2), 16) / 255); };
const lin = (c) => (c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4);
const L = (h) => { const [r, g, b] = hex(h).map(lin); return 0.2126 * r + 0.7152 * g + 0.0722 * b; };
const cr = (a, b) => { const [x, y] = [L(a), L(b)].sort((p, q) => q - p); return (x + 0.05) / (y + 0.05); };
const themes = {
  'fermata (day, DEFAULT)': { bg: '#f5efe2', 'bg-raised': '#efe7d5', card: '#ede4cf', 'card-hover': '#e4d9bf', text: '#2a1f14', 'text-muted': '#6b5436', 'text-dim': '#8b7551', accent: '#a65a2a', 'piano-white': '#faf5e9', 'piano-label': '#8b7551', border: '#c9b895' },
  'fermata-night': { bg: '#181208', 'bg-raised': '#211a0f', card: '#271f12', 'card-hover': '#322817', text: '#f1e9d8', 'text-muted': '#c3ad86', 'text-dim': '#8f7c5a', accent: '#d2804a', 'piano-white': '#e9dcbf', 'piano-label': '#a8916a', border: '#4a3c28' },
};
const palette = { 'palette.warning/AMBER/deg5': '#FBBF24', 'palette.success/deg4 (emerald-400)': '#34D399', 'palette.accent/deg1': '#60A5FA', 'palette.danger/deg7': '#F87171', 'deg2 violet': '#A78BFA', 'deg3 pink': '#F472B6', 'deg6 orange': '#FB923C' };
const rows = [];
const fmt = (n) => n.toFixed(2);
for (const [tn, t] of Object.entries(themes)) {
  for (const fg of ['text', 'text-muted', 'text-dim', 'accent']) for (const bg of ['bg', 'card', 'card-hover']) rows.push([tn, `--${fg} on --${bg}`, cr(t[fg], t[bg])]);
  rows.push([tn, '--piano-label on --piano-white', cr(t['piano-label'], t['piano-white'])]);
  rows.push([tn, '#fff on --accent (.btn-accent)', cr('#ffffff', t.accent)]);
  rows.push([tn, '--border on --bg (non-text 3:1)', cr(t.border, t.bg)]);
  for (const [pn, pc] of Object.entries(palette)) rows.push([tn, `${pn} as text on --card`, cr(pc, t.card)]);
}
console.log('theme | pair | ratio | AA normal(4.5) | AA large(3)');
for (const [tn, p, r] of rows) console.log(`${tn} | ${p} | ${fmt(r)} | ${r >= 4.5 ? 'pass' : 'FAIL'} | ${r >= 3 ? 'pass' : 'FAIL'}`);
