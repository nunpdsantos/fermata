import { test } from '/Users/nunosantos/Documents/Base/Music/new_music_app/node_modules/@playwright/test/index.mjs';
for (const target of ['/', '/?view=explore', '/?view=learn', '/index.html']) {
  test('offline reopen ' + target, async ({ page, context }) => {
    await page.goto('/');
    await page.waitForFunction(async () => !!(await navigator.serviceWorker.getRegistration())?.active, undefined, { timeout: 20000 });
    await page.waitForTimeout(2500);
    const diag = await page.evaluate(async () => {
      const reg = await navigator.serviceWorker.getRegistration();
      const pre = (await caches.keys()).find(k => k.includes('precache'));
      const keys = pre ? (await (await caches.open(pre)).keys()).map(r => new URL(r.url).pathname + new URL(r.url).search) : [];
      return { controller: !!navigator.serviceWorker.controller, active: reg?.active?.state, hasIndex: keys.filter(k => k.includes('index.html')) };
    });
    await context.setOffline(true);
    let res = 'ok';
    try { await page.goto(target); await page.waitForTimeout(2500); } catch (e) { res = 'GOTO_FAIL ' + String(e).split('\n')[0]; }
    let panel = 'n/a', err = 'n/a';
    if (res === 'ok') { panel = await page.locator('[role=tabpanel]').getAttribute('id').catch(() => 'none'); err = await page.getByText('This view encountered an error.').count(); }
    console.log('DIAG', target, JSON.stringify(diag), res, 'panel=' + panel, 'errorBoundary=' + err);
    await context.setOffline(false);
  });
}
