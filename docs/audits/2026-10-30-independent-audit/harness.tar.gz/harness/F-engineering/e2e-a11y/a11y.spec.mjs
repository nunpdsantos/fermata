import { test, expect, devices } from '/Users/nunosantos/Documents/Base/Music/new_music_app/node_modules/@playwright/test/index.mjs';
test.use({ viewport: { width: 390, height: 844 }, hasTouch: true, isMobile: true });
const collect = () => {
  const sel = 'button, [role=button], a[href], input, select, [role=tab], [role=radio], [role=option], [role=switch], [tabindex]:not([tabindex="-1"])';
  const out = { small: [], unnamed: [], total: 0 };
  for (const el of document.querySelectorAll(sel)) {
    const r = el.getBoundingClientRect(); const cs = getComputedStyle(el);
    if (r.width === 0 || r.height === 0 || cs.visibility === 'hidden' || cs.display === 'none') continue;
    if (r.bottom < 0 || r.top > innerHeight * 3) continue;
    out.total++;
    let name = el.getAttribute('aria-label') || '';
    const lb = el.getAttribute('aria-labelledby'); if (!name && lb) name = lb.split(' ').map((id) => document.getElementById(id)?.textContent || '').join(' ');
    if (!name) name = (el.textContent || '').trim() || el.getAttribute('title') || [...el.querySelectorAll('img[alt]')].map((i) => i.alt).join(' ') || (el.tagName === 'SELECT' ? (el.labels?.[0]?.textContent || '') : '') || (el.tagName === 'INPUT' ? (el.getAttribute('placeholder') || el.labels?.[0]?.textContent || '') : '');
    const desc = el.tagName.toLowerCase() + (el.getAttribute('role') ? '[role=' + el.getAttribute('role') + ']' : '') + ' "' + name.replace(/\s+/g, ' ').slice(0, 40) + '" ' + Math.round(r.width) + 'x' + Math.round(r.height);
    if (!name.trim()) out.unnamed.push(desc + ' html=' + el.outerHTML.slice(0, 120).replace(/\s+/g, ' '));
    if (Math.min(r.width, r.height) < 24) out.small.push(desc);
  }
  return out;
};
async function report(page, label) {
  const r = await page.evaluate(collect);
  console.log('== ' + label + ': interactive=' + r.total + ' under24px=' + r.small.length + ' unnamed=' + r.unnamed.length);
  console.log('   SMALL: ' + JSON.stringify(r.small.slice(0, 40)));
  console.log('   UNNAMED: ' + JSON.stringify(r.unnamed));
}
test('a11y survey (mobile 390px)', async ({ page }) => {
  await page.goto('/');
  await page.waitForTimeout(1500);
  await report(page, 'Explore / piano');
  await page.getByRole('tab', { name: 'Guitar' }).click();
  await page.waitForTimeout(800);
  await report(page, 'Explore / guitar');
  await page.getByRole('tab', { name: 'Learn' }).click();
  await page.waitForTimeout(1200);
  await report(page, 'Learn overview');
  await page.locator('#learn-panel button').filter({ hasText: 'Foundations of Music Literacy' }).first().click();
  await page.waitForTimeout(1200);
  await page.locator('#learn-panel button').filter({ hasText: /Unit 1/i }).first().click();
  await page.waitForTimeout(1200);
  await report(page, 'Learn unit detail');
  await page.getByRole('tab', { name: 'Drill' }).click();
  await page.waitForTimeout(1500);
  await report(page, 'Drill home');
  await page.screenshot({ path: '/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/F-engineering/a11y-drill-mobile.png' });
});
test('QuickSearch focus behaviour (desktop)', async ({ browser }) => {
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 800 } });
  const page = await ctx.newPage();
  await page.goto('/'); await page.waitForTimeout(1200);
  const trigger = page.getByRole('button', { name: /Quick search/ });
  await trigger.click(); await page.waitForTimeout(400);
  const dialog = await page.evaluate(() => { const d = document.querySelector('[role=dialog]'); return d ? { modal: d.getAttribute('aria-modal'), label: d.getAttribute('aria-label') } : null; });
  const seq = [];
  for (let i = 0; i < 12; i++) { await page.keyboard.press('Tab'); seq.push(await page.evaluate(() => { const a = document.activeElement; const inDlg = !!a?.closest('[role=dialog]'); return (inDlg ? 'IN:' : 'OUT:') + a?.tagName + ':' + (a?.getAttribute('aria-label') || a?.textContent || '').trim().slice(0, 20); })); }
  await page.keyboard.press('Escape'); await page.waitForTimeout(300);
  const after = await page.evaluate(() => { const a = document.activeElement; return a?.tagName + ':' + (a?.getAttribute('aria-label') || a?.textContent || '').trim().slice(0, 30); });
  console.log('QS dialog attrs:', JSON.stringify(dialog));
  console.log('QS tab sequence:', JSON.stringify(seq));
  console.log('QS focus after Escape:', after);
  await ctx.close();
});
