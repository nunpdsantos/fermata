import { defineConfig } from '/Users/nunosantos/Documents/Base/Music/new_music_app/node_modules/vitest/dist/config.js';
export default defineConfig({
  root: '/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/F-engineering/vt',
  esbuild: { jsx: 'automatic' },
  cacheDir: '/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/F-engineering/vt/.vite-cache',
  resolve: { alias: { 'virtual:pwa-register': '/Users/nunosantos/Documents/Base/Music/new_music_app/src/test/stubs/pwa-register.ts' } },
  server: { fs: { allow: ['/Users/nunosantos/Documents/Base/Music/new_music_app', '/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/F-engineering'] } },
  test: {
    include: ['tests/**/*.test.{ts,tsx}'],
    environment: 'jsdom',
    setupFiles: ['/Users/nunosantos/Documents/Base/Music/new_music_app/src/i18n/index.ts'],
  },
});
