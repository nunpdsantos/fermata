// PROBE: a key released before resumeAudio() settles (first gesture, suspended
// AudioContext) — is the sustained note ever stopped?
import { describe, it, expect, vi, afterEach } from 'vitest';
import { render, cleanup, act } from '@testing-library/react';
let release: () => void = () => {};
vi.mock('/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/services/audio.ts', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  return { ...original,
    resumeAudio: vi.fn(() => new Promise<void>((r) => { release = r; })),
    startSustainedNote: vi.fn(), stopSustainedNote: vi.fn(), setMasterVolume: vi.fn() };
});
import { Piano } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/components/instruments/Piano';
import { startSustainedNote, stopSustainedNote } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/services/audio.ts';
import { useAppStore } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/state/store';

afterEach(() => { cleanup(); vi.clearAllMocks(); });
(Element.prototype as unknown as { scrollTo: () => void }).scrollTo = () => {};
Object.defineProperty(window, 'matchMedia', { writable: true, value: (q: string) => ({ matches: false, media: q, onchange: null, addListener() {}, removeListener() {}, addEventListener() {}, removeEventListener() {}, dispatchEvent() { return false; } }) });

describe('Piano quick tap while AudioContext resume is pending', () => {
  it('releases the note it started', async () => {
    render(<Piano />);
    // computer-keyboard path shares handleNoteOn/handleNoteOff with pointer + touch
    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'a', bubbles: true }));
    document.dispatchEvent(new KeyboardEvent('keyup', { key: 'a', bubbles: true }));
    await act(async () => { release(); await Promise.resolve(); await Promise.resolve(); await Promise.resolve(); });
    const started = (startSustainedNote as never as { mock: { calls: unknown[] } }).mock.calls.length;
    const stopped = (stopSustainedNote as never as { mock: { calls: unknown[] } }).mock.calls.length;
    const active = [...useAppStore.getState().activeNotes];
    console.log('PROBE started=', started, 'stopped=', stopped, 'activeNotes after release=', JSON.stringify(active));
    expect(started).toBe(1);
    expect(stopped).toBe(1);
    expect(active).toEqual([]);
  });
});
