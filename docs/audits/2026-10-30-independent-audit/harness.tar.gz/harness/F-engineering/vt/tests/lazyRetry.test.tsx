// PROBE: App.tsx wraps each React.lazy view in ErrorBoundary(resetKey=view,
// fallback with a "Try again" button calling reset). If the chunk import fails
// once (offline / transient network), does "Try again" recover once it would succeed?
import { describe, it, expect, vi, afterEach } from 'vitest';
import { lazy, Suspense } from 'react';
import { render, screen, fireEvent, cleanup, act } from '@testing-library/react';
import { ErrorBoundary } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/components/ErrorBoundary';
afterEach(cleanup);

describe('view chunk load failure + Try again', () => {
  it('recovers when the import succeeds on retry', async () => {
    vi.spyOn(console, 'error').mockImplementation(() => {});
    let calls = 0;
    const factory = () => { calls++; return calls === 1 ? Promise.reject(new Error('Failed to fetch dynamically imported module')) : Promise.resolve({ default: () => <p>VIEW OK</p> }); };
    const View = lazy(factory);
    const fallback = (_e: Error, reset: () => void) => <button onClick={reset}>Try again</button>;
    render(<ErrorBoundary resetKey="explore" fallback={fallback}><Suspense fallback={<p>loading</p>}><View /></Suspense></ErrorBoundary>);
    await act(async () => { await new Promise((r) => setTimeout(r, 20)); });
    expect(screen.getByText('Try again')).toBeTruthy();
    await act(async () => { fireEvent.click(screen.getByText('Try again')); await new Promise((r) => setTimeout(r, 20)); });
    console.log('PROBE import factory calls =', calls, '; VIEW OK visible =', !!screen.queryByText('VIEW OK'), '; Try again visible =', !!screen.queryByText('Try again'));
    expect(screen.queryByText('VIEW OK')).toBeTruthy();
  });
});
