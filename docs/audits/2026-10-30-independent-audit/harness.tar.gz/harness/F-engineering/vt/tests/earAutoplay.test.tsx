// PROBE: does the next ear-training exercise auto-play its stimulus if the
// learner answers + presses Next while the previous stimulus' lock is held?
import { describe, it, expect, vi, afterEach, beforeEach } from 'vitest';
import { render, screen, fireEvent, cleanup, act } from '@testing-library/react';
vi.mock('/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/services/audio', async (importOriginal) => {
  const original = await importOriginal<Record<string, unknown>>();
  return { ...original, resumeAudio: vi.fn().mockResolvedValue(undefined), playNote: vi.fn(), playChord: vi.fn(), playScale: vi.fn() };
});
import { ExerciseRunner } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/components/learn/exercises/ExerciseRunner';
import { playChord } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/core/services/audio';

const prog = (id: string) => ({
  id, type: 'ear_training', prompt: 'Identify the progression', points: 1,
  config: { type: 'ear_training', mode: 'progression', root: 'C', rootAccidental: '', progression: ['I', 'IV', 'V', 'I'],
    choices: [{ label: 'I - IV - V - I', correct: true }, { label: 'ii - V - I', correct: false }] },
}) as never;

async function tick(ms: number) { await act(async () => { await vi.advanceTimersByTimeAsync(ms); }); }

beforeEach(() => vi.useFakeTimers());
afterEach(() => { cleanup(); vi.clearAllMocks(); vi.useRealTimers(); });

async function run(answerAtMs: number) {
  render(<ExerciseRunner exercises={[prog('p1'), prog('p2')]} accentColor="#8b5cf6" onRecordResult={vi.fn()} onComplete={vi.fn()} />);
  await tick(answerAtMs);
  fireEvent.click(screen.getByText('I - IV - V - I'));
  fireEvent.click(screen.getByText('Submit'));
  fireEvent.click(screen.getByText('Continue'));
  await tick(10_000);
  return (playChord as unknown as { mock: { calls: unknown[] } }).mock.calls.length;
}

describe('ear-training autoplay after a quick Next', () => {
  it('CONTROL: answering after the 4.15 s lock -> second exercise auto-plays (8 chords total)', async () => {
    expect(await run(5000)).toBe(8);
  });
  it('PROBE: answering at 2 s (stimulus still sounding) -> second exercise should still auto-play', async () => {
    const n = await run(2000);
    console.log('PROBE playChord calls with fast answer =', n);
    expect(n).toBe(8);
  });
});
