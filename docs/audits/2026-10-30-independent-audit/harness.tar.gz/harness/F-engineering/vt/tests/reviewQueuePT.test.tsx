// PROBE: ReviewQueue strings when the UI language is Portuguese.
import { describe, it, expect, afterEach } from 'vitest';
import { render, cleanup, act } from '@testing-library/react';
import { LazyMotion, domAnimation } from 'framer-motion';
import i18n from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/i18n';
import { ReviewQueue } from '/Users/nunosantos/Documents/Base/Music/new_music_app/src/components/learn/ReviewQueue';
afterEach(cleanup);
const DAY = 86_400_000;
describe('ReviewQueue in PT', () => {
  it('renders fully in Portuguese', async () => {
    await act(async () => { await i18n.changeLanguage('pt'); });
    const now = Date.now();
    const progress = { completedModules: ['l1u1m1', 'l1u1m2'], moduleProgress: {}, reviewSchedules: {
      l1u1m1: { completedAt: now - 10 * DAY, nextReviewAt: now - DAY, intervalLevel: 2, reviewCount: 2, lastReviewedAt: now - 8 * DAY },
    } } as never;
    const { container } = render(<LazyMotion features={domAnimation}><ReviewQueue progress={progress} onStartReview={() => {}} /></LazyMotion>);
    const due = container.textContent;
    cleanup();
    const progress2 = { completedModules: ['l1u1m1'], moduleProgress: {}, reviewSchedules: {
      l1u1m1: { completedAt: now, nextReviewAt: now + 4 * DAY + 3600_000, intervalLevel: 1, reviewCount: 1, lastReviewedAt: now },
    } } as never;
    const r2 = render(<LazyMotion features={domAnimation}><ReviewQueue progress={progress2} onStartReview={() => {}} /></LazyMotion>);
    const caughtUp = r2.container.textContent;
    console.log('PROBE PT due-card text   :', JSON.stringify(due));
    console.log('PROBE PT caught-up text  :', JSON.stringify(caughtUp));
    await act(async () => { await i18n.changeLanguage('en'); });
    expect(due).not.toMatch(/Due now|week|Foundations of Music Literacy/);
    expect(caughtUp).not.toMatch(/In \d+ days/);
  });
});
