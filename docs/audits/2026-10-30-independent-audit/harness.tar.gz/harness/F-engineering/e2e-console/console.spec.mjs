import { test } from '/Users/nunosantos/Documents/Base/Music/new_music_app/node_modules/@playwright/test/index.mjs';
test('first-load console + fonts + requests', async ({ page }) => {
  const msgs = []; const reqs = [];
  page.on('console', (m) => msgs.push(m.type() + ': ' + m.text().slice(0, 200)));
  page.on('pageerror', (e) => msgs.push('pageerror: ' + String(e).slice(0, 200)));
  page.on('request', (r) => reqs.push(new URL(r.url()).pathname));
  await page.goto('/');
  await page.waitForTimeout(6000);
  const fonts = await page.evaluate(() => [...document.fonts].map((f) => f.family + '|' + f.style + '|' + f.status));
  console.log('FONTS:', JSON.stringify(fonts));
  console.log('CONSOLE:', JSON.stringify(msgs));
  const samples = reqs.filter((p) => p.includes('/samples/'));
  console.log('ALLREQ:', JSON.stringify(reqs)); console.log('REQUESTS total=', reqs.length, 'fonts=', JSON.stringify(reqs.filter((p) => p.includes('/fonts/'))), 'samples(before any interaction)=', samples.length);
  // Learn overview: how many curriculum chunks load just by opening Learn?
  const before = reqs.length;
  await page.getByRole('tab', { name: 'Learn' }).click();
  await page.waitForTimeout(3000);
  const learnReqs = reqs.slice(before).filter((p) => /curriculumL\d/.test(p));
  console.log('LEARN overview curriculum chunks fetched:', learnReqs.length, JSON.stringify(learnReqs));
});
