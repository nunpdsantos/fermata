import { defineConfig, devices } from '/Users/nunosantos/Documents/Base/Music/new_music_app/node_modules/@playwright/test/index.mjs';
export default defineConfig({
  testDir: '/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/F-engineering/e2e-flaky', testMatch: /.*\.spec\.mjs/, timeout: 60_000, workers: 5, retries: 0, reporter: 'list',
  outputDir: '/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/F-engineering/pw-flaky-probe',
  use: { baseURL: 'http://localhost:5173' },
  projects: [{ name: 'chromium', use: { ...devices['Desktop Chrome'] } }],
  webServer: { command: 'npm run dev', cwd: '/Users/nunosantos/Documents/Base/Music/new_music_app', url: 'http://localhost:5173', reuseExistingServer: true, timeout: 60_000 },
});
