// OKLCH -> sRGB (Björn Ottosson's matrices) then WCAG contrast vs light-theme surfaces.
const ok = { 'emerald-300': [0.845, 0.143, 164.978], 'emerald-400': [0.765, 0.177, 163.223], 'red-300': [0.808, 0.114, 19.571], 'red-400': [0.704, 0.191, 22.216], 'amber-300': [0.879, 0.169, 91.605], 'amber-400': [0.828, 0.189, 84.429] };
function toLinRGB([L, C, h]) { const a = C * Math.cos(h * Math.PI / 180), b = C * Math.sin(h * Math.PI / 180);
  const l_ = L + 0.3963377774 * a + 0.2158037573 * b, m_ = L - 0.1055613458 * a - 0.0638541728 * b, s_ = L - 0.0894841775 * a - 1.2914855480 * b;
  const l = l_ ** 3, m = m_ ** 3, s = s_ ** 3;
  return [4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s, -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s, -0.0041960863 * l - 0.7034186147 * m + 1.7076147010 * s].map((v) => Math.min(1, Math.max(0, v))); }
const lumLin = ([r, g, b]) => 0.2126 * r + 0.7152 * g + 0.0722 * b;
const hexLum = (h) => { h = h.slice(1); return lumLin([0, 2, 4].map((i) => parseInt(h.slice(i, i + 2), 16) / 255).map((c) => (c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4))); };
const cr = (a, b) => { const [x, y] = [a, b].sort((p, q) => q - p); return (x + 0.05) / (y + 0.05); };
// sanity: oklch(1 0 0) must be white
console.log('sanity white lum =', lumLin(toLinRGB([1, 0, 0])).toFixed(3));
for (const [n, v] of Object.entries(ok)) { const Lc = lumLin(toLinRGB(v)); console.log(`text-${n} on light --bg #f5efe2: ${cr(Lc, hexLum('#f5efe2')).toFixed(2)}:1 | on --card #ede4cf: ${cr(Lc, hexLum('#ede4cf')).toFixed(2)}:1`); }
