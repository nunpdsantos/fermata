const R = process.argv[2];
const ts = require(R + '/node_modules/typescript'); const fs = require('fs'); const path = require('path');
const all = [];
const walk = (d, acc, re) => { if (!fs.existsSync(d)) return; for (const f of fs.readdirSync(d)) { const p = path.join(d, f); if (fs.statSync(p).isDirectory()) walk(p, acc, re); else if (re.test(f)) acc.push(p); } };
walk(R + '/src', all, /\.(ts|tsx)$/);
const scripts = []; walk(R + '/scripts', scripts, /\.(ts|tsx|mjs|js)$/);
const e2e = []; walk(R + '/e2e', e2e, /\.(ts|tsx)$/);
const isTest = (p) => p.includes('/__tests__/') || /\.test\.tsx?$/.test(p) || p.includes('/src/test/') || p.includes('/e2e/');
const text = new Map([...all, ...scripts, ...e2e, R + '/vite.config.ts', R + '/index.html'].map((p) => [p, fs.readFileSync(p, 'utf8')]));
const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const rows = [];
for (const f of all.filter((p) => !isTest(p))) {
  const sf = ts.createSourceFile(f, text.get(f), ts.ScriptTarget.Latest, true);
  const names = [];
  sf.statements.forEach((s) => {
    const exp = s.modifiers?.some((m) => m.kind === ts.SyntaxKind.ExportKeyword);
    if (!exp) return;
    if (ts.isVariableStatement(s)) s.declarationList.declarations.forEach((d) => names.push(d.name.getText()));
    else if (s.name) names.push(s.name.getText());
  });
  for (const n of names) {
    const re = new RegExp('\\b' + esc(n) + '\\b');
    let prod = 0, test = 0, script = 0;
    for (const [p, t] of text) { if (p === f) continue; if (!re.test(t)) continue; if (p.startsWith(R + '/scripts')) script++; else if (isTest(p)) test++; else prod++; }
    const self = (text.get(f).match(new RegExp('\\b' + esc(n) + '\\b', 'g')) || []).length;
    if (prod === 0) rows.push([path.relative(R, f), n, test, script, self]);
  }
}
console.log('file\tsymbol\ttestFilesUsing\tscriptFilesUsing\tselfMentions');
rows.forEach((r) => console.log(r.join('\t')));
console.error('exports with no non-test importer:', rows.length);
