import { test, expect } from '/Users/nunosantos/Documents/Base/Music/new_music_app/node_modules/@playwright/test/index.mjs';

async function firstVisitThenOffline(page, context) {
  await page.goto('/');
  await page.waitForFunction(async () => !!(await navigator.serviceWorker.getRegistration())?.active, undefined, { timeout: 15000 });
  await page.waitForTimeout(2000);
  const cached = await page.evaluate(async () => {
    const out = {};
    for (const n of await caches.keys()) { const c = await caches.open(n); out[n] = (await c.keys()).map(r => new URL(r.url).pathname).filter(p => /View-|curriculum|exercises|templates/.test(p)); }
    return out;
  });
  console.log('CACHES after first visit:', JSON.stringify(cached));
  await context.setOffline(true);
}

test('Explore (default view) after ONE online visit, reopened offline', async ({ page, context }) => {
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  await firstVisitThenOffline(page, context);
  await page.goto('/');
  await page.waitForTimeout(3000);
  const errVisible = await page.getByText('This view encountered an error.').count();
  const explorePanel = await page.locator('#explore-panel').count();
  const bodyText = (await page.locator('main').innerText()).slice(0, 300);
  console.log('OFFLINE explore: errorBoundaryCount=', errVisible, 'explorePanel=', explorePanel, 'pageErrors=', JSON.stringify(errors));
  console.log('MAIN TEXT:', JSON.stringify(bodyText));
  await page.screenshot({ path: '/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/F-engineering/offline-explore-prod.png' });
  await context.setOffline(false);
});

test('Learn after ONE online visit to Explore only, reopened offline', async ({ page, context }) => {
  await firstVisitThenOffline(page, context);
  await page.goto('/?view=learn');
  await page.waitForTimeout(3000);
  const errVisible = await page.getByText('This view encountered an error.').count();
  const bodyText = (await page.locator('main').innerText()).slice(0, 300);
  console.log('OFFLINE learn: errorBoundaryCount=', errVisible, 'MAIN TEXT:', JSON.stringify(bodyText));
  await page.screenshot({ path: '/private/tmp/claude-501/-Users-nunosantos/2c236006-c5b2-4c0c-8541-483f648fb071/scratchpad/audit/F-engineering/offline-learn-prod.png' });
  await context.setOffline(false);
});
