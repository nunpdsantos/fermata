import { test, expect } from '/Users/nunosantos/Documents/Base/Music/new_music_app/node_modules/@playwright/test/index.mjs';
test('module click probe', async ({ page }) => {
  await page.addInitScript(() => {
    window.__clicks = [];
    document.addEventListener('click', (e) => {
      const t = e.target; const b = t.closest && t.closest('button,[role=button]');
      window.__clicks.push({ t: Math.round(performance.now()), tag: t.tagName, btn: b ? (b.innerText || '').slice(0, 40).replace(/\n/g,' | ') : null, x: e.clientX, y: e.clientY, inDoc: document.contains(t) });
    }, true);
  });
  await page.goto('/');
  await page.getByRole('tab', { name: 'Learn' }).click();
  const level1 = page.locator('#learn-panel button').filter({ hasText: 'Foundations of Music Literacy' });
  await expect(level1).toBeVisible({ timeout: 10_000 });
  await level1.click();
  const unit = page.locator('#learn-panel button').filter({ hasText: 'Notation & Pitch' }).first();
  const anyUnit = page.locator('#learn-panel button').filter({ hasText: /Unit 1/i }).first();
  const unitCount = await unit.count();
  if (unitCount) await unit.click(); else await anyUnit.click();
  const module = page.locator('#learn-panel button, #learn-panel [role="button"]').filter({ hasText: 'The Staff and Clefs' }).first();
  await expect(module).toBeVisible({ timeout: 10_000 });
  await module.click();
  let ok = true;
  try { await expect(page.getByText('Exercises')).toBeVisible({ timeout: 5_000 }); } catch { ok = false; }
  const clicks = await page.evaluate(() => window.__clicks);
  console.log('RESULT ok=' + ok + ' unitCount=' + unitCount + ' clicks=' + JSON.stringify(clicks));
});
