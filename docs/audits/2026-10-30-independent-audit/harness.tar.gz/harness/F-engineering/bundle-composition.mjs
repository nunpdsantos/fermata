// Attribute minified bytes of a chunk to source files using its sourcemap
// (mappings decoded per generated segment; bytes between segments credited to the segment's source).
import fs from 'node:fs';
const [,, jsPath] = process.argv;
const code = fs.readFileSync(jsPath, 'utf8');
const map = JSON.parse(fs.readFileSync(jsPath + '.map', 'utf8'));
const B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
function decodeVLQ(str) { const out = []; let shift = 0, val = 0; for (const ch of str) { let d = B64.indexOf(ch); const cont = d & 32; d &= 31; val += d << shift; if (cont) { shift += 5; } else { const neg = val & 1; val >>= 1; out.push(neg ? -val : val); val = 0; shift = 0; } } return out; }
const lines = code.split('\n'); const lineStarts = []; let off = 0; for (const l of lines) { lineStarts.push(off); off += l.length + 1; }
const bytes = new Map(); let src = 0;
map.mappings.split(';').forEach((lineMap, li) => {
  if (!lineMap) return; let col = 0; const segs = [];
  for (const seg of lineMap.split(',')) { const v = decodeVLQ(seg); col += v[0]; if (v.length >= 4) { src += v[1]; segs.push([col, src]); } else segs.push([col, -1]); }
  for (let i = 0; i < segs.length; i++) { const [c, s] = segs[i]; const end = i + 1 < segs.length ? segs[i + 1][0] : lines[li].length; if (s < 0) continue; const name = map.sources[s]; bytes.set(name, (bytes.get(name) || 0) + (end - c)); }
});
const group = (p) => { p = p.replace(/^(\.\.\/)+/, ''); if (p.includes('node_modules/')) { const m = p.split('node_modules/').pop().split('/'); return 'npm:' + (m[0].startsWith('@') ? m[0] + '/' + m[1] : m[0]); } const parts = p.split('/'); return parts.slice(0, Math.min(parts.length - 1, 3)).join('/') + '/'; };
const byGroup = new Map(); for (const [k, v] of bytes) { const g = group(k); byGroup.set(g, (byGroup.get(g) || 0) + v); }
const total = [...bytes.values()].reduce((a, b) => a + b, 0);
console.log('chunk', jsPath.split('/').pop(), 'size', code.length, 'attributed', total);
console.log('--- by group (top 25)'); [...byGroup].sort((a, b) => b[1] - a[1]).slice(0, 25).forEach(([g, v]) => console.log(String(v).padStart(8), (v / code.length * 100).toFixed(1).padStart(5) + '%', g));
console.log('--- by file (top 30)'); [...bytes].sort((a, b) => b[1] - a[1]).slice(0, 30).forEach(([g, v]) => console.log(String(v).padStart(8), g.replace(/^(\.\.\/)+/, '')));
