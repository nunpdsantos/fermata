const ts = require('/Users/nunosantos/Documents/Base/Music/new_music_app/node_modules/typescript'); const fs = require('fs'); const path = require('path');
const root = process.argv[2]; const files = [];
(function walk(d) { for (const f of fs.readdirSync(d)) { const p = path.join(d, f); if (fs.statSync(p).isDirectory()) { if (['__tests__','core','data','i18n','test','design'].includes(f)) continue; walk(p); } else if (/\.tsx?$/.test(f)) files.push(p); } })(root);
for (const f of files) {
  const src = fs.readFileSync(f, 'utf8'); const sf = ts.createSourceFile(f, src, ts.ScriptTarget.Latest, true, f.endsWith('x') ? ts.ScriptKind.TSX : ts.ScriptKind.TS);
  (function visit(n) {
    if ((ts.isStringLiteral(n) || ts.isNoSubstitutionTemplateLiteral(n)) && !ts.isImportDeclaration(n.parent) && !ts.isExportDeclaration(n.parent)) {
      const t = n.text; const p = n.parent;
      const isKeyArg = ts.isCallExpression(p) && /(^|\.)t$|i18n\.t$|getItem|setItem|removeItem|console\.|addEventListener|querySelector|startsWith|includes|matchMedia|Error$/.test(p.expression.getText());
      const inAttrClass = ts.isJsxAttribute(p) && /className|style|role|type|id|key|href|d|points|viewBox/.test(p.name.getText());
      if (!isKeyArg && !inAttrClass && /^[A-Z][a-z]+( [A-Za-z']+){1,}[.!?]?$/.test(t) && !/var\(|px|rem/.test(t)) {
        const { line } = sf.getLineAndCharacterOfPosition(n.getStart()); console.log(path.relative(root, f) + ':' + (line + 1) + '\t' + JSON.stringify(t));
      }
    }
    ts.forEachChild(n, visit);
  })(sf);
}
